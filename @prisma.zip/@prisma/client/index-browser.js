const prisma = require('.prisma/client/index-browser')

module.exports = prisma
