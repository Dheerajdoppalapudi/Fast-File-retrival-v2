/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function format(a: number, b: number, c: number, d: number, e: number): void;
export function get_config(a: number, b: number, c: number): void;
export function get_dmmf(a: number, b: number, c: number): void;
export function lint(a: number, b: number, c: number): void;
export function validate(a: number, b: number, c: number): void;
export function native_types(a: number, b: number, c: number): void;
export function referential_actions(a: number, b: number, c: number): void;
export function preview_features(a: number): void;
export function text_document_completion(a: number, b: number, c: number, d: number, e: number): void;
export function code_actions(a: number, b: number, c: number, d: number, e: number): void;
export function debug_panic(): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
export function __wbindgen_free(a: number, b: number): void;
