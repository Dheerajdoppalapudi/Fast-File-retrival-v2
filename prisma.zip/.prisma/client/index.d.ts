
/**
 * Client
**/

import * as runtime from '@prisma/client/runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model Directory
 * 
 */
export type Directory = $Result.DefaultSelection<Prisma.$DirectoryPayload>
/**
 * Model File
 * 
 */
export type File = $Result.DefaultSelection<Prisma.$FilePayload>
/**
 * Model Version
 * 
 */
export type Version = $Result.DefaultSelection<Prisma.$VersionPayload>
/**
 * Model Approval
 * 
 */
export type Approval = $Result.DefaultSelection<Prisma.$ApprovalPayload>
/**
 * Model Permission
 * 
 */
export type Permission = $Result.DefaultSelection<Prisma.$PermissionPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const Role: {
  ADMIN: 'ADMIN',
  EDITOR: 'EDITOR',
  VIEWER: 'VIEWER'
};

export type Role = (typeof Role)[keyof typeof Role]


export const ApprovalStatus: {
  PENDING: 'PENDING',
  APPROVED: 'APPROVED',
  REJECTED: 'REJECTED'
};

export type ApprovalStatus = (typeof ApprovalStatus)[keyof typeof ApprovalStatus]


export const PermissionType: {
  READ: 'READ',
  WRITE: 'WRITE'
};

export type PermissionType = (typeof PermissionType)[keyof typeof PermissionType]


export const ResourceType: {
  FILE: 'FILE',
  DIRECTORY: 'DIRECTORY'
};

export type ResourceType = (typeof ResourceType)[keyof typeof ResourceType]

}

export type Role = $Enums.Role

export const Role: typeof $Enums.Role

export type ApprovalStatus = $Enums.ApprovalStatus

export const ApprovalStatus: typeof $Enums.ApprovalStatus

export type PermissionType = $Enums.PermissionType

export const PermissionType: typeof $Enums.PermissionType

export type ResourceType = $Enums.ResourceType

export const ResourceType: typeof $Enums.ResourceType

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.directory`: Exposes CRUD operations for the **Directory** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Directories
    * const directories = await prisma.directory.findMany()
    * ```
    */
  get directory(): Prisma.DirectoryDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.file`: Exposes CRUD operations for the **File** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Files
    * const files = await prisma.file.findMany()
    * ```
    */
  get file(): Prisma.FileDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.version`: Exposes CRUD operations for the **Version** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Versions
    * const versions = await prisma.version.findMany()
    * ```
    */
  get version(): Prisma.VersionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.approval`: Exposes CRUD operations for the **Approval** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Approvals
    * const approvals = await prisma.approval.findMany()
    * ```
    */
  get approval(): Prisma.ApprovalDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.permission`: Exposes CRUD operations for the **Permission** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Permissions
    * const permissions = await prisma.permission.findMany()
    * ```
    */
  get permission(): Prisma.PermissionDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.5.0
   * Query Engine version: 173f8d54f8d52e692c7e27e72a88314ec7aeff60
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    Directory: 'Directory',
    File: 'File',
    Version: 'Version',
    Approval: 'Approval',
    Permission: 'Permission'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "directory" | "file" | "version" | "approval" | "permission"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.UserCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.UserUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      Directory: {
        payload: Prisma.$DirectoryPayload<ExtArgs>
        fields: Prisma.DirectoryFieldRefs
        operations: {
          findUnique: {
            args: Prisma.DirectoryFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DirectoryPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.DirectoryFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DirectoryPayload>
          }
          findFirst: {
            args: Prisma.DirectoryFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DirectoryPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.DirectoryFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DirectoryPayload>
          }
          findMany: {
            args: Prisma.DirectoryFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DirectoryPayload>[]
          }
          create: {
            args: Prisma.DirectoryCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DirectoryPayload>
          }
          createMany: {
            args: Prisma.DirectoryCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.DirectoryCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DirectoryPayload>[]
          }
          delete: {
            args: Prisma.DirectoryDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DirectoryPayload>
          }
          update: {
            args: Prisma.DirectoryUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DirectoryPayload>
          }
          deleteMany: {
            args: Prisma.DirectoryDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.DirectoryUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.DirectoryUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DirectoryPayload>[]
          }
          upsert: {
            args: Prisma.DirectoryUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DirectoryPayload>
          }
          aggregate: {
            args: Prisma.DirectoryAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateDirectory>
          }
          groupBy: {
            args: Prisma.DirectoryGroupByArgs<ExtArgs>
            result: $Utils.Optional<DirectoryGroupByOutputType>[]
          }
          count: {
            args: Prisma.DirectoryCountArgs<ExtArgs>
            result: $Utils.Optional<DirectoryCountAggregateOutputType> | number
          }
        }
      }
      File: {
        payload: Prisma.$FilePayload<ExtArgs>
        fields: Prisma.FileFieldRefs
        operations: {
          findUnique: {
            args: Prisma.FileFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$FilePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.FileFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          findFirst: {
            args: Prisma.FileFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$FilePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.FileFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          findMany: {
            args: Prisma.FileFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$FilePayload>[]
          }
          create: {
            args: Prisma.FileCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          createMany: {
            args: Prisma.FileCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.FileCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$FilePayload>[]
          }
          delete: {
            args: Prisma.FileDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          update: {
            args: Prisma.FileUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          deleteMany: {
            args: Prisma.FileDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.FileUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.FileUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$FilePayload>[]
          }
          upsert: {
            args: Prisma.FileUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$FilePayload>
          }
          aggregate: {
            args: Prisma.FileAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateFile>
          }
          groupBy: {
            args: Prisma.FileGroupByArgs<ExtArgs>
            result: $Utils.Optional<FileGroupByOutputType>[]
          }
          count: {
            args: Prisma.FileCountArgs<ExtArgs>
            result: $Utils.Optional<FileCountAggregateOutputType> | number
          }
        }
      }
      Version: {
        payload: Prisma.$VersionPayload<ExtArgs>
        fields: Prisma.VersionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.VersionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VersionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.VersionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VersionPayload>
          }
          findFirst: {
            args: Prisma.VersionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VersionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.VersionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VersionPayload>
          }
          findMany: {
            args: Prisma.VersionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VersionPayload>[]
          }
          create: {
            args: Prisma.VersionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VersionPayload>
          }
          createMany: {
            args: Prisma.VersionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.VersionCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VersionPayload>[]
          }
          delete: {
            args: Prisma.VersionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VersionPayload>
          }
          update: {
            args: Prisma.VersionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VersionPayload>
          }
          deleteMany: {
            args: Prisma.VersionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.VersionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.VersionUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VersionPayload>[]
          }
          upsert: {
            args: Prisma.VersionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VersionPayload>
          }
          aggregate: {
            args: Prisma.VersionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateVersion>
          }
          groupBy: {
            args: Prisma.VersionGroupByArgs<ExtArgs>
            result: $Utils.Optional<VersionGroupByOutputType>[]
          }
          count: {
            args: Prisma.VersionCountArgs<ExtArgs>
            result: $Utils.Optional<VersionCountAggregateOutputType> | number
          }
        }
      }
      Approval: {
        payload: Prisma.$ApprovalPayload<ExtArgs>
        fields: Prisma.ApprovalFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ApprovalFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ApprovalPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ApprovalFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ApprovalPayload>
          }
          findFirst: {
            args: Prisma.ApprovalFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ApprovalPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ApprovalFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ApprovalPayload>
          }
          findMany: {
            args: Prisma.ApprovalFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ApprovalPayload>[]
          }
          create: {
            args: Prisma.ApprovalCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ApprovalPayload>
          }
          createMany: {
            args: Prisma.ApprovalCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ApprovalCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ApprovalPayload>[]
          }
          delete: {
            args: Prisma.ApprovalDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ApprovalPayload>
          }
          update: {
            args: Prisma.ApprovalUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ApprovalPayload>
          }
          deleteMany: {
            args: Prisma.ApprovalDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ApprovalUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ApprovalUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ApprovalPayload>[]
          }
          upsert: {
            args: Prisma.ApprovalUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ApprovalPayload>
          }
          aggregate: {
            args: Prisma.ApprovalAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateApproval>
          }
          groupBy: {
            args: Prisma.ApprovalGroupByArgs<ExtArgs>
            result: $Utils.Optional<ApprovalGroupByOutputType>[]
          }
          count: {
            args: Prisma.ApprovalCountArgs<ExtArgs>
            result: $Utils.Optional<ApprovalCountAggregateOutputType> | number
          }
        }
      }
      Permission: {
        payload: Prisma.$PermissionPayload<ExtArgs>
        fields: Prisma.PermissionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PermissionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PermissionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PermissionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PermissionPayload>
          }
          findFirst: {
            args: Prisma.PermissionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PermissionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PermissionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PermissionPayload>
          }
          findMany: {
            args: Prisma.PermissionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PermissionPayload>[]
          }
          create: {
            args: Prisma.PermissionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PermissionPayload>
          }
          createMany: {
            args: Prisma.PermissionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PermissionCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PermissionPayload>[]
          }
          delete: {
            args: Prisma.PermissionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PermissionPayload>
          }
          update: {
            args: Prisma.PermissionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PermissionPayload>
          }
          deleteMany: {
            args: Prisma.PermissionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PermissionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PermissionUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PermissionPayload>[]
          }
          upsert: {
            args: Prisma.PermissionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PermissionPayload>
          }
          aggregate: {
            args: Prisma.PermissionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePermission>
          }
          groupBy: {
            args: Prisma.PermissionGroupByArgs<ExtArgs>
            result: $Utils.Optional<PermissionGroupByOutputType>[]
          }
          count: {
            args: Prisma.PermissionCountArgs<ExtArgs>
            result: $Utils.Optional<PermissionCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    directory?: DirectoryOmit
    file?: FileOmit
    version?: VersionOmit
    approval?: ApprovalOmit
    permission?: PermissionOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    files: number
    approvals: number
    approvedVersions: number
    approvedFiles: number
    createdVersions: number
    createdDirectories: number
    givenPermissions: number
    permissions: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    files?: boolean | UserCountOutputTypeCountFilesArgs
    approvals?: boolean | UserCountOutputTypeCountApprovalsArgs
    approvedVersions?: boolean | UserCountOutputTypeCountApprovedVersionsArgs
    approvedFiles?: boolean | UserCountOutputTypeCountApprovedFilesArgs
    createdVersions?: boolean | UserCountOutputTypeCountCreatedVersionsArgs
    createdDirectories?: boolean | UserCountOutputTypeCountCreatedDirectoriesArgs
    givenPermissions?: boolean | UserCountOutputTypeCountGivenPermissionsArgs
    permissions?: boolean | UserCountOutputTypeCountPermissionsArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountFilesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: FileWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountApprovalsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ApprovalWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountApprovedVersionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VersionWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountApprovedFilesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: FileWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountCreatedVersionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VersionWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountCreatedDirectoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DirectoryWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountGivenPermissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PermissionWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountPermissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PermissionWhereInput
  }


  /**
   * Count Type DirectoryCountOutputType
   */

  export type DirectoryCountOutputType = {
    children: number
    permissions: number
    files: number
  }

  export type DirectoryCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    children?: boolean | DirectoryCountOutputTypeCountChildrenArgs
    permissions?: boolean | DirectoryCountOutputTypeCountPermissionsArgs
    files?: boolean | DirectoryCountOutputTypeCountFilesArgs
  }

  // Custom InputTypes
  /**
   * DirectoryCountOutputType without action
   */
  export type DirectoryCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the DirectoryCountOutputType
     */
    select?: DirectoryCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * DirectoryCountOutputType without action
   */
  export type DirectoryCountOutputTypeCountChildrenArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DirectoryWhereInput
  }

  /**
   * DirectoryCountOutputType without action
   */
  export type DirectoryCountOutputTypeCountPermissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PermissionWhereInput
  }

  /**
   * DirectoryCountOutputType without action
   */
  export type DirectoryCountOutputTypeCountFilesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: FileWhereInput
  }


  /**
   * Count Type FileCountOutputType
   */

  export type FileCountOutputType = {
    versions: number
    permissions: number
  }

  export type FileCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    versions?: boolean | FileCountOutputTypeCountVersionsArgs
    permissions?: boolean | FileCountOutputTypeCountPermissionsArgs
  }

  // Custom InputTypes
  /**
   * FileCountOutputType without action
   */
  export type FileCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the FileCountOutputType
     */
    select?: FileCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * FileCountOutputType without action
   */
  export type FileCountOutputTypeCountVersionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VersionWhereInput
  }

  /**
   * FileCountOutputType without action
   */
  export type FileCountOutputTypeCountPermissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PermissionWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserMinAggregateOutputType = {
    id: string | null
    username: string | null
    email: string | null
    password: string | null
    role: $Enums.Role | null
  }

  export type UserMaxAggregateOutputType = {
    id: string | null
    username: string | null
    email: string | null
    password: string | null
    role: $Enums.Role | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    username: number
    email: number
    password: number
    role: number
    _all: number
  }


  export type UserMinAggregateInputType = {
    id?: true
    username?: true
    email?: true
    password?: true
    role?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    username?: true
    email?: true
    password?: true
    role?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    username?: true
    email?: true
    password?: true
    role?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: string
    username: string
    email: string | null
    password: string
    role: $Enums.Role
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    username?: boolean
    email?: boolean
    password?: boolean
    role?: boolean
    files?: boolean | User$filesArgs<ExtArgs>
    approvals?: boolean | User$approvalsArgs<ExtArgs>
    approvedVersions?: boolean | User$approvedVersionsArgs<ExtArgs>
    approvedFiles?: boolean | User$approvedFilesArgs<ExtArgs>
    createdVersions?: boolean | User$createdVersionsArgs<ExtArgs>
    createdDirectories?: boolean | User$createdDirectoriesArgs<ExtArgs>
    givenPermissions?: boolean | User$givenPermissionsArgs<ExtArgs>
    permissions?: boolean | User$permissionsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>

  export type UserSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    username?: boolean
    email?: boolean
    password?: boolean
    role?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    username?: boolean
    email?: boolean
    password?: boolean
    role?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectScalar = {
    id?: boolean
    username?: boolean
    email?: boolean
    password?: boolean
    role?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "username" | "email" | "password" | "role", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    files?: boolean | User$filesArgs<ExtArgs>
    approvals?: boolean | User$approvalsArgs<ExtArgs>
    approvedVersions?: boolean | User$approvedVersionsArgs<ExtArgs>
    approvedFiles?: boolean | User$approvedFilesArgs<ExtArgs>
    createdVersions?: boolean | User$createdVersionsArgs<ExtArgs>
    createdDirectories?: boolean | User$createdDirectoriesArgs<ExtArgs>
    givenPermissions?: boolean | User$givenPermissionsArgs<ExtArgs>
    permissions?: boolean | User$permissionsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type UserIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type UserIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      files: Prisma.$FilePayload<ExtArgs>[]
      approvals: Prisma.$ApprovalPayload<ExtArgs>[]
      approvedVersions: Prisma.$VersionPayload<ExtArgs>[]
      approvedFiles: Prisma.$FilePayload<ExtArgs>[]
      createdVersions: Prisma.$VersionPayload<ExtArgs>[]
      createdDirectories: Prisma.$DirectoryPayload<ExtArgs>[]
      givenPermissions: Prisma.$PermissionPayload<ExtArgs>[]
      permissions: Prisma.$PermissionPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      username: string
      email: string | null
      password: string
      role: $Enums.Role
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Users and returns the data saved in the database.
     * @param {UserCreateManyAndReturnArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Users and only return the `id`
     * const userWithIdOnly = await prisma.user.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends UserCreateManyAndReturnArgs>(args?: SelectSubset<T, UserCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users and returns the data updated in the database.
     * @param {UserUpdateManyAndReturnArgs} args - Arguments to update many Users.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Users and only return the `id`
     * const userWithIdOnly = await prisma.user.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends UserUpdateManyAndReturnArgs>(args: SelectSubset<T, UserUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    files<T extends User$filesArgs<ExtArgs> = {}>(args?: Subset<T, User$filesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    approvals<T extends User$approvalsArgs<ExtArgs> = {}>(args?: Subset<T, User$approvalsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    approvedVersions<T extends User$approvedVersionsArgs<ExtArgs> = {}>(args?: Subset<T, User$approvedVersionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    approvedFiles<T extends User$approvedFilesArgs<ExtArgs> = {}>(args?: Subset<T, User$approvedFilesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    createdVersions<T extends User$createdVersionsArgs<ExtArgs> = {}>(args?: Subset<T, User$createdVersionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    createdDirectories<T extends User$createdDirectoriesArgs<ExtArgs> = {}>(args?: Subset<T, User$createdDirectoriesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    givenPermissions<T extends User$givenPermissionsArgs<ExtArgs> = {}>(args?: Subset<T, User$givenPermissionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    permissions<T extends User$permissionsArgs<ExtArgs> = {}>(args?: Subset<T, User$permissionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */ 
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'String'>
    readonly username: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly password: FieldRef<"User", 'String'>
    readonly role: FieldRef<"User", 'Role'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
  }

  /**
   * User createManyAndReturn
   */
  export type UserCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User updateManyAndReturn
   */
  export type UserUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User.files
   */
  export type User$filesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    where?: FileWhereInput
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    cursor?: FileWhereUniqueInput
    take?: number
    skip?: number
    distinct?: FileScalarFieldEnum | FileScalarFieldEnum[]
  }

  /**
   * User.approvals
   */
  export type User$approvalsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
    where?: ApprovalWhereInput
    orderBy?: ApprovalOrderByWithRelationInput | ApprovalOrderByWithRelationInput[]
    cursor?: ApprovalWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ApprovalScalarFieldEnum | ApprovalScalarFieldEnum[]
  }

  /**
   * User.approvedVersions
   */
  export type User$approvedVersionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    where?: VersionWhereInput
    orderBy?: VersionOrderByWithRelationInput | VersionOrderByWithRelationInput[]
    cursor?: VersionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: VersionScalarFieldEnum | VersionScalarFieldEnum[]
  }

  /**
   * User.approvedFiles
   */
  export type User$approvedFilesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    where?: FileWhereInput
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    cursor?: FileWhereUniqueInput
    take?: number
    skip?: number
    distinct?: FileScalarFieldEnum | FileScalarFieldEnum[]
  }

  /**
   * User.createdVersions
   */
  export type User$createdVersionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    where?: VersionWhereInput
    orderBy?: VersionOrderByWithRelationInput | VersionOrderByWithRelationInput[]
    cursor?: VersionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: VersionScalarFieldEnum | VersionScalarFieldEnum[]
  }

  /**
   * User.createdDirectories
   */
  export type User$createdDirectoriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    where?: DirectoryWhereInput
    orderBy?: DirectoryOrderByWithRelationInput | DirectoryOrderByWithRelationInput[]
    cursor?: DirectoryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: DirectoryScalarFieldEnum | DirectoryScalarFieldEnum[]
  }

  /**
   * User.givenPermissions
   */
  export type User$givenPermissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    where?: PermissionWhereInput
    orderBy?: PermissionOrderByWithRelationInput | PermissionOrderByWithRelationInput[]
    cursor?: PermissionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PermissionScalarFieldEnum | PermissionScalarFieldEnum[]
  }

  /**
   * User.permissions
   */
  export type User$permissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    where?: PermissionWhereInput
    orderBy?: PermissionOrderByWithRelationInput | PermissionOrderByWithRelationInput[]
    cursor?: PermissionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PermissionScalarFieldEnum | PermissionScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model Directory
   */

  export type AggregateDirectory = {
    _count: DirectoryCountAggregateOutputType | null
    _min: DirectoryMinAggregateOutputType | null
    _max: DirectoryMaxAggregateOutputType | null
  }

  export type DirectoryMinAggregateOutputType = {
    id: string | null
    name: string | null
    path: string | null
    parentId: string | null
    createdAt: Date | null
    createdBy: string | null
  }

  export type DirectoryMaxAggregateOutputType = {
    id: string | null
    name: string | null
    path: string | null
    parentId: string | null
    createdAt: Date | null
    createdBy: string | null
  }

  export type DirectoryCountAggregateOutputType = {
    id: number
    name: number
    path: number
    parentId: number
    createdAt: number
    createdBy: number
    _all: number
  }


  export type DirectoryMinAggregateInputType = {
    id?: true
    name?: true
    path?: true
    parentId?: true
    createdAt?: true
    createdBy?: true
  }

  export type DirectoryMaxAggregateInputType = {
    id?: true
    name?: true
    path?: true
    parentId?: true
    createdAt?: true
    createdBy?: true
  }

  export type DirectoryCountAggregateInputType = {
    id?: true
    name?: true
    path?: true
    parentId?: true
    createdAt?: true
    createdBy?: true
    _all?: true
  }

  export type DirectoryAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Directory to aggregate.
     */
    where?: DirectoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Directories to fetch.
     */
    orderBy?: DirectoryOrderByWithRelationInput | DirectoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: DirectoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Directories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Directories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Directories
    **/
    _count?: true | DirectoryCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: DirectoryMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: DirectoryMaxAggregateInputType
  }

  export type GetDirectoryAggregateType<T extends DirectoryAggregateArgs> = {
        [P in keyof T & keyof AggregateDirectory]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateDirectory[P]>
      : GetScalarType<T[P], AggregateDirectory[P]>
  }




  export type DirectoryGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DirectoryWhereInput
    orderBy?: DirectoryOrderByWithAggregationInput | DirectoryOrderByWithAggregationInput[]
    by: DirectoryScalarFieldEnum[] | DirectoryScalarFieldEnum
    having?: DirectoryScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: DirectoryCountAggregateInputType | true
    _min?: DirectoryMinAggregateInputType
    _max?: DirectoryMaxAggregateInputType
  }

  export type DirectoryGroupByOutputType = {
    id: string
    name: string
    path: string
    parentId: string | null
    createdAt: Date
    createdBy: string | null
    _count: DirectoryCountAggregateOutputType | null
    _min: DirectoryMinAggregateOutputType | null
    _max: DirectoryMaxAggregateOutputType | null
  }

  type GetDirectoryGroupByPayload<T extends DirectoryGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<DirectoryGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof DirectoryGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], DirectoryGroupByOutputType[P]>
            : GetScalarType<T[P], DirectoryGroupByOutputType[P]>
        }
      >
    >


  export type DirectorySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    path?: boolean
    parentId?: boolean
    createdAt?: boolean
    createdBy?: boolean
    parent?: boolean | Directory$parentArgs<ExtArgs>
    children?: boolean | Directory$childrenArgs<ExtArgs>
    creator?: boolean | Directory$creatorArgs<ExtArgs>
    permissions?: boolean | Directory$permissionsArgs<ExtArgs>
    files?: boolean | Directory$filesArgs<ExtArgs>
    _count?: boolean | DirectoryCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["directory"]>

  export type DirectorySelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    path?: boolean
    parentId?: boolean
    createdAt?: boolean
    createdBy?: boolean
    parent?: boolean | Directory$parentArgs<ExtArgs>
    creator?: boolean | Directory$creatorArgs<ExtArgs>
  }, ExtArgs["result"]["directory"]>

  export type DirectorySelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    path?: boolean
    parentId?: boolean
    createdAt?: boolean
    createdBy?: boolean
    parent?: boolean | Directory$parentArgs<ExtArgs>
    creator?: boolean | Directory$creatorArgs<ExtArgs>
  }, ExtArgs["result"]["directory"]>

  export type DirectorySelectScalar = {
    id?: boolean
    name?: boolean
    path?: boolean
    parentId?: boolean
    createdAt?: boolean
    createdBy?: boolean
  }

  export type DirectoryOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "path" | "parentId" | "createdAt" | "createdBy", ExtArgs["result"]["directory"]>
  export type DirectoryInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    parent?: boolean | Directory$parentArgs<ExtArgs>
    children?: boolean | Directory$childrenArgs<ExtArgs>
    creator?: boolean | Directory$creatorArgs<ExtArgs>
    permissions?: boolean | Directory$permissionsArgs<ExtArgs>
    files?: boolean | Directory$filesArgs<ExtArgs>
    _count?: boolean | DirectoryCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type DirectoryIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    parent?: boolean | Directory$parentArgs<ExtArgs>
    creator?: boolean | Directory$creatorArgs<ExtArgs>
  }
  export type DirectoryIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    parent?: boolean | Directory$parentArgs<ExtArgs>
    creator?: boolean | Directory$creatorArgs<ExtArgs>
  }

  export type $DirectoryPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Directory"
    objects: {
      parent: Prisma.$DirectoryPayload<ExtArgs> | null
      children: Prisma.$DirectoryPayload<ExtArgs>[]
      creator: Prisma.$UserPayload<ExtArgs> | null
      permissions: Prisma.$PermissionPayload<ExtArgs>[]
      files: Prisma.$FilePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      path: string
      parentId: string | null
      createdAt: Date
      createdBy: string | null
    }, ExtArgs["result"]["directory"]>
    composites: {}
  }

  type DirectoryGetPayload<S extends boolean | null | undefined | DirectoryDefaultArgs> = $Result.GetResult<Prisma.$DirectoryPayload, S>

  type DirectoryCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<DirectoryFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: DirectoryCountAggregateInputType | true
    }

  export interface DirectoryDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Directory'], meta: { name: 'Directory' } }
    /**
     * Find zero or one Directory that matches the filter.
     * @param {DirectoryFindUniqueArgs} args - Arguments to find a Directory
     * @example
     * // Get one Directory
     * const directory = await prisma.directory.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends DirectoryFindUniqueArgs>(args: SelectSubset<T, DirectoryFindUniqueArgs<ExtArgs>>): Prisma__DirectoryClient<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Directory that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {DirectoryFindUniqueOrThrowArgs} args - Arguments to find a Directory
     * @example
     * // Get one Directory
     * const directory = await prisma.directory.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends DirectoryFindUniqueOrThrowArgs>(args: SelectSubset<T, DirectoryFindUniqueOrThrowArgs<ExtArgs>>): Prisma__DirectoryClient<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Directory that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DirectoryFindFirstArgs} args - Arguments to find a Directory
     * @example
     * // Get one Directory
     * const directory = await prisma.directory.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends DirectoryFindFirstArgs>(args?: SelectSubset<T, DirectoryFindFirstArgs<ExtArgs>>): Prisma__DirectoryClient<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Directory that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DirectoryFindFirstOrThrowArgs} args - Arguments to find a Directory
     * @example
     * // Get one Directory
     * const directory = await prisma.directory.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends DirectoryFindFirstOrThrowArgs>(args?: SelectSubset<T, DirectoryFindFirstOrThrowArgs<ExtArgs>>): Prisma__DirectoryClient<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Directories that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DirectoryFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Directories
     * const directories = await prisma.directory.findMany()
     * 
     * // Get first 10 Directories
     * const directories = await prisma.directory.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const directoryWithIdOnly = await prisma.directory.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends DirectoryFindManyArgs>(args?: SelectSubset<T, DirectoryFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Directory.
     * @param {DirectoryCreateArgs} args - Arguments to create a Directory.
     * @example
     * // Create one Directory
     * const Directory = await prisma.directory.create({
     *   data: {
     *     // ... data to create a Directory
     *   }
     * })
     * 
     */
    create<T extends DirectoryCreateArgs>(args: SelectSubset<T, DirectoryCreateArgs<ExtArgs>>): Prisma__DirectoryClient<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Directories.
     * @param {DirectoryCreateManyArgs} args - Arguments to create many Directories.
     * @example
     * // Create many Directories
     * const directory = await prisma.directory.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends DirectoryCreateManyArgs>(args?: SelectSubset<T, DirectoryCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Directories and returns the data saved in the database.
     * @param {DirectoryCreateManyAndReturnArgs} args - Arguments to create many Directories.
     * @example
     * // Create many Directories
     * const directory = await prisma.directory.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Directories and only return the `id`
     * const directoryWithIdOnly = await prisma.directory.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends DirectoryCreateManyAndReturnArgs>(args?: SelectSubset<T, DirectoryCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Directory.
     * @param {DirectoryDeleteArgs} args - Arguments to delete one Directory.
     * @example
     * // Delete one Directory
     * const Directory = await prisma.directory.delete({
     *   where: {
     *     // ... filter to delete one Directory
     *   }
     * })
     * 
     */
    delete<T extends DirectoryDeleteArgs>(args: SelectSubset<T, DirectoryDeleteArgs<ExtArgs>>): Prisma__DirectoryClient<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Directory.
     * @param {DirectoryUpdateArgs} args - Arguments to update one Directory.
     * @example
     * // Update one Directory
     * const directory = await prisma.directory.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends DirectoryUpdateArgs>(args: SelectSubset<T, DirectoryUpdateArgs<ExtArgs>>): Prisma__DirectoryClient<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Directories.
     * @param {DirectoryDeleteManyArgs} args - Arguments to filter Directories to delete.
     * @example
     * // Delete a few Directories
     * const { count } = await prisma.directory.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends DirectoryDeleteManyArgs>(args?: SelectSubset<T, DirectoryDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Directories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DirectoryUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Directories
     * const directory = await prisma.directory.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends DirectoryUpdateManyArgs>(args: SelectSubset<T, DirectoryUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Directories and returns the data updated in the database.
     * @param {DirectoryUpdateManyAndReturnArgs} args - Arguments to update many Directories.
     * @example
     * // Update many Directories
     * const directory = await prisma.directory.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Directories and only return the `id`
     * const directoryWithIdOnly = await prisma.directory.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends DirectoryUpdateManyAndReturnArgs>(args: SelectSubset<T, DirectoryUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Directory.
     * @param {DirectoryUpsertArgs} args - Arguments to update or create a Directory.
     * @example
     * // Update or create a Directory
     * const directory = await prisma.directory.upsert({
     *   create: {
     *     // ... data to create a Directory
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Directory we want to update
     *   }
     * })
     */
    upsert<T extends DirectoryUpsertArgs>(args: SelectSubset<T, DirectoryUpsertArgs<ExtArgs>>): Prisma__DirectoryClient<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Directories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DirectoryCountArgs} args - Arguments to filter Directories to count.
     * @example
     * // Count the number of Directories
     * const count = await prisma.directory.count({
     *   where: {
     *     // ... the filter for the Directories we want to count
     *   }
     * })
    **/
    count<T extends DirectoryCountArgs>(
      args?: Subset<T, DirectoryCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], DirectoryCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Directory.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DirectoryAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends DirectoryAggregateArgs>(args: Subset<T, DirectoryAggregateArgs>): Prisma.PrismaPromise<GetDirectoryAggregateType<T>>

    /**
     * Group by Directory.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DirectoryGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends DirectoryGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: DirectoryGroupByArgs['orderBy'] }
        : { orderBy?: DirectoryGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, DirectoryGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetDirectoryGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Directory model
   */
  readonly fields: DirectoryFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Directory.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__DirectoryClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    parent<T extends Directory$parentArgs<ExtArgs> = {}>(args?: Subset<T, Directory$parentArgs<ExtArgs>>): Prisma__DirectoryClient<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    children<T extends Directory$childrenArgs<ExtArgs> = {}>(args?: Subset<T, Directory$childrenArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    creator<T extends Directory$creatorArgs<ExtArgs> = {}>(args?: Subset<T, Directory$creatorArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    permissions<T extends Directory$permissionsArgs<ExtArgs> = {}>(args?: Subset<T, Directory$permissionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    files<T extends Directory$filesArgs<ExtArgs> = {}>(args?: Subset<T, Directory$filesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Directory model
   */ 
  interface DirectoryFieldRefs {
    readonly id: FieldRef<"Directory", 'String'>
    readonly name: FieldRef<"Directory", 'String'>
    readonly path: FieldRef<"Directory", 'String'>
    readonly parentId: FieldRef<"Directory", 'String'>
    readonly createdAt: FieldRef<"Directory", 'DateTime'>
    readonly createdBy: FieldRef<"Directory", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Directory findUnique
   */
  export type DirectoryFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    /**
     * Filter, which Directory to fetch.
     */
    where: DirectoryWhereUniqueInput
  }

  /**
   * Directory findUniqueOrThrow
   */
  export type DirectoryFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    /**
     * Filter, which Directory to fetch.
     */
    where: DirectoryWhereUniqueInput
  }

  /**
   * Directory findFirst
   */
  export type DirectoryFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    /**
     * Filter, which Directory to fetch.
     */
    where?: DirectoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Directories to fetch.
     */
    orderBy?: DirectoryOrderByWithRelationInput | DirectoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Directories.
     */
    cursor?: DirectoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Directories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Directories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Directories.
     */
    distinct?: DirectoryScalarFieldEnum | DirectoryScalarFieldEnum[]
  }

  /**
   * Directory findFirstOrThrow
   */
  export type DirectoryFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    /**
     * Filter, which Directory to fetch.
     */
    where?: DirectoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Directories to fetch.
     */
    orderBy?: DirectoryOrderByWithRelationInput | DirectoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Directories.
     */
    cursor?: DirectoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Directories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Directories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Directories.
     */
    distinct?: DirectoryScalarFieldEnum | DirectoryScalarFieldEnum[]
  }

  /**
   * Directory findMany
   */
  export type DirectoryFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    /**
     * Filter, which Directories to fetch.
     */
    where?: DirectoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Directories to fetch.
     */
    orderBy?: DirectoryOrderByWithRelationInput | DirectoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Directories.
     */
    cursor?: DirectoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Directories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Directories.
     */
    skip?: number
    distinct?: DirectoryScalarFieldEnum | DirectoryScalarFieldEnum[]
  }

  /**
   * Directory create
   */
  export type DirectoryCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    /**
     * The data needed to create a Directory.
     */
    data: XOR<DirectoryCreateInput, DirectoryUncheckedCreateInput>
  }

  /**
   * Directory createMany
   */
  export type DirectoryCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Directories.
     */
    data: DirectoryCreateManyInput | DirectoryCreateManyInput[]
  }

  /**
   * Directory createManyAndReturn
   */
  export type DirectoryCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * The data used to create many Directories.
     */
    data: DirectoryCreateManyInput | DirectoryCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Directory update
   */
  export type DirectoryUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    /**
     * The data needed to update a Directory.
     */
    data: XOR<DirectoryUpdateInput, DirectoryUncheckedUpdateInput>
    /**
     * Choose, which Directory to update.
     */
    where: DirectoryWhereUniqueInput
  }

  /**
   * Directory updateMany
   */
  export type DirectoryUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Directories.
     */
    data: XOR<DirectoryUpdateManyMutationInput, DirectoryUncheckedUpdateManyInput>
    /**
     * Filter which Directories to update
     */
    where?: DirectoryWhereInput
    /**
     * Limit how many Directories to update.
     */
    limit?: number
  }

  /**
   * Directory updateManyAndReturn
   */
  export type DirectoryUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * The data used to update Directories.
     */
    data: XOR<DirectoryUpdateManyMutationInput, DirectoryUncheckedUpdateManyInput>
    /**
     * Filter which Directories to update
     */
    where?: DirectoryWhereInput
    /**
     * Limit how many Directories to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Directory upsert
   */
  export type DirectoryUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    /**
     * The filter to search for the Directory to update in case it exists.
     */
    where: DirectoryWhereUniqueInput
    /**
     * In case the Directory found by the `where` argument doesn't exist, create a new Directory with this data.
     */
    create: XOR<DirectoryCreateInput, DirectoryUncheckedCreateInput>
    /**
     * In case the Directory was found with the provided `where` argument, update it with this data.
     */
    update: XOR<DirectoryUpdateInput, DirectoryUncheckedUpdateInput>
  }

  /**
   * Directory delete
   */
  export type DirectoryDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    /**
     * Filter which Directory to delete.
     */
    where: DirectoryWhereUniqueInput
  }

  /**
   * Directory deleteMany
   */
  export type DirectoryDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Directories to delete
     */
    where?: DirectoryWhereInput
    /**
     * Limit how many Directories to delete.
     */
    limit?: number
  }

  /**
   * Directory.parent
   */
  export type Directory$parentArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    where?: DirectoryWhereInput
  }

  /**
   * Directory.children
   */
  export type Directory$childrenArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    where?: DirectoryWhereInput
    orderBy?: DirectoryOrderByWithRelationInput | DirectoryOrderByWithRelationInput[]
    cursor?: DirectoryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: DirectoryScalarFieldEnum | DirectoryScalarFieldEnum[]
  }

  /**
   * Directory.creator
   */
  export type Directory$creatorArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }

  /**
   * Directory.permissions
   */
  export type Directory$permissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    where?: PermissionWhereInput
    orderBy?: PermissionOrderByWithRelationInput | PermissionOrderByWithRelationInput[]
    cursor?: PermissionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PermissionScalarFieldEnum | PermissionScalarFieldEnum[]
  }

  /**
   * Directory.files
   */
  export type Directory$filesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    where?: FileWhereInput
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    cursor?: FileWhereUniqueInput
    take?: number
    skip?: number
    distinct?: FileScalarFieldEnum | FileScalarFieldEnum[]
  }

  /**
   * Directory without action
   */
  export type DirectoryDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
  }


  /**
   * Model File
   */

  export type AggregateFile = {
    _count: FileCountAggregateOutputType | null
    _min: FileMinAggregateOutputType | null
    _max: FileMaxAggregateOutputType | null
  }

  export type FileMinAggregateOutputType = {
    id: string | null
    name: string | null
    description: string | null
    path: string | null
    directoryId: string | null
    directoryPath: string | null
    createdAt: Date | null
    createdBy: string | null
    approvalStatus: $Enums.ApprovalStatus | null
    approvedBy: string | null
  }

  export type FileMaxAggregateOutputType = {
    id: string | null
    name: string | null
    description: string | null
    path: string | null
    directoryId: string | null
    directoryPath: string | null
    createdAt: Date | null
    createdBy: string | null
    approvalStatus: $Enums.ApprovalStatus | null
    approvedBy: string | null
  }

  export type FileCountAggregateOutputType = {
    id: number
    name: number
    description: number
    path: number
    directoryId: number
    directoryPath: number
    createdAt: number
    createdBy: number
    approvalStatus: number
    approvedBy: number
    _all: number
  }


  export type FileMinAggregateInputType = {
    id?: true
    name?: true
    description?: true
    path?: true
    directoryId?: true
    directoryPath?: true
    createdAt?: true
    createdBy?: true
    approvalStatus?: true
    approvedBy?: true
  }

  export type FileMaxAggregateInputType = {
    id?: true
    name?: true
    description?: true
    path?: true
    directoryId?: true
    directoryPath?: true
    createdAt?: true
    createdBy?: true
    approvalStatus?: true
    approvedBy?: true
  }

  export type FileCountAggregateInputType = {
    id?: true
    name?: true
    description?: true
    path?: true
    directoryId?: true
    directoryPath?: true
    createdAt?: true
    createdBy?: true
    approvalStatus?: true
    approvedBy?: true
    _all?: true
  }

  export type FileAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which File to aggregate.
     */
    where?: FileWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Files to fetch.
     */
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: FileWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Files.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Files
    **/
    _count?: true | FileCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: FileMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: FileMaxAggregateInputType
  }

  export type GetFileAggregateType<T extends FileAggregateArgs> = {
        [P in keyof T & keyof AggregateFile]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateFile[P]>
      : GetScalarType<T[P], AggregateFile[P]>
  }




  export type FileGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: FileWhereInput
    orderBy?: FileOrderByWithAggregationInput | FileOrderByWithAggregationInput[]
    by: FileScalarFieldEnum[] | FileScalarFieldEnum
    having?: FileScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: FileCountAggregateInputType | true
    _min?: FileMinAggregateInputType
    _max?: FileMaxAggregateInputType
  }

  export type FileGroupByOutputType = {
    id: string
    name: string
    description: string | null
    path: string
    directoryId: string | null
    directoryPath: string | null
    createdAt: Date
    createdBy: string
    approvalStatus: $Enums.ApprovalStatus
    approvedBy: string | null
    _count: FileCountAggregateOutputType | null
    _min: FileMinAggregateOutputType | null
    _max: FileMaxAggregateOutputType | null
  }

  type GetFileGroupByPayload<T extends FileGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<FileGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof FileGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], FileGroupByOutputType[P]>
            : GetScalarType<T[P], FileGroupByOutputType[P]>
        }
      >
    >


  export type FileSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    path?: boolean
    directoryId?: boolean
    directoryPath?: boolean
    createdAt?: boolean
    createdBy?: boolean
    approvalStatus?: boolean
    approvedBy?: boolean
    directory?: boolean | File$directoryArgs<ExtArgs>
    creator?: boolean | UserDefaultArgs<ExtArgs>
    versions?: boolean | File$versionsArgs<ExtArgs>
    approver?: boolean | File$approverArgs<ExtArgs>
    approval?: boolean | File$approvalArgs<ExtArgs>
    permissions?: boolean | File$permissionsArgs<ExtArgs>
    _count?: boolean | FileCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["file"]>

  export type FileSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    path?: boolean
    directoryId?: boolean
    directoryPath?: boolean
    createdAt?: boolean
    createdBy?: boolean
    approvalStatus?: boolean
    approvedBy?: boolean
    directory?: boolean | File$directoryArgs<ExtArgs>
    creator?: boolean | UserDefaultArgs<ExtArgs>
    approver?: boolean | File$approverArgs<ExtArgs>
  }, ExtArgs["result"]["file"]>

  export type FileSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    path?: boolean
    directoryId?: boolean
    directoryPath?: boolean
    createdAt?: boolean
    createdBy?: boolean
    approvalStatus?: boolean
    approvedBy?: boolean
    directory?: boolean | File$directoryArgs<ExtArgs>
    creator?: boolean | UserDefaultArgs<ExtArgs>
    approver?: boolean | File$approverArgs<ExtArgs>
  }, ExtArgs["result"]["file"]>

  export type FileSelectScalar = {
    id?: boolean
    name?: boolean
    description?: boolean
    path?: boolean
    directoryId?: boolean
    directoryPath?: boolean
    createdAt?: boolean
    createdBy?: boolean
    approvalStatus?: boolean
    approvedBy?: boolean
  }

  export type FileOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "description" | "path" | "directoryId" | "directoryPath" | "createdAt" | "createdBy" | "approvalStatus" | "approvedBy", ExtArgs["result"]["file"]>
  export type FileInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    directory?: boolean | File$directoryArgs<ExtArgs>
    creator?: boolean | UserDefaultArgs<ExtArgs>
    versions?: boolean | File$versionsArgs<ExtArgs>
    approver?: boolean | File$approverArgs<ExtArgs>
    approval?: boolean | File$approvalArgs<ExtArgs>
    permissions?: boolean | File$permissionsArgs<ExtArgs>
    _count?: boolean | FileCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type FileIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    directory?: boolean | File$directoryArgs<ExtArgs>
    creator?: boolean | UserDefaultArgs<ExtArgs>
    approver?: boolean | File$approverArgs<ExtArgs>
  }
  export type FileIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    directory?: boolean | File$directoryArgs<ExtArgs>
    creator?: boolean | UserDefaultArgs<ExtArgs>
    approver?: boolean | File$approverArgs<ExtArgs>
  }

  export type $FilePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "File"
    objects: {
      directory: Prisma.$DirectoryPayload<ExtArgs> | null
      creator: Prisma.$UserPayload<ExtArgs>
      versions: Prisma.$VersionPayload<ExtArgs>[]
      approver: Prisma.$UserPayload<ExtArgs> | null
      approval: Prisma.$ApprovalPayload<ExtArgs> | null
      permissions: Prisma.$PermissionPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      description: string | null
      path: string
      directoryId: string | null
      directoryPath: string | null
      createdAt: Date
      createdBy: string
      approvalStatus: $Enums.ApprovalStatus
      approvedBy: string | null
    }, ExtArgs["result"]["file"]>
    composites: {}
  }

  type FileGetPayload<S extends boolean | null | undefined | FileDefaultArgs> = $Result.GetResult<Prisma.$FilePayload, S>

  type FileCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<FileFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: FileCountAggregateInputType | true
    }

  export interface FileDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['File'], meta: { name: 'File' } }
    /**
     * Find zero or one File that matches the filter.
     * @param {FileFindUniqueArgs} args - Arguments to find a File
     * @example
     * // Get one File
     * const file = await prisma.file.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends FileFindUniqueArgs>(args: SelectSubset<T, FileFindUniqueArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one File that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {FileFindUniqueOrThrowArgs} args - Arguments to find a File
     * @example
     * // Get one File
     * const file = await prisma.file.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends FileFindUniqueOrThrowArgs>(args: SelectSubset<T, FileFindUniqueOrThrowArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first File that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileFindFirstArgs} args - Arguments to find a File
     * @example
     * // Get one File
     * const file = await prisma.file.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends FileFindFirstArgs>(args?: SelectSubset<T, FileFindFirstArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first File that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileFindFirstOrThrowArgs} args - Arguments to find a File
     * @example
     * // Get one File
     * const file = await prisma.file.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends FileFindFirstOrThrowArgs>(args?: SelectSubset<T, FileFindFirstOrThrowArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Files that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Files
     * const files = await prisma.file.findMany()
     * 
     * // Get first 10 Files
     * const files = await prisma.file.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const fileWithIdOnly = await prisma.file.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends FileFindManyArgs>(args?: SelectSubset<T, FileFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a File.
     * @param {FileCreateArgs} args - Arguments to create a File.
     * @example
     * // Create one File
     * const File = await prisma.file.create({
     *   data: {
     *     // ... data to create a File
     *   }
     * })
     * 
     */
    create<T extends FileCreateArgs>(args: SelectSubset<T, FileCreateArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Files.
     * @param {FileCreateManyArgs} args - Arguments to create many Files.
     * @example
     * // Create many Files
     * const file = await prisma.file.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends FileCreateManyArgs>(args?: SelectSubset<T, FileCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Files and returns the data saved in the database.
     * @param {FileCreateManyAndReturnArgs} args - Arguments to create many Files.
     * @example
     * // Create many Files
     * const file = await prisma.file.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Files and only return the `id`
     * const fileWithIdOnly = await prisma.file.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends FileCreateManyAndReturnArgs>(args?: SelectSubset<T, FileCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a File.
     * @param {FileDeleteArgs} args - Arguments to delete one File.
     * @example
     * // Delete one File
     * const File = await prisma.file.delete({
     *   where: {
     *     // ... filter to delete one File
     *   }
     * })
     * 
     */
    delete<T extends FileDeleteArgs>(args: SelectSubset<T, FileDeleteArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one File.
     * @param {FileUpdateArgs} args - Arguments to update one File.
     * @example
     * // Update one File
     * const file = await prisma.file.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends FileUpdateArgs>(args: SelectSubset<T, FileUpdateArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Files.
     * @param {FileDeleteManyArgs} args - Arguments to filter Files to delete.
     * @example
     * // Delete a few Files
     * const { count } = await prisma.file.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends FileDeleteManyArgs>(args?: SelectSubset<T, FileDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Files.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Files
     * const file = await prisma.file.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends FileUpdateManyArgs>(args: SelectSubset<T, FileUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Files and returns the data updated in the database.
     * @param {FileUpdateManyAndReturnArgs} args - Arguments to update many Files.
     * @example
     * // Update many Files
     * const file = await prisma.file.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Files and only return the `id`
     * const fileWithIdOnly = await prisma.file.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends FileUpdateManyAndReturnArgs>(args: SelectSubset<T, FileUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one File.
     * @param {FileUpsertArgs} args - Arguments to update or create a File.
     * @example
     * // Update or create a File
     * const file = await prisma.file.upsert({
     *   create: {
     *     // ... data to create a File
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the File we want to update
     *   }
     * })
     */
    upsert<T extends FileUpsertArgs>(args: SelectSubset<T, FileUpsertArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Files.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileCountArgs} args - Arguments to filter Files to count.
     * @example
     * // Count the number of Files
     * const count = await prisma.file.count({
     *   where: {
     *     // ... the filter for the Files we want to count
     *   }
     * })
    **/
    count<T extends FileCountArgs>(
      args?: Subset<T, FileCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], FileCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a File.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends FileAggregateArgs>(args: Subset<T, FileAggregateArgs>): Prisma.PrismaPromise<GetFileAggregateType<T>>

    /**
     * Group by File.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FileGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends FileGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: FileGroupByArgs['orderBy'] }
        : { orderBy?: FileGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, FileGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetFileGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the File model
   */
  readonly fields: FileFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for File.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__FileClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    directory<T extends File$directoryArgs<ExtArgs> = {}>(args?: Subset<T, File$directoryArgs<ExtArgs>>): Prisma__DirectoryClient<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    creator<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    versions<T extends File$versionsArgs<ExtArgs> = {}>(args?: Subset<T, File$versionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    approver<T extends File$approverArgs<ExtArgs> = {}>(args?: Subset<T, File$approverArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    approval<T extends File$approvalArgs<ExtArgs> = {}>(args?: Subset<T, File$approvalArgs<ExtArgs>>): Prisma__ApprovalClient<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    permissions<T extends File$permissionsArgs<ExtArgs> = {}>(args?: Subset<T, File$permissionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the File model
   */ 
  interface FileFieldRefs {
    readonly id: FieldRef<"File", 'String'>
    readonly name: FieldRef<"File", 'String'>
    readonly description: FieldRef<"File", 'String'>
    readonly path: FieldRef<"File", 'String'>
    readonly directoryId: FieldRef<"File", 'String'>
    readonly directoryPath: FieldRef<"File", 'String'>
    readonly createdAt: FieldRef<"File", 'DateTime'>
    readonly createdBy: FieldRef<"File", 'String'>
    readonly approvalStatus: FieldRef<"File", 'ApprovalStatus'>
    readonly approvedBy: FieldRef<"File", 'String'>
  }
    

  // Custom InputTypes
  /**
   * File findUnique
   */
  export type FileFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter, which File to fetch.
     */
    where: FileWhereUniqueInput
  }

  /**
   * File findUniqueOrThrow
   */
  export type FileFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter, which File to fetch.
     */
    where: FileWhereUniqueInput
  }

  /**
   * File findFirst
   */
  export type FileFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter, which File to fetch.
     */
    where?: FileWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Files to fetch.
     */
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Files.
     */
    cursor?: FileWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Files.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Files.
     */
    distinct?: FileScalarFieldEnum | FileScalarFieldEnum[]
  }

  /**
   * File findFirstOrThrow
   */
  export type FileFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter, which File to fetch.
     */
    where?: FileWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Files to fetch.
     */
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Files.
     */
    cursor?: FileWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Files.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Files.
     */
    distinct?: FileScalarFieldEnum | FileScalarFieldEnum[]
  }

  /**
   * File findMany
   */
  export type FileFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter, which Files to fetch.
     */
    where?: FileWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Files to fetch.
     */
    orderBy?: FileOrderByWithRelationInput | FileOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Files.
     */
    cursor?: FileWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Files from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Files.
     */
    skip?: number
    distinct?: FileScalarFieldEnum | FileScalarFieldEnum[]
  }

  /**
   * File create
   */
  export type FileCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * The data needed to create a File.
     */
    data: XOR<FileCreateInput, FileUncheckedCreateInput>
  }

  /**
   * File createMany
   */
  export type FileCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Files.
     */
    data: FileCreateManyInput | FileCreateManyInput[]
  }

  /**
   * File createManyAndReturn
   */
  export type FileCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * The data used to create many Files.
     */
    data: FileCreateManyInput | FileCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * File update
   */
  export type FileUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * The data needed to update a File.
     */
    data: XOR<FileUpdateInput, FileUncheckedUpdateInput>
    /**
     * Choose, which File to update.
     */
    where: FileWhereUniqueInput
  }

  /**
   * File updateMany
   */
  export type FileUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Files.
     */
    data: XOR<FileUpdateManyMutationInput, FileUncheckedUpdateManyInput>
    /**
     * Filter which Files to update
     */
    where?: FileWhereInput
    /**
     * Limit how many Files to update.
     */
    limit?: number
  }

  /**
   * File updateManyAndReturn
   */
  export type FileUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * The data used to update Files.
     */
    data: XOR<FileUpdateManyMutationInput, FileUncheckedUpdateManyInput>
    /**
     * Filter which Files to update
     */
    where?: FileWhereInput
    /**
     * Limit how many Files to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * File upsert
   */
  export type FileUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * The filter to search for the File to update in case it exists.
     */
    where: FileWhereUniqueInput
    /**
     * In case the File found by the `where` argument doesn't exist, create a new File with this data.
     */
    create: XOR<FileCreateInput, FileUncheckedCreateInput>
    /**
     * In case the File was found with the provided `where` argument, update it with this data.
     */
    update: XOR<FileUpdateInput, FileUncheckedUpdateInput>
  }

  /**
   * File delete
   */
  export type FileDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    /**
     * Filter which File to delete.
     */
    where: FileWhereUniqueInput
  }

  /**
   * File deleteMany
   */
  export type FileDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Files to delete
     */
    where?: FileWhereInput
    /**
     * Limit how many Files to delete.
     */
    limit?: number
  }

  /**
   * File.directory
   */
  export type File$directoryArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    where?: DirectoryWhereInput
  }

  /**
   * File.versions
   */
  export type File$versionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    where?: VersionWhereInput
    orderBy?: VersionOrderByWithRelationInput | VersionOrderByWithRelationInput[]
    cursor?: VersionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: VersionScalarFieldEnum | VersionScalarFieldEnum[]
  }

  /**
   * File.approver
   */
  export type File$approverArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }

  /**
   * File.approval
   */
  export type File$approvalArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
    where?: ApprovalWhereInput
  }

  /**
   * File.permissions
   */
  export type File$permissionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    where?: PermissionWhereInput
    orderBy?: PermissionOrderByWithRelationInput | PermissionOrderByWithRelationInput[]
    cursor?: PermissionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PermissionScalarFieldEnum | PermissionScalarFieldEnum[]
  }

  /**
   * File without action
   */
  export type FileDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
  }


  /**
   * Model Version
   */

  export type AggregateVersion = {
    _count: VersionCountAggregateOutputType | null
    _avg: VersionAvgAggregateOutputType | null
    _sum: VersionSumAggregateOutputType | null
    _min: VersionMinAggregateOutputType | null
    _max: VersionMaxAggregateOutputType | null
  }

  export type VersionAvgAggregateOutputType = {
    versionNumber: number | null
  }

  export type VersionSumAggregateOutputType = {
    versionNumber: number | null
  }

  export type VersionMinAggregateOutputType = {
    id: string | null
    fileId: string | null
    filePath: string | null
    versionNumber: number | null
    createdAt: Date | null
    description: string | null
    createdBy: string | null
    approvedBy: string | null
    approvedAt: Date | null
  }

  export type VersionMaxAggregateOutputType = {
    id: string | null
    fileId: string | null
    filePath: string | null
    versionNumber: number | null
    createdAt: Date | null
    description: string | null
    createdBy: string | null
    approvedBy: string | null
    approvedAt: Date | null
  }

  export type VersionCountAggregateOutputType = {
    id: number
    fileId: number
    filePath: number
    versionNumber: number
    createdAt: number
    description: number
    createdBy: number
    approvedBy: number
    approvedAt: number
    _all: number
  }


  export type VersionAvgAggregateInputType = {
    versionNumber?: true
  }

  export type VersionSumAggregateInputType = {
    versionNumber?: true
  }

  export type VersionMinAggregateInputType = {
    id?: true
    fileId?: true
    filePath?: true
    versionNumber?: true
    createdAt?: true
    description?: true
    createdBy?: true
    approvedBy?: true
    approvedAt?: true
  }

  export type VersionMaxAggregateInputType = {
    id?: true
    fileId?: true
    filePath?: true
    versionNumber?: true
    createdAt?: true
    description?: true
    createdBy?: true
    approvedBy?: true
    approvedAt?: true
  }

  export type VersionCountAggregateInputType = {
    id?: true
    fileId?: true
    filePath?: true
    versionNumber?: true
    createdAt?: true
    description?: true
    createdBy?: true
    approvedBy?: true
    approvedAt?: true
    _all?: true
  }

  export type VersionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Version to aggregate.
     */
    where?: VersionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Versions to fetch.
     */
    orderBy?: VersionOrderByWithRelationInput | VersionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: VersionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Versions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Versions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Versions
    **/
    _count?: true | VersionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: VersionAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: VersionSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VersionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VersionMaxAggregateInputType
  }

  export type GetVersionAggregateType<T extends VersionAggregateArgs> = {
        [P in keyof T & keyof AggregateVersion]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVersion[P]>
      : GetScalarType<T[P], AggregateVersion[P]>
  }




  export type VersionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VersionWhereInput
    orderBy?: VersionOrderByWithAggregationInput | VersionOrderByWithAggregationInput[]
    by: VersionScalarFieldEnum[] | VersionScalarFieldEnum
    having?: VersionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VersionCountAggregateInputType | true
    _avg?: VersionAvgAggregateInputType
    _sum?: VersionSumAggregateInputType
    _min?: VersionMinAggregateInputType
    _max?: VersionMaxAggregateInputType
  }

  export type VersionGroupByOutputType = {
    id: string
    fileId: string
    filePath: string
    versionNumber: number
    createdAt: Date
    description: string | null
    createdBy: string
    approvedBy: string | null
    approvedAt: Date | null
    _count: VersionCountAggregateOutputType | null
    _avg: VersionAvgAggregateOutputType | null
    _sum: VersionSumAggregateOutputType | null
    _min: VersionMinAggregateOutputType | null
    _max: VersionMaxAggregateOutputType | null
  }

  type GetVersionGroupByPayload<T extends VersionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<VersionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VersionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VersionGroupByOutputType[P]>
            : GetScalarType<T[P], VersionGroupByOutputType[P]>
        }
      >
    >


  export type VersionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    fileId?: boolean
    filePath?: boolean
    versionNumber?: boolean
    createdAt?: boolean
    description?: boolean
    createdBy?: boolean
    approvedBy?: boolean
    approvedAt?: boolean
    creator?: boolean | UserDefaultArgs<ExtArgs>
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Version$approverArgs<ExtArgs>
  }, ExtArgs["result"]["version"]>

  export type VersionSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    fileId?: boolean
    filePath?: boolean
    versionNumber?: boolean
    createdAt?: boolean
    description?: boolean
    createdBy?: boolean
    approvedBy?: boolean
    approvedAt?: boolean
    creator?: boolean | UserDefaultArgs<ExtArgs>
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Version$approverArgs<ExtArgs>
  }, ExtArgs["result"]["version"]>

  export type VersionSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    fileId?: boolean
    filePath?: boolean
    versionNumber?: boolean
    createdAt?: boolean
    description?: boolean
    createdBy?: boolean
    approvedBy?: boolean
    approvedAt?: boolean
    creator?: boolean | UserDefaultArgs<ExtArgs>
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Version$approverArgs<ExtArgs>
  }, ExtArgs["result"]["version"]>

  export type VersionSelectScalar = {
    id?: boolean
    fileId?: boolean
    filePath?: boolean
    versionNumber?: boolean
    createdAt?: boolean
    description?: boolean
    createdBy?: boolean
    approvedBy?: boolean
    approvedAt?: boolean
  }

  export type VersionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "fileId" | "filePath" | "versionNumber" | "createdAt" | "description" | "createdBy" | "approvedBy" | "approvedAt", ExtArgs["result"]["version"]>
  export type VersionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    creator?: boolean | UserDefaultArgs<ExtArgs>
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Version$approverArgs<ExtArgs>
  }
  export type VersionIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    creator?: boolean | UserDefaultArgs<ExtArgs>
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Version$approverArgs<ExtArgs>
  }
  export type VersionIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    creator?: boolean | UserDefaultArgs<ExtArgs>
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Version$approverArgs<ExtArgs>
  }

  export type $VersionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Version"
    objects: {
      creator: Prisma.$UserPayload<ExtArgs>
      file: Prisma.$FilePayload<ExtArgs>
      approver: Prisma.$UserPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      fileId: string
      filePath: string
      versionNumber: number
      createdAt: Date
      description: string | null
      createdBy: string
      approvedBy: string | null
      approvedAt: Date | null
    }, ExtArgs["result"]["version"]>
    composites: {}
  }

  type VersionGetPayload<S extends boolean | null | undefined | VersionDefaultArgs> = $Result.GetResult<Prisma.$VersionPayload, S>

  type VersionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<VersionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: VersionCountAggregateInputType | true
    }

  export interface VersionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Version'], meta: { name: 'Version' } }
    /**
     * Find zero or one Version that matches the filter.
     * @param {VersionFindUniqueArgs} args - Arguments to find a Version
     * @example
     * // Get one Version
     * const version = await prisma.version.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends VersionFindUniqueArgs>(args: SelectSubset<T, VersionFindUniqueArgs<ExtArgs>>): Prisma__VersionClient<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Version that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {VersionFindUniqueOrThrowArgs} args - Arguments to find a Version
     * @example
     * // Get one Version
     * const version = await prisma.version.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends VersionFindUniqueOrThrowArgs>(args: SelectSubset<T, VersionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__VersionClient<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Version that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VersionFindFirstArgs} args - Arguments to find a Version
     * @example
     * // Get one Version
     * const version = await prisma.version.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends VersionFindFirstArgs>(args?: SelectSubset<T, VersionFindFirstArgs<ExtArgs>>): Prisma__VersionClient<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Version that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VersionFindFirstOrThrowArgs} args - Arguments to find a Version
     * @example
     * // Get one Version
     * const version = await prisma.version.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends VersionFindFirstOrThrowArgs>(args?: SelectSubset<T, VersionFindFirstOrThrowArgs<ExtArgs>>): Prisma__VersionClient<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Versions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VersionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Versions
     * const versions = await prisma.version.findMany()
     * 
     * // Get first 10 Versions
     * const versions = await prisma.version.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const versionWithIdOnly = await prisma.version.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends VersionFindManyArgs>(args?: SelectSubset<T, VersionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Version.
     * @param {VersionCreateArgs} args - Arguments to create a Version.
     * @example
     * // Create one Version
     * const Version = await prisma.version.create({
     *   data: {
     *     // ... data to create a Version
     *   }
     * })
     * 
     */
    create<T extends VersionCreateArgs>(args: SelectSubset<T, VersionCreateArgs<ExtArgs>>): Prisma__VersionClient<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Versions.
     * @param {VersionCreateManyArgs} args - Arguments to create many Versions.
     * @example
     * // Create many Versions
     * const version = await prisma.version.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends VersionCreateManyArgs>(args?: SelectSubset<T, VersionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Versions and returns the data saved in the database.
     * @param {VersionCreateManyAndReturnArgs} args - Arguments to create many Versions.
     * @example
     * // Create many Versions
     * const version = await prisma.version.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Versions and only return the `id`
     * const versionWithIdOnly = await prisma.version.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends VersionCreateManyAndReturnArgs>(args?: SelectSubset<T, VersionCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Version.
     * @param {VersionDeleteArgs} args - Arguments to delete one Version.
     * @example
     * // Delete one Version
     * const Version = await prisma.version.delete({
     *   where: {
     *     // ... filter to delete one Version
     *   }
     * })
     * 
     */
    delete<T extends VersionDeleteArgs>(args: SelectSubset<T, VersionDeleteArgs<ExtArgs>>): Prisma__VersionClient<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Version.
     * @param {VersionUpdateArgs} args - Arguments to update one Version.
     * @example
     * // Update one Version
     * const version = await prisma.version.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends VersionUpdateArgs>(args: SelectSubset<T, VersionUpdateArgs<ExtArgs>>): Prisma__VersionClient<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Versions.
     * @param {VersionDeleteManyArgs} args - Arguments to filter Versions to delete.
     * @example
     * // Delete a few Versions
     * const { count } = await prisma.version.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends VersionDeleteManyArgs>(args?: SelectSubset<T, VersionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Versions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VersionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Versions
     * const version = await prisma.version.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends VersionUpdateManyArgs>(args: SelectSubset<T, VersionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Versions and returns the data updated in the database.
     * @param {VersionUpdateManyAndReturnArgs} args - Arguments to update many Versions.
     * @example
     * // Update many Versions
     * const version = await prisma.version.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Versions and only return the `id`
     * const versionWithIdOnly = await prisma.version.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends VersionUpdateManyAndReturnArgs>(args: SelectSubset<T, VersionUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Version.
     * @param {VersionUpsertArgs} args - Arguments to update or create a Version.
     * @example
     * // Update or create a Version
     * const version = await prisma.version.upsert({
     *   create: {
     *     // ... data to create a Version
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Version we want to update
     *   }
     * })
     */
    upsert<T extends VersionUpsertArgs>(args: SelectSubset<T, VersionUpsertArgs<ExtArgs>>): Prisma__VersionClient<$Result.GetResult<Prisma.$VersionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Versions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VersionCountArgs} args - Arguments to filter Versions to count.
     * @example
     * // Count the number of Versions
     * const count = await prisma.version.count({
     *   where: {
     *     // ... the filter for the Versions we want to count
     *   }
     * })
    **/
    count<T extends VersionCountArgs>(
      args?: Subset<T, VersionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VersionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Version.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VersionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VersionAggregateArgs>(args: Subset<T, VersionAggregateArgs>): Prisma.PrismaPromise<GetVersionAggregateType<T>>

    /**
     * Group by Version.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VersionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VersionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VersionGroupByArgs['orderBy'] }
        : { orderBy?: VersionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VersionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVersionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Version model
   */
  readonly fields: VersionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Version.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__VersionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    creator<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    file<T extends FileDefaultArgs<ExtArgs> = {}>(args?: Subset<T, FileDefaultArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    approver<T extends Version$approverArgs<ExtArgs> = {}>(args?: Subset<T, Version$approverArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Version model
   */ 
  interface VersionFieldRefs {
    readonly id: FieldRef<"Version", 'String'>
    readonly fileId: FieldRef<"Version", 'String'>
    readonly filePath: FieldRef<"Version", 'String'>
    readonly versionNumber: FieldRef<"Version", 'Int'>
    readonly createdAt: FieldRef<"Version", 'DateTime'>
    readonly description: FieldRef<"Version", 'String'>
    readonly createdBy: FieldRef<"Version", 'String'>
    readonly approvedBy: FieldRef<"Version", 'String'>
    readonly approvedAt: FieldRef<"Version", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Version findUnique
   */
  export type VersionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    /**
     * Filter, which Version to fetch.
     */
    where: VersionWhereUniqueInput
  }

  /**
   * Version findUniqueOrThrow
   */
  export type VersionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    /**
     * Filter, which Version to fetch.
     */
    where: VersionWhereUniqueInput
  }

  /**
   * Version findFirst
   */
  export type VersionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    /**
     * Filter, which Version to fetch.
     */
    where?: VersionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Versions to fetch.
     */
    orderBy?: VersionOrderByWithRelationInput | VersionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Versions.
     */
    cursor?: VersionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Versions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Versions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Versions.
     */
    distinct?: VersionScalarFieldEnum | VersionScalarFieldEnum[]
  }

  /**
   * Version findFirstOrThrow
   */
  export type VersionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    /**
     * Filter, which Version to fetch.
     */
    where?: VersionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Versions to fetch.
     */
    orderBy?: VersionOrderByWithRelationInput | VersionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Versions.
     */
    cursor?: VersionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Versions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Versions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Versions.
     */
    distinct?: VersionScalarFieldEnum | VersionScalarFieldEnum[]
  }

  /**
   * Version findMany
   */
  export type VersionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    /**
     * Filter, which Versions to fetch.
     */
    where?: VersionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Versions to fetch.
     */
    orderBy?: VersionOrderByWithRelationInput | VersionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Versions.
     */
    cursor?: VersionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Versions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Versions.
     */
    skip?: number
    distinct?: VersionScalarFieldEnum | VersionScalarFieldEnum[]
  }

  /**
   * Version create
   */
  export type VersionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    /**
     * The data needed to create a Version.
     */
    data: XOR<VersionCreateInput, VersionUncheckedCreateInput>
  }

  /**
   * Version createMany
   */
  export type VersionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Versions.
     */
    data: VersionCreateManyInput | VersionCreateManyInput[]
  }

  /**
   * Version createManyAndReturn
   */
  export type VersionCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * The data used to create many Versions.
     */
    data: VersionCreateManyInput | VersionCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Version update
   */
  export type VersionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    /**
     * The data needed to update a Version.
     */
    data: XOR<VersionUpdateInput, VersionUncheckedUpdateInput>
    /**
     * Choose, which Version to update.
     */
    where: VersionWhereUniqueInput
  }

  /**
   * Version updateMany
   */
  export type VersionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Versions.
     */
    data: XOR<VersionUpdateManyMutationInput, VersionUncheckedUpdateManyInput>
    /**
     * Filter which Versions to update
     */
    where?: VersionWhereInput
    /**
     * Limit how many Versions to update.
     */
    limit?: number
  }

  /**
   * Version updateManyAndReturn
   */
  export type VersionUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * The data used to update Versions.
     */
    data: XOR<VersionUpdateManyMutationInput, VersionUncheckedUpdateManyInput>
    /**
     * Filter which Versions to update
     */
    where?: VersionWhereInput
    /**
     * Limit how many Versions to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Version upsert
   */
  export type VersionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    /**
     * The filter to search for the Version to update in case it exists.
     */
    where: VersionWhereUniqueInput
    /**
     * In case the Version found by the `where` argument doesn't exist, create a new Version with this data.
     */
    create: XOR<VersionCreateInput, VersionUncheckedCreateInput>
    /**
     * In case the Version was found with the provided `where` argument, update it with this data.
     */
    update: XOR<VersionUpdateInput, VersionUncheckedUpdateInput>
  }

  /**
   * Version delete
   */
  export type VersionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
    /**
     * Filter which Version to delete.
     */
    where: VersionWhereUniqueInput
  }

  /**
   * Version deleteMany
   */
  export type VersionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Versions to delete
     */
    where?: VersionWhereInput
    /**
     * Limit how many Versions to delete.
     */
    limit?: number
  }

  /**
   * Version.approver
   */
  export type Version$approverArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }

  /**
   * Version without action
   */
  export type VersionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Version
     */
    select?: VersionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Version
     */
    omit?: VersionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VersionInclude<ExtArgs> | null
  }


  /**
   * Model Approval
   */

  export type AggregateApproval = {
    _count: ApprovalCountAggregateOutputType | null
    _min: ApprovalMinAggregateOutputType | null
    _max: ApprovalMaxAggregateOutputType | null
  }

  export type ApprovalMinAggregateOutputType = {
    id: string | null
    fileId: string | null
    approvedBy: string | null
    approvedAt: Date | null
  }

  export type ApprovalMaxAggregateOutputType = {
    id: string | null
    fileId: string | null
    approvedBy: string | null
    approvedAt: Date | null
  }

  export type ApprovalCountAggregateOutputType = {
    id: number
    fileId: number
    approvedBy: number
    approvedAt: number
    _all: number
  }


  export type ApprovalMinAggregateInputType = {
    id?: true
    fileId?: true
    approvedBy?: true
    approvedAt?: true
  }

  export type ApprovalMaxAggregateInputType = {
    id?: true
    fileId?: true
    approvedBy?: true
    approvedAt?: true
  }

  export type ApprovalCountAggregateInputType = {
    id?: true
    fileId?: true
    approvedBy?: true
    approvedAt?: true
    _all?: true
  }

  export type ApprovalAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Approval to aggregate.
     */
    where?: ApprovalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Approvals to fetch.
     */
    orderBy?: ApprovalOrderByWithRelationInput | ApprovalOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ApprovalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Approvals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Approvals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Approvals
    **/
    _count?: true | ApprovalCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ApprovalMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ApprovalMaxAggregateInputType
  }

  export type GetApprovalAggregateType<T extends ApprovalAggregateArgs> = {
        [P in keyof T & keyof AggregateApproval]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateApproval[P]>
      : GetScalarType<T[P], AggregateApproval[P]>
  }




  export type ApprovalGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ApprovalWhereInput
    orderBy?: ApprovalOrderByWithAggregationInput | ApprovalOrderByWithAggregationInput[]
    by: ApprovalScalarFieldEnum[] | ApprovalScalarFieldEnum
    having?: ApprovalScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ApprovalCountAggregateInputType | true
    _min?: ApprovalMinAggregateInputType
    _max?: ApprovalMaxAggregateInputType
  }

  export type ApprovalGroupByOutputType = {
    id: string
    fileId: string
    approvedBy: string | null
    approvedAt: Date | null
    _count: ApprovalCountAggregateOutputType | null
    _min: ApprovalMinAggregateOutputType | null
    _max: ApprovalMaxAggregateOutputType | null
  }

  type GetApprovalGroupByPayload<T extends ApprovalGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ApprovalGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ApprovalGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ApprovalGroupByOutputType[P]>
            : GetScalarType<T[P], ApprovalGroupByOutputType[P]>
        }
      >
    >


  export type ApprovalSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    fileId?: boolean
    approvedBy?: boolean
    approvedAt?: boolean
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Approval$approverArgs<ExtArgs>
  }, ExtArgs["result"]["approval"]>

  export type ApprovalSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    fileId?: boolean
    approvedBy?: boolean
    approvedAt?: boolean
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Approval$approverArgs<ExtArgs>
  }, ExtArgs["result"]["approval"]>

  export type ApprovalSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    fileId?: boolean
    approvedBy?: boolean
    approvedAt?: boolean
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Approval$approverArgs<ExtArgs>
  }, ExtArgs["result"]["approval"]>

  export type ApprovalSelectScalar = {
    id?: boolean
    fileId?: boolean
    approvedBy?: boolean
    approvedAt?: boolean
  }

  export type ApprovalOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "fileId" | "approvedBy" | "approvedAt", ExtArgs["result"]["approval"]>
  export type ApprovalInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Approval$approverArgs<ExtArgs>
  }
  export type ApprovalIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Approval$approverArgs<ExtArgs>
  }
  export type ApprovalIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    file?: boolean | FileDefaultArgs<ExtArgs>
    approver?: boolean | Approval$approverArgs<ExtArgs>
  }

  export type $ApprovalPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Approval"
    objects: {
      file: Prisma.$FilePayload<ExtArgs>
      approver: Prisma.$UserPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      fileId: string
      approvedBy: string | null
      approvedAt: Date | null
    }, ExtArgs["result"]["approval"]>
    composites: {}
  }

  type ApprovalGetPayload<S extends boolean | null | undefined | ApprovalDefaultArgs> = $Result.GetResult<Prisma.$ApprovalPayload, S>

  type ApprovalCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ApprovalFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ApprovalCountAggregateInputType | true
    }

  export interface ApprovalDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Approval'], meta: { name: 'Approval' } }
    /**
     * Find zero or one Approval that matches the filter.
     * @param {ApprovalFindUniqueArgs} args - Arguments to find a Approval
     * @example
     * // Get one Approval
     * const approval = await prisma.approval.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ApprovalFindUniqueArgs>(args: SelectSubset<T, ApprovalFindUniqueArgs<ExtArgs>>): Prisma__ApprovalClient<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Approval that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ApprovalFindUniqueOrThrowArgs} args - Arguments to find a Approval
     * @example
     * // Get one Approval
     * const approval = await prisma.approval.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ApprovalFindUniqueOrThrowArgs>(args: SelectSubset<T, ApprovalFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ApprovalClient<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Approval that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovalFindFirstArgs} args - Arguments to find a Approval
     * @example
     * // Get one Approval
     * const approval = await prisma.approval.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ApprovalFindFirstArgs>(args?: SelectSubset<T, ApprovalFindFirstArgs<ExtArgs>>): Prisma__ApprovalClient<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Approval that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovalFindFirstOrThrowArgs} args - Arguments to find a Approval
     * @example
     * // Get one Approval
     * const approval = await prisma.approval.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ApprovalFindFirstOrThrowArgs>(args?: SelectSubset<T, ApprovalFindFirstOrThrowArgs<ExtArgs>>): Prisma__ApprovalClient<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Approvals that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovalFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Approvals
     * const approvals = await prisma.approval.findMany()
     * 
     * // Get first 10 Approvals
     * const approvals = await prisma.approval.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const approvalWithIdOnly = await prisma.approval.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ApprovalFindManyArgs>(args?: SelectSubset<T, ApprovalFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Approval.
     * @param {ApprovalCreateArgs} args - Arguments to create a Approval.
     * @example
     * // Create one Approval
     * const Approval = await prisma.approval.create({
     *   data: {
     *     // ... data to create a Approval
     *   }
     * })
     * 
     */
    create<T extends ApprovalCreateArgs>(args: SelectSubset<T, ApprovalCreateArgs<ExtArgs>>): Prisma__ApprovalClient<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Approvals.
     * @param {ApprovalCreateManyArgs} args - Arguments to create many Approvals.
     * @example
     * // Create many Approvals
     * const approval = await prisma.approval.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ApprovalCreateManyArgs>(args?: SelectSubset<T, ApprovalCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Approvals and returns the data saved in the database.
     * @param {ApprovalCreateManyAndReturnArgs} args - Arguments to create many Approvals.
     * @example
     * // Create many Approvals
     * const approval = await prisma.approval.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Approvals and only return the `id`
     * const approvalWithIdOnly = await prisma.approval.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ApprovalCreateManyAndReturnArgs>(args?: SelectSubset<T, ApprovalCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Approval.
     * @param {ApprovalDeleteArgs} args - Arguments to delete one Approval.
     * @example
     * // Delete one Approval
     * const Approval = await prisma.approval.delete({
     *   where: {
     *     // ... filter to delete one Approval
     *   }
     * })
     * 
     */
    delete<T extends ApprovalDeleteArgs>(args: SelectSubset<T, ApprovalDeleteArgs<ExtArgs>>): Prisma__ApprovalClient<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Approval.
     * @param {ApprovalUpdateArgs} args - Arguments to update one Approval.
     * @example
     * // Update one Approval
     * const approval = await prisma.approval.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ApprovalUpdateArgs>(args: SelectSubset<T, ApprovalUpdateArgs<ExtArgs>>): Prisma__ApprovalClient<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Approvals.
     * @param {ApprovalDeleteManyArgs} args - Arguments to filter Approvals to delete.
     * @example
     * // Delete a few Approvals
     * const { count } = await prisma.approval.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ApprovalDeleteManyArgs>(args?: SelectSubset<T, ApprovalDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Approvals.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovalUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Approvals
     * const approval = await prisma.approval.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ApprovalUpdateManyArgs>(args: SelectSubset<T, ApprovalUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Approvals and returns the data updated in the database.
     * @param {ApprovalUpdateManyAndReturnArgs} args - Arguments to update many Approvals.
     * @example
     * // Update many Approvals
     * const approval = await prisma.approval.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Approvals and only return the `id`
     * const approvalWithIdOnly = await prisma.approval.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ApprovalUpdateManyAndReturnArgs>(args: SelectSubset<T, ApprovalUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Approval.
     * @param {ApprovalUpsertArgs} args - Arguments to update or create a Approval.
     * @example
     * // Update or create a Approval
     * const approval = await prisma.approval.upsert({
     *   create: {
     *     // ... data to create a Approval
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Approval we want to update
     *   }
     * })
     */
    upsert<T extends ApprovalUpsertArgs>(args: SelectSubset<T, ApprovalUpsertArgs<ExtArgs>>): Prisma__ApprovalClient<$Result.GetResult<Prisma.$ApprovalPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Approvals.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovalCountArgs} args - Arguments to filter Approvals to count.
     * @example
     * // Count the number of Approvals
     * const count = await prisma.approval.count({
     *   where: {
     *     // ... the filter for the Approvals we want to count
     *   }
     * })
    **/
    count<T extends ApprovalCountArgs>(
      args?: Subset<T, ApprovalCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ApprovalCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Approval.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovalAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ApprovalAggregateArgs>(args: Subset<T, ApprovalAggregateArgs>): Prisma.PrismaPromise<GetApprovalAggregateType<T>>

    /**
     * Group by Approval.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ApprovalGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ApprovalGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ApprovalGroupByArgs['orderBy'] }
        : { orderBy?: ApprovalGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ApprovalGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetApprovalGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Approval model
   */
  readonly fields: ApprovalFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Approval.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ApprovalClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    file<T extends FileDefaultArgs<ExtArgs> = {}>(args?: Subset<T, FileDefaultArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    approver<T extends Approval$approverArgs<ExtArgs> = {}>(args?: Subset<T, Approval$approverArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Approval model
   */ 
  interface ApprovalFieldRefs {
    readonly id: FieldRef<"Approval", 'String'>
    readonly fileId: FieldRef<"Approval", 'String'>
    readonly approvedBy: FieldRef<"Approval", 'String'>
    readonly approvedAt: FieldRef<"Approval", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Approval findUnique
   */
  export type ApprovalFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
    /**
     * Filter, which Approval to fetch.
     */
    where: ApprovalWhereUniqueInput
  }

  /**
   * Approval findUniqueOrThrow
   */
  export type ApprovalFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
    /**
     * Filter, which Approval to fetch.
     */
    where: ApprovalWhereUniqueInput
  }

  /**
   * Approval findFirst
   */
  export type ApprovalFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
    /**
     * Filter, which Approval to fetch.
     */
    where?: ApprovalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Approvals to fetch.
     */
    orderBy?: ApprovalOrderByWithRelationInput | ApprovalOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Approvals.
     */
    cursor?: ApprovalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Approvals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Approvals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Approvals.
     */
    distinct?: ApprovalScalarFieldEnum | ApprovalScalarFieldEnum[]
  }

  /**
   * Approval findFirstOrThrow
   */
  export type ApprovalFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
    /**
     * Filter, which Approval to fetch.
     */
    where?: ApprovalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Approvals to fetch.
     */
    orderBy?: ApprovalOrderByWithRelationInput | ApprovalOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Approvals.
     */
    cursor?: ApprovalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Approvals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Approvals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Approvals.
     */
    distinct?: ApprovalScalarFieldEnum | ApprovalScalarFieldEnum[]
  }

  /**
   * Approval findMany
   */
  export type ApprovalFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
    /**
     * Filter, which Approvals to fetch.
     */
    where?: ApprovalWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Approvals to fetch.
     */
    orderBy?: ApprovalOrderByWithRelationInput | ApprovalOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Approvals.
     */
    cursor?: ApprovalWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Approvals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Approvals.
     */
    skip?: number
    distinct?: ApprovalScalarFieldEnum | ApprovalScalarFieldEnum[]
  }

  /**
   * Approval create
   */
  export type ApprovalCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
    /**
     * The data needed to create a Approval.
     */
    data: XOR<ApprovalCreateInput, ApprovalUncheckedCreateInput>
  }

  /**
   * Approval createMany
   */
  export type ApprovalCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Approvals.
     */
    data: ApprovalCreateManyInput | ApprovalCreateManyInput[]
  }

  /**
   * Approval createManyAndReturn
   */
  export type ApprovalCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * The data used to create many Approvals.
     */
    data: ApprovalCreateManyInput | ApprovalCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Approval update
   */
  export type ApprovalUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
    /**
     * The data needed to update a Approval.
     */
    data: XOR<ApprovalUpdateInput, ApprovalUncheckedUpdateInput>
    /**
     * Choose, which Approval to update.
     */
    where: ApprovalWhereUniqueInput
  }

  /**
   * Approval updateMany
   */
  export type ApprovalUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Approvals.
     */
    data: XOR<ApprovalUpdateManyMutationInput, ApprovalUncheckedUpdateManyInput>
    /**
     * Filter which Approvals to update
     */
    where?: ApprovalWhereInput
    /**
     * Limit how many Approvals to update.
     */
    limit?: number
  }

  /**
   * Approval updateManyAndReturn
   */
  export type ApprovalUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * The data used to update Approvals.
     */
    data: XOR<ApprovalUpdateManyMutationInput, ApprovalUncheckedUpdateManyInput>
    /**
     * Filter which Approvals to update
     */
    where?: ApprovalWhereInput
    /**
     * Limit how many Approvals to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Approval upsert
   */
  export type ApprovalUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
    /**
     * The filter to search for the Approval to update in case it exists.
     */
    where: ApprovalWhereUniqueInput
    /**
     * In case the Approval found by the `where` argument doesn't exist, create a new Approval with this data.
     */
    create: XOR<ApprovalCreateInput, ApprovalUncheckedCreateInput>
    /**
     * In case the Approval was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ApprovalUpdateInput, ApprovalUncheckedUpdateInput>
  }

  /**
   * Approval delete
   */
  export type ApprovalDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
    /**
     * Filter which Approval to delete.
     */
    where: ApprovalWhereUniqueInput
  }

  /**
   * Approval deleteMany
   */
  export type ApprovalDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Approvals to delete
     */
    where?: ApprovalWhereInput
    /**
     * Limit how many Approvals to delete.
     */
    limit?: number
  }

  /**
   * Approval.approver
   */
  export type Approval$approverArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }

  /**
   * Approval without action
   */
  export type ApprovalDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Approval
     */
    select?: ApprovalSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Approval
     */
    omit?: ApprovalOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ApprovalInclude<ExtArgs> | null
  }


  /**
   * Model Permission
   */

  export type AggregatePermission = {
    _count: PermissionCountAggregateOutputType | null
    _min: PermissionMinAggregateOutputType | null
    _max: PermissionMaxAggregateOutputType | null
  }

  export type PermissionMinAggregateOutputType = {
    id: string | null
    permissionType: $Enums.PermissionType | null
    resourceType: $Enums.ResourceType | null
    userId: string | null
    grantedBy: string | null
    fileId: string | null
    directoryId: string | null
    cascadeToChildren: boolean | null
    createdAt: Date | null
  }

  export type PermissionMaxAggregateOutputType = {
    id: string | null
    permissionType: $Enums.PermissionType | null
    resourceType: $Enums.ResourceType | null
    userId: string | null
    grantedBy: string | null
    fileId: string | null
    directoryId: string | null
    cascadeToChildren: boolean | null
    createdAt: Date | null
  }

  export type PermissionCountAggregateOutputType = {
    id: number
    permissionType: number
    resourceType: number
    userId: number
    grantedBy: number
    fileId: number
    directoryId: number
    cascadeToChildren: number
    createdAt: number
    _all: number
  }


  export type PermissionMinAggregateInputType = {
    id?: true
    permissionType?: true
    resourceType?: true
    userId?: true
    grantedBy?: true
    fileId?: true
    directoryId?: true
    cascadeToChildren?: true
    createdAt?: true
  }

  export type PermissionMaxAggregateInputType = {
    id?: true
    permissionType?: true
    resourceType?: true
    userId?: true
    grantedBy?: true
    fileId?: true
    directoryId?: true
    cascadeToChildren?: true
    createdAt?: true
  }

  export type PermissionCountAggregateInputType = {
    id?: true
    permissionType?: true
    resourceType?: true
    userId?: true
    grantedBy?: true
    fileId?: true
    directoryId?: true
    cascadeToChildren?: true
    createdAt?: true
    _all?: true
  }

  export type PermissionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Permission to aggregate.
     */
    where?: PermissionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Permissions to fetch.
     */
    orderBy?: PermissionOrderByWithRelationInput | PermissionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PermissionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Permissions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Permissions
    **/
    _count?: true | PermissionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PermissionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PermissionMaxAggregateInputType
  }

  export type GetPermissionAggregateType<T extends PermissionAggregateArgs> = {
        [P in keyof T & keyof AggregatePermission]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePermission[P]>
      : GetScalarType<T[P], AggregatePermission[P]>
  }




  export type PermissionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PermissionWhereInput
    orderBy?: PermissionOrderByWithAggregationInput | PermissionOrderByWithAggregationInput[]
    by: PermissionScalarFieldEnum[] | PermissionScalarFieldEnum
    having?: PermissionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PermissionCountAggregateInputType | true
    _min?: PermissionMinAggregateInputType
    _max?: PermissionMaxAggregateInputType
  }

  export type PermissionGroupByOutputType = {
    id: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    userId: string
    grantedBy: string | null
    fileId: string | null
    directoryId: string | null
    cascadeToChildren: boolean
    createdAt: Date
    _count: PermissionCountAggregateOutputType | null
    _min: PermissionMinAggregateOutputType | null
    _max: PermissionMaxAggregateOutputType | null
  }

  type GetPermissionGroupByPayload<T extends PermissionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PermissionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PermissionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PermissionGroupByOutputType[P]>
            : GetScalarType<T[P], PermissionGroupByOutputType[P]>
        }
      >
    >


  export type PermissionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    permissionType?: boolean
    resourceType?: boolean
    userId?: boolean
    grantedBy?: boolean
    fileId?: boolean
    directoryId?: boolean
    cascadeToChildren?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    granter?: boolean | Permission$granterArgs<ExtArgs>
    file?: boolean | Permission$fileArgs<ExtArgs>
    directory?: boolean | Permission$directoryArgs<ExtArgs>
  }, ExtArgs["result"]["permission"]>

  export type PermissionSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    permissionType?: boolean
    resourceType?: boolean
    userId?: boolean
    grantedBy?: boolean
    fileId?: boolean
    directoryId?: boolean
    cascadeToChildren?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    granter?: boolean | Permission$granterArgs<ExtArgs>
    file?: boolean | Permission$fileArgs<ExtArgs>
    directory?: boolean | Permission$directoryArgs<ExtArgs>
  }, ExtArgs["result"]["permission"]>

  export type PermissionSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    permissionType?: boolean
    resourceType?: boolean
    userId?: boolean
    grantedBy?: boolean
    fileId?: boolean
    directoryId?: boolean
    cascadeToChildren?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    granter?: boolean | Permission$granterArgs<ExtArgs>
    file?: boolean | Permission$fileArgs<ExtArgs>
    directory?: boolean | Permission$directoryArgs<ExtArgs>
  }, ExtArgs["result"]["permission"]>

  export type PermissionSelectScalar = {
    id?: boolean
    permissionType?: boolean
    resourceType?: boolean
    userId?: boolean
    grantedBy?: boolean
    fileId?: boolean
    directoryId?: boolean
    cascadeToChildren?: boolean
    createdAt?: boolean
  }

  export type PermissionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "permissionType" | "resourceType" | "userId" | "grantedBy" | "fileId" | "directoryId" | "cascadeToChildren" | "createdAt", ExtArgs["result"]["permission"]>
  export type PermissionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    granter?: boolean | Permission$granterArgs<ExtArgs>
    file?: boolean | Permission$fileArgs<ExtArgs>
    directory?: boolean | Permission$directoryArgs<ExtArgs>
  }
  export type PermissionIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    granter?: boolean | Permission$granterArgs<ExtArgs>
    file?: boolean | Permission$fileArgs<ExtArgs>
    directory?: boolean | Permission$directoryArgs<ExtArgs>
  }
  export type PermissionIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    granter?: boolean | Permission$granterArgs<ExtArgs>
    file?: boolean | Permission$fileArgs<ExtArgs>
    directory?: boolean | Permission$directoryArgs<ExtArgs>
  }

  export type $PermissionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Permission"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      granter: Prisma.$UserPayload<ExtArgs> | null
      file: Prisma.$FilePayload<ExtArgs> | null
      directory: Prisma.$DirectoryPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      permissionType: $Enums.PermissionType
      resourceType: $Enums.ResourceType
      userId: string
      grantedBy: string | null
      fileId: string | null
      directoryId: string | null
      cascadeToChildren: boolean
      createdAt: Date
    }, ExtArgs["result"]["permission"]>
    composites: {}
  }

  type PermissionGetPayload<S extends boolean | null | undefined | PermissionDefaultArgs> = $Result.GetResult<Prisma.$PermissionPayload, S>

  type PermissionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PermissionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PermissionCountAggregateInputType | true
    }

  export interface PermissionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Permission'], meta: { name: 'Permission' } }
    /**
     * Find zero or one Permission that matches the filter.
     * @param {PermissionFindUniqueArgs} args - Arguments to find a Permission
     * @example
     * // Get one Permission
     * const permission = await prisma.permission.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PermissionFindUniqueArgs>(args: SelectSubset<T, PermissionFindUniqueArgs<ExtArgs>>): Prisma__PermissionClient<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Permission that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PermissionFindUniqueOrThrowArgs} args - Arguments to find a Permission
     * @example
     * // Get one Permission
     * const permission = await prisma.permission.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PermissionFindUniqueOrThrowArgs>(args: SelectSubset<T, PermissionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PermissionClient<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Permission that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PermissionFindFirstArgs} args - Arguments to find a Permission
     * @example
     * // Get one Permission
     * const permission = await prisma.permission.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PermissionFindFirstArgs>(args?: SelectSubset<T, PermissionFindFirstArgs<ExtArgs>>): Prisma__PermissionClient<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Permission that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PermissionFindFirstOrThrowArgs} args - Arguments to find a Permission
     * @example
     * // Get one Permission
     * const permission = await prisma.permission.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PermissionFindFirstOrThrowArgs>(args?: SelectSubset<T, PermissionFindFirstOrThrowArgs<ExtArgs>>): Prisma__PermissionClient<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Permissions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PermissionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Permissions
     * const permissions = await prisma.permission.findMany()
     * 
     * // Get first 10 Permissions
     * const permissions = await prisma.permission.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const permissionWithIdOnly = await prisma.permission.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PermissionFindManyArgs>(args?: SelectSubset<T, PermissionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Permission.
     * @param {PermissionCreateArgs} args - Arguments to create a Permission.
     * @example
     * // Create one Permission
     * const Permission = await prisma.permission.create({
     *   data: {
     *     // ... data to create a Permission
     *   }
     * })
     * 
     */
    create<T extends PermissionCreateArgs>(args: SelectSubset<T, PermissionCreateArgs<ExtArgs>>): Prisma__PermissionClient<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Permissions.
     * @param {PermissionCreateManyArgs} args - Arguments to create many Permissions.
     * @example
     * // Create many Permissions
     * const permission = await prisma.permission.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PermissionCreateManyArgs>(args?: SelectSubset<T, PermissionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Permissions and returns the data saved in the database.
     * @param {PermissionCreateManyAndReturnArgs} args - Arguments to create many Permissions.
     * @example
     * // Create many Permissions
     * const permission = await prisma.permission.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Permissions and only return the `id`
     * const permissionWithIdOnly = await prisma.permission.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PermissionCreateManyAndReturnArgs>(args?: SelectSubset<T, PermissionCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Permission.
     * @param {PermissionDeleteArgs} args - Arguments to delete one Permission.
     * @example
     * // Delete one Permission
     * const Permission = await prisma.permission.delete({
     *   where: {
     *     // ... filter to delete one Permission
     *   }
     * })
     * 
     */
    delete<T extends PermissionDeleteArgs>(args: SelectSubset<T, PermissionDeleteArgs<ExtArgs>>): Prisma__PermissionClient<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Permission.
     * @param {PermissionUpdateArgs} args - Arguments to update one Permission.
     * @example
     * // Update one Permission
     * const permission = await prisma.permission.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PermissionUpdateArgs>(args: SelectSubset<T, PermissionUpdateArgs<ExtArgs>>): Prisma__PermissionClient<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Permissions.
     * @param {PermissionDeleteManyArgs} args - Arguments to filter Permissions to delete.
     * @example
     * // Delete a few Permissions
     * const { count } = await prisma.permission.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PermissionDeleteManyArgs>(args?: SelectSubset<T, PermissionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Permissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PermissionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Permissions
     * const permission = await prisma.permission.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PermissionUpdateManyArgs>(args: SelectSubset<T, PermissionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Permissions and returns the data updated in the database.
     * @param {PermissionUpdateManyAndReturnArgs} args - Arguments to update many Permissions.
     * @example
     * // Update many Permissions
     * const permission = await prisma.permission.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Permissions and only return the `id`
     * const permissionWithIdOnly = await prisma.permission.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PermissionUpdateManyAndReturnArgs>(args: SelectSubset<T, PermissionUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Permission.
     * @param {PermissionUpsertArgs} args - Arguments to update or create a Permission.
     * @example
     * // Update or create a Permission
     * const permission = await prisma.permission.upsert({
     *   create: {
     *     // ... data to create a Permission
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Permission we want to update
     *   }
     * })
     */
    upsert<T extends PermissionUpsertArgs>(args: SelectSubset<T, PermissionUpsertArgs<ExtArgs>>): Prisma__PermissionClient<$Result.GetResult<Prisma.$PermissionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Permissions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PermissionCountArgs} args - Arguments to filter Permissions to count.
     * @example
     * // Count the number of Permissions
     * const count = await prisma.permission.count({
     *   where: {
     *     // ... the filter for the Permissions we want to count
     *   }
     * })
    **/
    count<T extends PermissionCountArgs>(
      args?: Subset<T, PermissionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PermissionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Permission.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PermissionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PermissionAggregateArgs>(args: Subset<T, PermissionAggregateArgs>): Prisma.PrismaPromise<GetPermissionAggregateType<T>>

    /**
     * Group by Permission.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PermissionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PermissionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PermissionGroupByArgs['orderBy'] }
        : { orderBy?: PermissionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PermissionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPermissionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Permission model
   */
  readonly fields: PermissionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Permission.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PermissionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    granter<T extends Permission$granterArgs<ExtArgs> = {}>(args?: Subset<T, Permission$granterArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    file<T extends Permission$fileArgs<ExtArgs> = {}>(args?: Subset<T, Permission$fileArgs<ExtArgs>>): Prisma__FileClient<$Result.GetResult<Prisma.$FilePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    directory<T extends Permission$directoryArgs<ExtArgs> = {}>(args?: Subset<T, Permission$directoryArgs<ExtArgs>>): Prisma__DirectoryClient<$Result.GetResult<Prisma.$DirectoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Permission model
   */ 
  interface PermissionFieldRefs {
    readonly id: FieldRef<"Permission", 'String'>
    readonly permissionType: FieldRef<"Permission", 'PermissionType'>
    readonly resourceType: FieldRef<"Permission", 'ResourceType'>
    readonly userId: FieldRef<"Permission", 'String'>
    readonly grantedBy: FieldRef<"Permission", 'String'>
    readonly fileId: FieldRef<"Permission", 'String'>
    readonly directoryId: FieldRef<"Permission", 'String'>
    readonly cascadeToChildren: FieldRef<"Permission", 'Boolean'>
    readonly createdAt: FieldRef<"Permission", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Permission findUnique
   */
  export type PermissionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    /**
     * Filter, which Permission to fetch.
     */
    where: PermissionWhereUniqueInput
  }

  /**
   * Permission findUniqueOrThrow
   */
  export type PermissionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    /**
     * Filter, which Permission to fetch.
     */
    where: PermissionWhereUniqueInput
  }

  /**
   * Permission findFirst
   */
  export type PermissionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    /**
     * Filter, which Permission to fetch.
     */
    where?: PermissionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Permissions to fetch.
     */
    orderBy?: PermissionOrderByWithRelationInput | PermissionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Permissions.
     */
    cursor?: PermissionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Permissions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Permissions.
     */
    distinct?: PermissionScalarFieldEnum | PermissionScalarFieldEnum[]
  }

  /**
   * Permission findFirstOrThrow
   */
  export type PermissionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    /**
     * Filter, which Permission to fetch.
     */
    where?: PermissionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Permissions to fetch.
     */
    orderBy?: PermissionOrderByWithRelationInput | PermissionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Permissions.
     */
    cursor?: PermissionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Permissions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Permissions.
     */
    distinct?: PermissionScalarFieldEnum | PermissionScalarFieldEnum[]
  }

  /**
   * Permission findMany
   */
  export type PermissionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    /**
     * Filter, which Permissions to fetch.
     */
    where?: PermissionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Permissions to fetch.
     */
    orderBy?: PermissionOrderByWithRelationInput | PermissionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Permissions.
     */
    cursor?: PermissionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Permissions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Permissions.
     */
    skip?: number
    distinct?: PermissionScalarFieldEnum | PermissionScalarFieldEnum[]
  }

  /**
   * Permission create
   */
  export type PermissionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    /**
     * The data needed to create a Permission.
     */
    data: XOR<PermissionCreateInput, PermissionUncheckedCreateInput>
  }

  /**
   * Permission createMany
   */
  export type PermissionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Permissions.
     */
    data: PermissionCreateManyInput | PermissionCreateManyInput[]
  }

  /**
   * Permission createManyAndReturn
   */
  export type PermissionCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * The data used to create many Permissions.
     */
    data: PermissionCreateManyInput | PermissionCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Permission update
   */
  export type PermissionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    /**
     * The data needed to update a Permission.
     */
    data: XOR<PermissionUpdateInput, PermissionUncheckedUpdateInput>
    /**
     * Choose, which Permission to update.
     */
    where: PermissionWhereUniqueInput
  }

  /**
   * Permission updateMany
   */
  export type PermissionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Permissions.
     */
    data: XOR<PermissionUpdateManyMutationInput, PermissionUncheckedUpdateManyInput>
    /**
     * Filter which Permissions to update
     */
    where?: PermissionWhereInput
    /**
     * Limit how many Permissions to update.
     */
    limit?: number
  }

  /**
   * Permission updateManyAndReturn
   */
  export type PermissionUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * The data used to update Permissions.
     */
    data: XOR<PermissionUpdateManyMutationInput, PermissionUncheckedUpdateManyInput>
    /**
     * Filter which Permissions to update
     */
    where?: PermissionWhereInput
    /**
     * Limit how many Permissions to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Permission upsert
   */
  export type PermissionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    /**
     * The filter to search for the Permission to update in case it exists.
     */
    where: PermissionWhereUniqueInput
    /**
     * In case the Permission found by the `where` argument doesn't exist, create a new Permission with this data.
     */
    create: XOR<PermissionCreateInput, PermissionUncheckedCreateInput>
    /**
     * In case the Permission was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PermissionUpdateInput, PermissionUncheckedUpdateInput>
  }

  /**
   * Permission delete
   */
  export type PermissionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
    /**
     * Filter which Permission to delete.
     */
    where: PermissionWhereUniqueInput
  }

  /**
   * Permission deleteMany
   */
  export type PermissionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Permissions to delete
     */
    where?: PermissionWhereInput
    /**
     * Limit how many Permissions to delete.
     */
    limit?: number
  }

  /**
   * Permission.granter
   */
  export type Permission$granterArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }

  /**
   * Permission.file
   */
  export type Permission$fileArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the File
     */
    select?: FileSelect<ExtArgs> | null
    /**
     * Omit specific fields from the File
     */
    omit?: FileOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: FileInclude<ExtArgs> | null
    where?: FileWhereInput
  }

  /**
   * Permission.directory
   */
  export type Permission$directoryArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Directory
     */
    select?: DirectorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Directory
     */
    omit?: DirectoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DirectoryInclude<ExtArgs> | null
    where?: DirectoryWhereInput
  }

  /**
   * Permission without action
   */
  export type PermissionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Permission
     */
    select?: PermissionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Permission
     */
    omit?: PermissionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PermissionInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    id: 'id',
    username: 'username',
    email: 'email',
    password: 'password',
    role: 'role'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const DirectoryScalarFieldEnum: {
    id: 'id',
    name: 'name',
    path: 'path',
    parentId: 'parentId',
    createdAt: 'createdAt',
    createdBy: 'createdBy'
  };

  export type DirectoryScalarFieldEnum = (typeof DirectoryScalarFieldEnum)[keyof typeof DirectoryScalarFieldEnum]


  export const FileScalarFieldEnum: {
    id: 'id',
    name: 'name',
    description: 'description',
    path: 'path',
    directoryId: 'directoryId',
    directoryPath: 'directoryPath',
    createdAt: 'createdAt',
    createdBy: 'createdBy',
    approvalStatus: 'approvalStatus',
    approvedBy: 'approvedBy'
  };

  export type FileScalarFieldEnum = (typeof FileScalarFieldEnum)[keyof typeof FileScalarFieldEnum]


  export const VersionScalarFieldEnum: {
    id: 'id',
    fileId: 'fileId',
    filePath: 'filePath',
    versionNumber: 'versionNumber',
    createdAt: 'createdAt',
    description: 'description',
    createdBy: 'createdBy',
    approvedBy: 'approvedBy',
    approvedAt: 'approvedAt'
  };

  export type VersionScalarFieldEnum = (typeof VersionScalarFieldEnum)[keyof typeof VersionScalarFieldEnum]


  export const ApprovalScalarFieldEnum: {
    id: 'id',
    fileId: 'fileId',
    approvedBy: 'approvedBy',
    approvedAt: 'approvedAt'
  };

  export type ApprovalScalarFieldEnum = (typeof ApprovalScalarFieldEnum)[keyof typeof ApprovalScalarFieldEnum]


  export const PermissionScalarFieldEnum: {
    id: 'id',
    permissionType: 'permissionType',
    resourceType: 'resourceType',
    userId: 'userId',
    grantedBy: 'grantedBy',
    fileId: 'fileId',
    directoryId: 'directoryId',
    cascadeToChildren: 'cascadeToChildren',
    createdAt: 'createdAt'
  };

  export type PermissionScalarFieldEnum = (typeof PermissionScalarFieldEnum)[keyof typeof PermissionScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references 
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'Role'
   */
  export type EnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'ApprovalStatus'
   */
  export type EnumApprovalStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'ApprovalStatus'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'PermissionType'
   */
  export type EnumPermissionTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PermissionType'>
    


  /**
   * Reference to a field of type 'ResourceType'
   */
  export type EnumResourceTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'ResourceType'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: StringFilter<"User"> | string
    username?: StringFilter<"User"> | string
    email?: StringNullableFilter<"User"> | string | null
    password?: StringFilter<"User"> | string
    role?: EnumRoleFilter<"User"> | $Enums.Role
    files?: FileListRelationFilter
    approvals?: ApprovalListRelationFilter
    approvedVersions?: VersionListRelationFilter
    approvedFiles?: FileListRelationFilter
    createdVersions?: VersionListRelationFilter
    createdDirectories?: DirectoryListRelationFilter
    givenPermissions?: PermissionListRelationFilter
    permissions?: PermissionListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    username?: SortOrder
    email?: SortOrderInput | SortOrder
    password?: SortOrder
    role?: SortOrder
    files?: FileOrderByRelationAggregateInput
    approvals?: ApprovalOrderByRelationAggregateInput
    approvedVersions?: VersionOrderByRelationAggregateInput
    approvedFiles?: FileOrderByRelationAggregateInput
    createdVersions?: VersionOrderByRelationAggregateInput
    createdDirectories?: DirectoryOrderByRelationAggregateInput
    givenPermissions?: PermissionOrderByRelationAggregateInput
    permissions?: PermissionOrderByRelationAggregateInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    username?: string
    email?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    password?: StringFilter<"User"> | string
    role?: EnumRoleFilter<"User"> | $Enums.Role
    files?: FileListRelationFilter
    approvals?: ApprovalListRelationFilter
    approvedVersions?: VersionListRelationFilter
    approvedFiles?: FileListRelationFilter
    createdVersions?: VersionListRelationFilter
    createdDirectories?: DirectoryListRelationFilter
    givenPermissions?: PermissionListRelationFilter
    permissions?: PermissionListRelationFilter
  }, "id" | "username" | "email">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    username?: SortOrder
    email?: SortOrderInput | SortOrder
    password?: SortOrder
    role?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"User"> | string
    username?: StringWithAggregatesFilter<"User"> | string
    email?: StringNullableWithAggregatesFilter<"User"> | string | null
    password?: StringWithAggregatesFilter<"User"> | string
    role?: EnumRoleWithAggregatesFilter<"User"> | $Enums.Role
  }

  export type DirectoryWhereInput = {
    AND?: DirectoryWhereInput | DirectoryWhereInput[]
    OR?: DirectoryWhereInput[]
    NOT?: DirectoryWhereInput | DirectoryWhereInput[]
    id?: StringFilter<"Directory"> | string
    name?: StringFilter<"Directory"> | string
    path?: StringFilter<"Directory"> | string
    parentId?: StringNullableFilter<"Directory"> | string | null
    createdAt?: DateTimeFilter<"Directory"> | Date | string
    createdBy?: StringNullableFilter<"Directory"> | string | null
    parent?: XOR<DirectoryNullableScalarRelationFilter, DirectoryWhereInput> | null
    children?: DirectoryListRelationFilter
    creator?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    permissions?: PermissionListRelationFilter
    files?: FileListRelationFilter
  }

  export type DirectoryOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    path?: SortOrder
    parentId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    createdBy?: SortOrderInput | SortOrder
    parent?: DirectoryOrderByWithRelationInput
    children?: DirectoryOrderByRelationAggregateInput
    creator?: UserOrderByWithRelationInput
    permissions?: PermissionOrderByRelationAggregateInput
    files?: FileOrderByRelationAggregateInput
  }

  export type DirectoryWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    path?: string
    name_parentId?: DirectoryNameParentIdCompoundUniqueInput
    AND?: DirectoryWhereInput | DirectoryWhereInput[]
    OR?: DirectoryWhereInput[]
    NOT?: DirectoryWhereInput | DirectoryWhereInput[]
    name?: StringFilter<"Directory"> | string
    parentId?: StringNullableFilter<"Directory"> | string | null
    createdAt?: DateTimeFilter<"Directory"> | Date | string
    createdBy?: StringNullableFilter<"Directory"> | string | null
    parent?: XOR<DirectoryNullableScalarRelationFilter, DirectoryWhereInput> | null
    children?: DirectoryListRelationFilter
    creator?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    permissions?: PermissionListRelationFilter
    files?: FileListRelationFilter
  }, "id" | "path" | "name_parentId">

  export type DirectoryOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    path?: SortOrder
    parentId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    createdBy?: SortOrderInput | SortOrder
    _count?: DirectoryCountOrderByAggregateInput
    _max?: DirectoryMaxOrderByAggregateInput
    _min?: DirectoryMinOrderByAggregateInput
  }

  export type DirectoryScalarWhereWithAggregatesInput = {
    AND?: DirectoryScalarWhereWithAggregatesInput | DirectoryScalarWhereWithAggregatesInput[]
    OR?: DirectoryScalarWhereWithAggregatesInput[]
    NOT?: DirectoryScalarWhereWithAggregatesInput | DirectoryScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Directory"> | string
    name?: StringWithAggregatesFilter<"Directory"> | string
    path?: StringWithAggregatesFilter<"Directory"> | string
    parentId?: StringNullableWithAggregatesFilter<"Directory"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Directory"> | Date | string
    createdBy?: StringNullableWithAggregatesFilter<"Directory"> | string | null
  }

  export type FileWhereInput = {
    AND?: FileWhereInput | FileWhereInput[]
    OR?: FileWhereInput[]
    NOT?: FileWhereInput | FileWhereInput[]
    id?: StringFilter<"File"> | string
    name?: StringFilter<"File"> | string
    description?: StringNullableFilter<"File"> | string | null
    path?: StringFilter<"File"> | string
    directoryId?: StringNullableFilter<"File"> | string | null
    directoryPath?: StringNullableFilter<"File"> | string | null
    createdAt?: DateTimeFilter<"File"> | Date | string
    createdBy?: StringFilter<"File"> | string
    approvalStatus?: EnumApprovalStatusFilter<"File"> | $Enums.ApprovalStatus
    approvedBy?: StringNullableFilter<"File"> | string | null
    directory?: XOR<DirectoryNullableScalarRelationFilter, DirectoryWhereInput> | null
    creator?: XOR<UserScalarRelationFilter, UserWhereInput>
    versions?: VersionListRelationFilter
    approver?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    approval?: XOR<ApprovalNullableScalarRelationFilter, ApprovalWhereInput> | null
    permissions?: PermissionListRelationFilter
  }

  export type FileOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    path?: SortOrder
    directoryId?: SortOrderInput | SortOrder
    directoryPath?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    createdBy?: SortOrder
    approvalStatus?: SortOrder
    approvedBy?: SortOrderInput | SortOrder
    directory?: DirectoryOrderByWithRelationInput
    creator?: UserOrderByWithRelationInput
    versions?: VersionOrderByRelationAggregateInput
    approver?: UserOrderByWithRelationInput
    approval?: ApprovalOrderByWithRelationInput
    permissions?: PermissionOrderByRelationAggregateInput
  }

  export type FileWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    path?: string
    AND?: FileWhereInput | FileWhereInput[]
    OR?: FileWhereInput[]
    NOT?: FileWhereInput | FileWhereInput[]
    name?: StringFilter<"File"> | string
    description?: StringNullableFilter<"File"> | string | null
    directoryId?: StringNullableFilter<"File"> | string | null
    directoryPath?: StringNullableFilter<"File"> | string | null
    createdAt?: DateTimeFilter<"File"> | Date | string
    createdBy?: StringFilter<"File"> | string
    approvalStatus?: EnumApprovalStatusFilter<"File"> | $Enums.ApprovalStatus
    approvedBy?: StringNullableFilter<"File"> | string | null
    directory?: XOR<DirectoryNullableScalarRelationFilter, DirectoryWhereInput> | null
    creator?: XOR<UserScalarRelationFilter, UserWhereInput>
    versions?: VersionListRelationFilter
    approver?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    approval?: XOR<ApprovalNullableScalarRelationFilter, ApprovalWhereInput> | null
    permissions?: PermissionListRelationFilter
  }, "id" | "path">

  export type FileOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    path?: SortOrder
    directoryId?: SortOrderInput | SortOrder
    directoryPath?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    createdBy?: SortOrder
    approvalStatus?: SortOrder
    approvedBy?: SortOrderInput | SortOrder
    _count?: FileCountOrderByAggregateInput
    _max?: FileMaxOrderByAggregateInput
    _min?: FileMinOrderByAggregateInput
  }

  export type FileScalarWhereWithAggregatesInput = {
    AND?: FileScalarWhereWithAggregatesInput | FileScalarWhereWithAggregatesInput[]
    OR?: FileScalarWhereWithAggregatesInput[]
    NOT?: FileScalarWhereWithAggregatesInput | FileScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"File"> | string
    name?: StringWithAggregatesFilter<"File"> | string
    description?: StringNullableWithAggregatesFilter<"File"> | string | null
    path?: StringWithAggregatesFilter<"File"> | string
    directoryId?: StringNullableWithAggregatesFilter<"File"> | string | null
    directoryPath?: StringNullableWithAggregatesFilter<"File"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"File"> | Date | string
    createdBy?: StringWithAggregatesFilter<"File"> | string
    approvalStatus?: EnumApprovalStatusWithAggregatesFilter<"File"> | $Enums.ApprovalStatus
    approvedBy?: StringNullableWithAggregatesFilter<"File"> | string | null
  }

  export type VersionWhereInput = {
    AND?: VersionWhereInput | VersionWhereInput[]
    OR?: VersionWhereInput[]
    NOT?: VersionWhereInput | VersionWhereInput[]
    id?: StringFilter<"Version"> | string
    fileId?: StringFilter<"Version"> | string
    filePath?: StringFilter<"Version"> | string
    versionNumber?: IntFilter<"Version"> | number
    createdAt?: DateTimeFilter<"Version"> | Date | string
    description?: StringNullableFilter<"Version"> | string | null
    createdBy?: StringFilter<"Version"> | string
    approvedBy?: StringNullableFilter<"Version"> | string | null
    approvedAt?: DateTimeNullableFilter<"Version"> | Date | string | null
    creator?: XOR<UserScalarRelationFilter, UserWhereInput>
    file?: XOR<FileScalarRelationFilter, FileWhereInput>
    approver?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
  }

  export type VersionOrderByWithRelationInput = {
    id?: SortOrder
    fileId?: SortOrder
    filePath?: SortOrder
    versionNumber?: SortOrder
    createdAt?: SortOrder
    description?: SortOrderInput | SortOrder
    createdBy?: SortOrder
    approvedBy?: SortOrderInput | SortOrder
    approvedAt?: SortOrderInput | SortOrder
    creator?: UserOrderByWithRelationInput
    file?: FileOrderByWithRelationInput
    approver?: UserOrderByWithRelationInput
  }

  export type VersionWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: VersionWhereInput | VersionWhereInput[]
    OR?: VersionWhereInput[]
    NOT?: VersionWhereInput | VersionWhereInput[]
    fileId?: StringFilter<"Version"> | string
    filePath?: StringFilter<"Version"> | string
    versionNumber?: IntFilter<"Version"> | number
    createdAt?: DateTimeFilter<"Version"> | Date | string
    description?: StringNullableFilter<"Version"> | string | null
    createdBy?: StringFilter<"Version"> | string
    approvedBy?: StringNullableFilter<"Version"> | string | null
    approvedAt?: DateTimeNullableFilter<"Version"> | Date | string | null
    creator?: XOR<UserScalarRelationFilter, UserWhereInput>
    file?: XOR<FileScalarRelationFilter, FileWhereInput>
    approver?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
  }, "id">

  export type VersionOrderByWithAggregationInput = {
    id?: SortOrder
    fileId?: SortOrder
    filePath?: SortOrder
    versionNumber?: SortOrder
    createdAt?: SortOrder
    description?: SortOrderInput | SortOrder
    createdBy?: SortOrder
    approvedBy?: SortOrderInput | SortOrder
    approvedAt?: SortOrderInput | SortOrder
    _count?: VersionCountOrderByAggregateInput
    _avg?: VersionAvgOrderByAggregateInput
    _max?: VersionMaxOrderByAggregateInput
    _min?: VersionMinOrderByAggregateInput
    _sum?: VersionSumOrderByAggregateInput
  }

  export type VersionScalarWhereWithAggregatesInput = {
    AND?: VersionScalarWhereWithAggregatesInput | VersionScalarWhereWithAggregatesInput[]
    OR?: VersionScalarWhereWithAggregatesInput[]
    NOT?: VersionScalarWhereWithAggregatesInput | VersionScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Version"> | string
    fileId?: StringWithAggregatesFilter<"Version"> | string
    filePath?: StringWithAggregatesFilter<"Version"> | string
    versionNumber?: IntWithAggregatesFilter<"Version"> | number
    createdAt?: DateTimeWithAggregatesFilter<"Version"> | Date | string
    description?: StringNullableWithAggregatesFilter<"Version"> | string | null
    createdBy?: StringWithAggregatesFilter<"Version"> | string
    approvedBy?: StringNullableWithAggregatesFilter<"Version"> | string | null
    approvedAt?: DateTimeNullableWithAggregatesFilter<"Version"> | Date | string | null
  }

  export type ApprovalWhereInput = {
    AND?: ApprovalWhereInput | ApprovalWhereInput[]
    OR?: ApprovalWhereInput[]
    NOT?: ApprovalWhereInput | ApprovalWhereInput[]
    id?: StringFilter<"Approval"> | string
    fileId?: StringFilter<"Approval"> | string
    approvedBy?: StringNullableFilter<"Approval"> | string | null
    approvedAt?: DateTimeNullableFilter<"Approval"> | Date | string | null
    file?: XOR<FileScalarRelationFilter, FileWhereInput>
    approver?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
  }

  export type ApprovalOrderByWithRelationInput = {
    id?: SortOrder
    fileId?: SortOrder
    approvedBy?: SortOrderInput | SortOrder
    approvedAt?: SortOrderInput | SortOrder
    file?: FileOrderByWithRelationInput
    approver?: UserOrderByWithRelationInput
  }

  export type ApprovalWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    fileId?: string
    AND?: ApprovalWhereInput | ApprovalWhereInput[]
    OR?: ApprovalWhereInput[]
    NOT?: ApprovalWhereInput | ApprovalWhereInput[]
    approvedBy?: StringNullableFilter<"Approval"> | string | null
    approvedAt?: DateTimeNullableFilter<"Approval"> | Date | string | null
    file?: XOR<FileScalarRelationFilter, FileWhereInput>
    approver?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
  }, "id" | "fileId">

  export type ApprovalOrderByWithAggregationInput = {
    id?: SortOrder
    fileId?: SortOrder
    approvedBy?: SortOrderInput | SortOrder
    approvedAt?: SortOrderInput | SortOrder
    _count?: ApprovalCountOrderByAggregateInput
    _max?: ApprovalMaxOrderByAggregateInput
    _min?: ApprovalMinOrderByAggregateInput
  }

  export type ApprovalScalarWhereWithAggregatesInput = {
    AND?: ApprovalScalarWhereWithAggregatesInput | ApprovalScalarWhereWithAggregatesInput[]
    OR?: ApprovalScalarWhereWithAggregatesInput[]
    NOT?: ApprovalScalarWhereWithAggregatesInput | ApprovalScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Approval"> | string
    fileId?: StringWithAggregatesFilter<"Approval"> | string
    approvedBy?: StringNullableWithAggregatesFilter<"Approval"> | string | null
    approvedAt?: DateTimeNullableWithAggregatesFilter<"Approval"> | Date | string | null
  }

  export type PermissionWhereInput = {
    AND?: PermissionWhereInput | PermissionWhereInput[]
    OR?: PermissionWhereInput[]
    NOT?: PermissionWhereInput | PermissionWhereInput[]
    id?: StringFilter<"Permission"> | string
    permissionType?: EnumPermissionTypeFilter<"Permission"> | $Enums.PermissionType
    resourceType?: EnumResourceTypeFilter<"Permission"> | $Enums.ResourceType
    userId?: StringFilter<"Permission"> | string
    grantedBy?: StringNullableFilter<"Permission"> | string | null
    fileId?: StringNullableFilter<"Permission"> | string | null
    directoryId?: StringNullableFilter<"Permission"> | string | null
    cascadeToChildren?: BoolFilter<"Permission"> | boolean
    createdAt?: DateTimeFilter<"Permission"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    granter?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    file?: XOR<FileNullableScalarRelationFilter, FileWhereInput> | null
    directory?: XOR<DirectoryNullableScalarRelationFilter, DirectoryWhereInput> | null
  }

  export type PermissionOrderByWithRelationInput = {
    id?: SortOrder
    permissionType?: SortOrder
    resourceType?: SortOrder
    userId?: SortOrder
    grantedBy?: SortOrderInput | SortOrder
    fileId?: SortOrderInput | SortOrder
    directoryId?: SortOrderInput | SortOrder
    cascadeToChildren?: SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
    granter?: UserOrderByWithRelationInput
    file?: FileOrderByWithRelationInput
    directory?: DirectoryOrderByWithRelationInput
  }

  export type PermissionWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    userId_resourceType_fileId?: PermissionUserIdResourceTypeFileIdCompoundUniqueInput
    userId_resourceType_directoryId?: PermissionUserIdResourceTypeDirectoryIdCompoundUniqueInput
    AND?: PermissionWhereInput | PermissionWhereInput[]
    OR?: PermissionWhereInput[]
    NOT?: PermissionWhereInput | PermissionWhereInput[]
    permissionType?: EnumPermissionTypeFilter<"Permission"> | $Enums.PermissionType
    resourceType?: EnumResourceTypeFilter<"Permission"> | $Enums.ResourceType
    userId?: StringFilter<"Permission"> | string
    grantedBy?: StringNullableFilter<"Permission"> | string | null
    fileId?: StringNullableFilter<"Permission"> | string | null
    directoryId?: StringNullableFilter<"Permission"> | string | null
    cascadeToChildren?: BoolFilter<"Permission"> | boolean
    createdAt?: DateTimeFilter<"Permission"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    granter?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    file?: XOR<FileNullableScalarRelationFilter, FileWhereInput> | null
    directory?: XOR<DirectoryNullableScalarRelationFilter, DirectoryWhereInput> | null
  }, "id" | "userId_resourceType_fileId" | "userId_resourceType_directoryId">

  export type PermissionOrderByWithAggregationInput = {
    id?: SortOrder
    permissionType?: SortOrder
    resourceType?: SortOrder
    userId?: SortOrder
    grantedBy?: SortOrderInput | SortOrder
    fileId?: SortOrderInput | SortOrder
    directoryId?: SortOrderInput | SortOrder
    cascadeToChildren?: SortOrder
    createdAt?: SortOrder
    _count?: PermissionCountOrderByAggregateInput
    _max?: PermissionMaxOrderByAggregateInput
    _min?: PermissionMinOrderByAggregateInput
  }

  export type PermissionScalarWhereWithAggregatesInput = {
    AND?: PermissionScalarWhereWithAggregatesInput | PermissionScalarWhereWithAggregatesInput[]
    OR?: PermissionScalarWhereWithAggregatesInput[]
    NOT?: PermissionScalarWhereWithAggregatesInput | PermissionScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Permission"> | string
    permissionType?: EnumPermissionTypeWithAggregatesFilter<"Permission"> | $Enums.PermissionType
    resourceType?: EnumResourceTypeWithAggregatesFilter<"Permission"> | $Enums.ResourceType
    userId?: StringWithAggregatesFilter<"Permission"> | string
    grantedBy?: StringNullableWithAggregatesFilter<"Permission"> | string | null
    fileId?: StringNullableWithAggregatesFilter<"Permission"> | string | null
    directoryId?: StringNullableWithAggregatesFilter<"Permission"> | string | null
    cascadeToChildren?: BoolWithAggregatesFilter<"Permission"> | boolean
    createdAt?: DateTimeWithAggregatesFilter<"Permission"> | Date | string
  }

  export type UserCreateInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionCreateNestedManyWithoutApproverInput
    approvedFiles?: FileCreateNestedManyWithoutApproverInput
    createdVersions?: VersionCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionCreateNestedManyWithoutGranterInput
    permissions?: PermissionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileUncheckedCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalUncheckedCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionUncheckedCreateNestedManyWithoutApproverInput
    approvedFiles?: FileUncheckedCreateNestedManyWithoutApproverInput
    createdVersions?: VersionUncheckedCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryUncheckedCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionUncheckedCreateNestedManyWithoutGranterInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUncheckedUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUncheckedUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUncheckedUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUncheckedUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUncheckedUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUncheckedUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUncheckedUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateManyInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
  }

  export type UserUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
  }

  export type UserUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
  }

  export type DirectoryCreateInput = {
    id?: string
    name: string
    path: string
    createdAt?: Date | string
    parent?: DirectoryCreateNestedOneWithoutChildrenInput
    children?: DirectoryCreateNestedManyWithoutParentInput
    creator?: UserCreateNestedOneWithoutCreatedDirectoriesInput
    permissions?: PermissionCreateNestedManyWithoutDirectoryInput
    files?: FileCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryUncheckedCreateInput = {
    id?: string
    name: string
    path: string
    parentId?: string | null
    createdAt?: Date | string
    createdBy?: string | null
    children?: DirectoryUncheckedCreateNestedManyWithoutParentInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutDirectoryInput
    files?: FileUncheckedCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    parent?: DirectoryUpdateOneWithoutChildrenNestedInput
    children?: DirectoryUpdateManyWithoutParentNestedInput
    creator?: UserUpdateOneWithoutCreatedDirectoriesNestedInput
    permissions?: PermissionUpdateManyWithoutDirectoryNestedInput
    files?: FileUpdateManyWithoutDirectoryNestedInput
  }

  export type DirectoryUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    parentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: NullableStringFieldUpdateOperationsInput | string | null
    children?: DirectoryUncheckedUpdateManyWithoutParentNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutDirectoryNestedInput
    files?: FileUncheckedUpdateManyWithoutDirectoryNestedInput
  }

  export type DirectoryCreateManyInput = {
    id?: string
    name: string
    path: string
    parentId?: string | null
    createdAt?: Date | string
    createdBy?: string | null
  }

  export type DirectoryUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type DirectoryUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    parentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type FileCreateInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryPath?: string | null
    createdAt?: Date | string
    approvalStatus?: $Enums.ApprovalStatus
    directory?: DirectoryCreateNestedOneWithoutFilesInput
    creator: UserCreateNestedOneWithoutFilesInput
    versions?: VersionCreateNestedManyWithoutFileInput
    approver?: UserCreateNestedOneWithoutApprovedFilesInput
    approval?: ApprovalCreateNestedOneWithoutFileInput
    permissions?: PermissionCreateNestedManyWithoutFileInput
  }

  export type FileUncheckedCreateInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryId?: string | null
    directoryPath?: string | null
    createdAt?: Date | string
    createdBy: string
    approvalStatus?: $Enums.ApprovalStatus
    approvedBy?: string | null
    versions?: VersionUncheckedCreateNestedManyWithoutFileInput
    approval?: ApprovalUncheckedCreateNestedOneWithoutFileInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutFileInput
  }

  export type FileUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    directory?: DirectoryUpdateOneWithoutFilesNestedInput
    creator?: UserUpdateOneRequiredWithoutFilesNestedInput
    versions?: VersionUpdateManyWithoutFileNestedInput
    approver?: UserUpdateOneWithoutApprovedFilesNestedInput
    approval?: ApprovalUpdateOneWithoutFileNestedInput
    permissions?: PermissionUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    versions?: VersionUncheckedUpdateManyWithoutFileNestedInput
    approval?: ApprovalUncheckedUpdateOneWithoutFileNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutFileNestedInput
  }

  export type FileCreateManyInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryId?: string | null
    directoryPath?: string | null
    createdAt?: Date | string
    createdBy: string
    approvalStatus?: $Enums.ApprovalStatus
    approvedBy?: string | null
  }

  export type FileUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
  }

  export type FileUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type VersionCreateInput = {
    id?: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    approvedAt?: Date | string | null
    creator: UserCreateNestedOneWithoutCreatedVersionsInput
    file: FileCreateNestedOneWithoutVersionsInput
    approver?: UserCreateNestedOneWithoutApprovedVersionsInput
  }

  export type VersionUncheckedCreateInput = {
    id?: string
    fileId: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    createdBy: string
    approvedBy?: string | null
    approvedAt?: Date | string | null
  }

  export type VersionUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    creator?: UserUpdateOneRequiredWithoutCreatedVersionsNestedInput
    file?: FileUpdateOneRequiredWithoutVersionsNestedInput
    approver?: UserUpdateOneWithoutApprovedVersionsNestedInput
  }

  export type VersionUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdBy?: StringFieldUpdateOperationsInput | string
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type VersionCreateManyInput = {
    id?: string
    fileId: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    createdBy: string
    approvedBy?: string | null
    approvedAt?: Date | string | null
  }

  export type VersionUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type VersionUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdBy?: StringFieldUpdateOperationsInput | string
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type ApprovalCreateInput = {
    id?: string
    approvedAt?: Date | string | null
    file: FileCreateNestedOneWithoutApprovalInput
    approver?: UserCreateNestedOneWithoutApprovalsInput
  }

  export type ApprovalUncheckedCreateInput = {
    id?: string
    fileId: string
    approvedBy?: string | null
    approvedAt?: Date | string | null
  }

  export type ApprovalUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    file?: FileUpdateOneRequiredWithoutApprovalNestedInput
    approver?: UserUpdateOneWithoutApprovalsNestedInput
  }

  export type ApprovalUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type ApprovalCreateManyInput = {
    id?: string
    fileId: string
    approvedBy?: string | null
    approvedAt?: Date | string | null
  }

  export type ApprovalUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type ApprovalUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type PermissionCreateInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    cascadeToChildren?: boolean
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutPermissionsInput
    granter?: UserCreateNestedOneWithoutGivenPermissionsInput
    file?: FileCreateNestedOneWithoutPermissionsInput
    directory?: DirectoryCreateNestedOneWithoutPermissionsInput
  }

  export type PermissionUncheckedCreateInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    userId: string
    grantedBy?: string | null
    fileId?: string | null
    directoryId?: string | null
    cascadeToChildren?: boolean
    createdAt?: Date | string
  }

  export type PermissionUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutPermissionsNestedInput
    granter?: UserUpdateOneWithoutGivenPermissionsNestedInput
    file?: FileUpdateOneWithoutPermissionsNestedInput
    directory?: DirectoryUpdateOneWithoutPermissionsNestedInput
  }

  export type PermissionUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    userId?: StringFieldUpdateOperationsInput | string
    grantedBy?: NullableStringFieldUpdateOperationsInput | string | null
    fileId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PermissionCreateManyInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    userId: string
    grantedBy?: string | null
    fileId?: string | null
    directoryId?: string | null
    cascadeToChildren?: boolean
    createdAt?: Date | string
  }

  export type PermissionUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PermissionUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    userId?: StringFieldUpdateOperationsInput | string
    grantedBy?: NullableStringFieldUpdateOperationsInput | string | null
    fileId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type EnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type FileListRelationFilter = {
    every?: FileWhereInput
    some?: FileWhereInput
    none?: FileWhereInput
  }

  export type ApprovalListRelationFilter = {
    every?: ApprovalWhereInput
    some?: ApprovalWhereInput
    none?: ApprovalWhereInput
  }

  export type VersionListRelationFilter = {
    every?: VersionWhereInput
    some?: VersionWhereInput
    none?: VersionWhereInput
  }

  export type DirectoryListRelationFilter = {
    every?: DirectoryWhereInput
    some?: DirectoryWhereInput
    none?: DirectoryWhereInput
  }

  export type PermissionListRelationFilter = {
    every?: PermissionWhereInput
    some?: PermissionWhereInput
    none?: PermissionWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type FileOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ApprovalOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type VersionOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type DirectoryOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type PermissionOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type EnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type DirectoryNullableScalarRelationFilter = {
    is?: DirectoryWhereInput | null
    isNot?: DirectoryWhereInput | null
  }

  export type UserNullableScalarRelationFilter = {
    is?: UserWhereInput | null
    isNot?: UserWhereInput | null
  }

  export type DirectoryNameParentIdCompoundUniqueInput = {
    name: string
    parentId: string
  }

  export type DirectoryCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    path?: SortOrder
    parentId?: SortOrder
    createdAt?: SortOrder
    createdBy?: SortOrder
  }

  export type DirectoryMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    path?: SortOrder
    parentId?: SortOrder
    createdAt?: SortOrder
    createdBy?: SortOrder
  }

  export type DirectoryMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    path?: SortOrder
    parentId?: SortOrder
    createdAt?: SortOrder
    createdBy?: SortOrder
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type EnumApprovalStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.ApprovalStatus | EnumApprovalStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ApprovalStatus[]
    notIn?: $Enums.ApprovalStatus[]
    not?: NestedEnumApprovalStatusFilter<$PrismaModel> | $Enums.ApprovalStatus
  }

  export type UserScalarRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type ApprovalNullableScalarRelationFilter = {
    is?: ApprovalWhereInput | null
    isNot?: ApprovalWhereInput | null
  }

  export type FileCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    path?: SortOrder
    directoryId?: SortOrder
    directoryPath?: SortOrder
    createdAt?: SortOrder
    createdBy?: SortOrder
    approvalStatus?: SortOrder
    approvedBy?: SortOrder
  }

  export type FileMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    path?: SortOrder
    directoryId?: SortOrder
    directoryPath?: SortOrder
    createdAt?: SortOrder
    createdBy?: SortOrder
    approvalStatus?: SortOrder
    approvedBy?: SortOrder
  }

  export type FileMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    path?: SortOrder
    directoryId?: SortOrder
    directoryPath?: SortOrder
    createdAt?: SortOrder
    createdBy?: SortOrder
    approvalStatus?: SortOrder
    approvedBy?: SortOrder
  }

  export type EnumApprovalStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.ApprovalStatus | EnumApprovalStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ApprovalStatus[]
    notIn?: $Enums.ApprovalStatus[]
    not?: NestedEnumApprovalStatusWithAggregatesFilter<$PrismaModel> | $Enums.ApprovalStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumApprovalStatusFilter<$PrismaModel>
    _max?: NestedEnumApprovalStatusFilter<$PrismaModel>
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type FileScalarRelationFilter = {
    is?: FileWhereInput
    isNot?: FileWhereInput
  }

  export type VersionCountOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    filePath?: SortOrder
    versionNumber?: SortOrder
    createdAt?: SortOrder
    description?: SortOrder
    createdBy?: SortOrder
    approvedBy?: SortOrder
    approvedAt?: SortOrder
  }

  export type VersionAvgOrderByAggregateInput = {
    versionNumber?: SortOrder
  }

  export type VersionMaxOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    filePath?: SortOrder
    versionNumber?: SortOrder
    createdAt?: SortOrder
    description?: SortOrder
    createdBy?: SortOrder
    approvedBy?: SortOrder
    approvedAt?: SortOrder
  }

  export type VersionMinOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    filePath?: SortOrder
    versionNumber?: SortOrder
    createdAt?: SortOrder
    description?: SortOrder
    createdBy?: SortOrder
    approvedBy?: SortOrder
    approvedAt?: SortOrder
  }

  export type VersionSumOrderByAggregateInput = {
    versionNumber?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type ApprovalCountOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    approvedBy?: SortOrder
    approvedAt?: SortOrder
  }

  export type ApprovalMaxOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    approvedBy?: SortOrder
    approvedAt?: SortOrder
  }

  export type ApprovalMinOrderByAggregateInput = {
    id?: SortOrder
    fileId?: SortOrder
    approvedBy?: SortOrder
    approvedAt?: SortOrder
  }

  export type EnumPermissionTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.PermissionType | EnumPermissionTypeFieldRefInput<$PrismaModel>
    in?: $Enums.PermissionType[]
    notIn?: $Enums.PermissionType[]
    not?: NestedEnumPermissionTypeFilter<$PrismaModel> | $Enums.PermissionType
  }

  export type EnumResourceTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.ResourceType | EnumResourceTypeFieldRefInput<$PrismaModel>
    in?: $Enums.ResourceType[]
    notIn?: $Enums.ResourceType[]
    not?: NestedEnumResourceTypeFilter<$PrismaModel> | $Enums.ResourceType
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type FileNullableScalarRelationFilter = {
    is?: FileWhereInput | null
    isNot?: FileWhereInput | null
  }

  export type PermissionUserIdResourceTypeFileIdCompoundUniqueInput = {
    userId: string
    resourceType: $Enums.ResourceType
    fileId: string
  }

  export type PermissionUserIdResourceTypeDirectoryIdCompoundUniqueInput = {
    userId: string
    resourceType: $Enums.ResourceType
    directoryId: string
  }

  export type PermissionCountOrderByAggregateInput = {
    id?: SortOrder
    permissionType?: SortOrder
    resourceType?: SortOrder
    userId?: SortOrder
    grantedBy?: SortOrder
    fileId?: SortOrder
    directoryId?: SortOrder
    cascadeToChildren?: SortOrder
    createdAt?: SortOrder
  }

  export type PermissionMaxOrderByAggregateInput = {
    id?: SortOrder
    permissionType?: SortOrder
    resourceType?: SortOrder
    userId?: SortOrder
    grantedBy?: SortOrder
    fileId?: SortOrder
    directoryId?: SortOrder
    cascadeToChildren?: SortOrder
    createdAt?: SortOrder
  }

  export type PermissionMinOrderByAggregateInput = {
    id?: SortOrder
    permissionType?: SortOrder
    resourceType?: SortOrder
    userId?: SortOrder
    grantedBy?: SortOrder
    fileId?: SortOrder
    directoryId?: SortOrder
    cascadeToChildren?: SortOrder
    createdAt?: SortOrder
  }

  export type EnumPermissionTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PermissionType | EnumPermissionTypeFieldRefInput<$PrismaModel>
    in?: $Enums.PermissionType[]
    notIn?: $Enums.PermissionType[]
    not?: NestedEnumPermissionTypeWithAggregatesFilter<$PrismaModel> | $Enums.PermissionType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPermissionTypeFilter<$PrismaModel>
    _max?: NestedEnumPermissionTypeFilter<$PrismaModel>
  }

  export type EnumResourceTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.ResourceType | EnumResourceTypeFieldRefInput<$PrismaModel>
    in?: $Enums.ResourceType[]
    notIn?: $Enums.ResourceType[]
    not?: NestedEnumResourceTypeWithAggregatesFilter<$PrismaModel> | $Enums.ResourceType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumResourceTypeFilter<$PrismaModel>
    _max?: NestedEnumResourceTypeFilter<$PrismaModel>
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type FileCreateNestedManyWithoutCreatorInput = {
    create?: XOR<FileCreateWithoutCreatorInput, FileUncheckedCreateWithoutCreatorInput> | FileCreateWithoutCreatorInput[] | FileUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: FileCreateOrConnectWithoutCreatorInput | FileCreateOrConnectWithoutCreatorInput[]
    createMany?: FileCreateManyCreatorInputEnvelope
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
  }

  export type ApprovalCreateNestedManyWithoutApproverInput = {
    create?: XOR<ApprovalCreateWithoutApproverInput, ApprovalUncheckedCreateWithoutApproverInput> | ApprovalCreateWithoutApproverInput[] | ApprovalUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: ApprovalCreateOrConnectWithoutApproverInput | ApprovalCreateOrConnectWithoutApproverInput[]
    createMany?: ApprovalCreateManyApproverInputEnvelope
    connect?: ApprovalWhereUniqueInput | ApprovalWhereUniqueInput[]
  }

  export type VersionCreateNestedManyWithoutApproverInput = {
    create?: XOR<VersionCreateWithoutApproverInput, VersionUncheckedCreateWithoutApproverInput> | VersionCreateWithoutApproverInput[] | VersionUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutApproverInput | VersionCreateOrConnectWithoutApproverInput[]
    createMany?: VersionCreateManyApproverInputEnvelope
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
  }

  export type FileCreateNestedManyWithoutApproverInput = {
    create?: XOR<FileCreateWithoutApproverInput, FileUncheckedCreateWithoutApproverInput> | FileCreateWithoutApproverInput[] | FileUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: FileCreateOrConnectWithoutApproverInput | FileCreateOrConnectWithoutApproverInput[]
    createMany?: FileCreateManyApproverInputEnvelope
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
  }

  export type VersionCreateNestedManyWithoutCreatorInput = {
    create?: XOR<VersionCreateWithoutCreatorInput, VersionUncheckedCreateWithoutCreatorInput> | VersionCreateWithoutCreatorInput[] | VersionUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutCreatorInput | VersionCreateOrConnectWithoutCreatorInput[]
    createMany?: VersionCreateManyCreatorInputEnvelope
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
  }

  export type DirectoryCreateNestedManyWithoutCreatorInput = {
    create?: XOR<DirectoryCreateWithoutCreatorInput, DirectoryUncheckedCreateWithoutCreatorInput> | DirectoryCreateWithoutCreatorInput[] | DirectoryUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: DirectoryCreateOrConnectWithoutCreatorInput | DirectoryCreateOrConnectWithoutCreatorInput[]
    createMany?: DirectoryCreateManyCreatorInputEnvelope
    connect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
  }

  export type PermissionCreateNestedManyWithoutGranterInput = {
    create?: XOR<PermissionCreateWithoutGranterInput, PermissionUncheckedCreateWithoutGranterInput> | PermissionCreateWithoutGranterInput[] | PermissionUncheckedCreateWithoutGranterInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutGranterInput | PermissionCreateOrConnectWithoutGranterInput[]
    createMany?: PermissionCreateManyGranterInputEnvelope
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
  }

  export type PermissionCreateNestedManyWithoutUserInput = {
    create?: XOR<PermissionCreateWithoutUserInput, PermissionUncheckedCreateWithoutUserInput> | PermissionCreateWithoutUserInput[] | PermissionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutUserInput | PermissionCreateOrConnectWithoutUserInput[]
    createMany?: PermissionCreateManyUserInputEnvelope
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
  }

  export type FileUncheckedCreateNestedManyWithoutCreatorInput = {
    create?: XOR<FileCreateWithoutCreatorInput, FileUncheckedCreateWithoutCreatorInput> | FileCreateWithoutCreatorInput[] | FileUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: FileCreateOrConnectWithoutCreatorInput | FileCreateOrConnectWithoutCreatorInput[]
    createMany?: FileCreateManyCreatorInputEnvelope
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
  }

  export type ApprovalUncheckedCreateNestedManyWithoutApproverInput = {
    create?: XOR<ApprovalCreateWithoutApproverInput, ApprovalUncheckedCreateWithoutApproverInput> | ApprovalCreateWithoutApproverInput[] | ApprovalUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: ApprovalCreateOrConnectWithoutApproverInput | ApprovalCreateOrConnectWithoutApproverInput[]
    createMany?: ApprovalCreateManyApproverInputEnvelope
    connect?: ApprovalWhereUniqueInput | ApprovalWhereUniqueInput[]
  }

  export type VersionUncheckedCreateNestedManyWithoutApproverInput = {
    create?: XOR<VersionCreateWithoutApproverInput, VersionUncheckedCreateWithoutApproverInput> | VersionCreateWithoutApproverInput[] | VersionUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutApproverInput | VersionCreateOrConnectWithoutApproverInput[]
    createMany?: VersionCreateManyApproverInputEnvelope
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
  }

  export type FileUncheckedCreateNestedManyWithoutApproverInput = {
    create?: XOR<FileCreateWithoutApproverInput, FileUncheckedCreateWithoutApproverInput> | FileCreateWithoutApproverInput[] | FileUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: FileCreateOrConnectWithoutApproverInput | FileCreateOrConnectWithoutApproverInput[]
    createMany?: FileCreateManyApproverInputEnvelope
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
  }

  export type VersionUncheckedCreateNestedManyWithoutCreatorInput = {
    create?: XOR<VersionCreateWithoutCreatorInput, VersionUncheckedCreateWithoutCreatorInput> | VersionCreateWithoutCreatorInput[] | VersionUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutCreatorInput | VersionCreateOrConnectWithoutCreatorInput[]
    createMany?: VersionCreateManyCreatorInputEnvelope
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
  }

  export type DirectoryUncheckedCreateNestedManyWithoutCreatorInput = {
    create?: XOR<DirectoryCreateWithoutCreatorInput, DirectoryUncheckedCreateWithoutCreatorInput> | DirectoryCreateWithoutCreatorInput[] | DirectoryUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: DirectoryCreateOrConnectWithoutCreatorInput | DirectoryCreateOrConnectWithoutCreatorInput[]
    createMany?: DirectoryCreateManyCreatorInputEnvelope
    connect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
  }

  export type PermissionUncheckedCreateNestedManyWithoutGranterInput = {
    create?: XOR<PermissionCreateWithoutGranterInput, PermissionUncheckedCreateWithoutGranterInput> | PermissionCreateWithoutGranterInput[] | PermissionUncheckedCreateWithoutGranterInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutGranterInput | PermissionCreateOrConnectWithoutGranterInput[]
    createMany?: PermissionCreateManyGranterInputEnvelope
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
  }

  export type PermissionUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<PermissionCreateWithoutUserInput, PermissionUncheckedCreateWithoutUserInput> | PermissionCreateWithoutUserInput[] | PermissionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutUserInput | PermissionCreateOrConnectWithoutUserInput[]
    createMany?: PermissionCreateManyUserInputEnvelope
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type EnumRoleFieldUpdateOperationsInput = {
    set?: $Enums.Role
  }

  export type FileUpdateManyWithoutCreatorNestedInput = {
    create?: XOR<FileCreateWithoutCreatorInput, FileUncheckedCreateWithoutCreatorInput> | FileCreateWithoutCreatorInput[] | FileUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: FileCreateOrConnectWithoutCreatorInput | FileCreateOrConnectWithoutCreatorInput[]
    upsert?: FileUpsertWithWhereUniqueWithoutCreatorInput | FileUpsertWithWhereUniqueWithoutCreatorInput[]
    createMany?: FileCreateManyCreatorInputEnvelope
    set?: FileWhereUniqueInput | FileWhereUniqueInput[]
    disconnect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    delete?: FileWhereUniqueInput | FileWhereUniqueInput[]
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    update?: FileUpdateWithWhereUniqueWithoutCreatorInput | FileUpdateWithWhereUniqueWithoutCreatorInput[]
    updateMany?: FileUpdateManyWithWhereWithoutCreatorInput | FileUpdateManyWithWhereWithoutCreatorInput[]
    deleteMany?: FileScalarWhereInput | FileScalarWhereInput[]
  }

  export type ApprovalUpdateManyWithoutApproverNestedInput = {
    create?: XOR<ApprovalCreateWithoutApproverInput, ApprovalUncheckedCreateWithoutApproverInput> | ApprovalCreateWithoutApproverInput[] | ApprovalUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: ApprovalCreateOrConnectWithoutApproverInput | ApprovalCreateOrConnectWithoutApproverInput[]
    upsert?: ApprovalUpsertWithWhereUniqueWithoutApproverInput | ApprovalUpsertWithWhereUniqueWithoutApproverInput[]
    createMany?: ApprovalCreateManyApproverInputEnvelope
    set?: ApprovalWhereUniqueInput | ApprovalWhereUniqueInput[]
    disconnect?: ApprovalWhereUniqueInput | ApprovalWhereUniqueInput[]
    delete?: ApprovalWhereUniqueInput | ApprovalWhereUniqueInput[]
    connect?: ApprovalWhereUniqueInput | ApprovalWhereUniqueInput[]
    update?: ApprovalUpdateWithWhereUniqueWithoutApproverInput | ApprovalUpdateWithWhereUniqueWithoutApproverInput[]
    updateMany?: ApprovalUpdateManyWithWhereWithoutApproverInput | ApprovalUpdateManyWithWhereWithoutApproverInput[]
    deleteMany?: ApprovalScalarWhereInput | ApprovalScalarWhereInput[]
  }

  export type VersionUpdateManyWithoutApproverNestedInput = {
    create?: XOR<VersionCreateWithoutApproverInput, VersionUncheckedCreateWithoutApproverInput> | VersionCreateWithoutApproverInput[] | VersionUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutApproverInput | VersionCreateOrConnectWithoutApproverInput[]
    upsert?: VersionUpsertWithWhereUniqueWithoutApproverInput | VersionUpsertWithWhereUniqueWithoutApproverInput[]
    createMany?: VersionCreateManyApproverInputEnvelope
    set?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    disconnect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    delete?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    update?: VersionUpdateWithWhereUniqueWithoutApproverInput | VersionUpdateWithWhereUniqueWithoutApproverInput[]
    updateMany?: VersionUpdateManyWithWhereWithoutApproverInput | VersionUpdateManyWithWhereWithoutApproverInput[]
    deleteMany?: VersionScalarWhereInput | VersionScalarWhereInput[]
  }

  export type FileUpdateManyWithoutApproverNestedInput = {
    create?: XOR<FileCreateWithoutApproverInput, FileUncheckedCreateWithoutApproverInput> | FileCreateWithoutApproverInput[] | FileUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: FileCreateOrConnectWithoutApproverInput | FileCreateOrConnectWithoutApproverInput[]
    upsert?: FileUpsertWithWhereUniqueWithoutApproverInput | FileUpsertWithWhereUniqueWithoutApproverInput[]
    createMany?: FileCreateManyApproverInputEnvelope
    set?: FileWhereUniqueInput | FileWhereUniqueInput[]
    disconnect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    delete?: FileWhereUniqueInput | FileWhereUniqueInput[]
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    update?: FileUpdateWithWhereUniqueWithoutApproverInput | FileUpdateWithWhereUniqueWithoutApproverInput[]
    updateMany?: FileUpdateManyWithWhereWithoutApproverInput | FileUpdateManyWithWhereWithoutApproverInput[]
    deleteMany?: FileScalarWhereInput | FileScalarWhereInput[]
  }

  export type VersionUpdateManyWithoutCreatorNestedInput = {
    create?: XOR<VersionCreateWithoutCreatorInput, VersionUncheckedCreateWithoutCreatorInput> | VersionCreateWithoutCreatorInput[] | VersionUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutCreatorInput | VersionCreateOrConnectWithoutCreatorInput[]
    upsert?: VersionUpsertWithWhereUniqueWithoutCreatorInput | VersionUpsertWithWhereUniqueWithoutCreatorInput[]
    createMany?: VersionCreateManyCreatorInputEnvelope
    set?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    disconnect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    delete?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    update?: VersionUpdateWithWhereUniqueWithoutCreatorInput | VersionUpdateWithWhereUniqueWithoutCreatorInput[]
    updateMany?: VersionUpdateManyWithWhereWithoutCreatorInput | VersionUpdateManyWithWhereWithoutCreatorInput[]
    deleteMany?: VersionScalarWhereInput | VersionScalarWhereInput[]
  }

  export type DirectoryUpdateManyWithoutCreatorNestedInput = {
    create?: XOR<DirectoryCreateWithoutCreatorInput, DirectoryUncheckedCreateWithoutCreatorInput> | DirectoryCreateWithoutCreatorInput[] | DirectoryUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: DirectoryCreateOrConnectWithoutCreatorInput | DirectoryCreateOrConnectWithoutCreatorInput[]
    upsert?: DirectoryUpsertWithWhereUniqueWithoutCreatorInput | DirectoryUpsertWithWhereUniqueWithoutCreatorInput[]
    createMany?: DirectoryCreateManyCreatorInputEnvelope
    set?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    disconnect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    delete?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    connect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    update?: DirectoryUpdateWithWhereUniqueWithoutCreatorInput | DirectoryUpdateWithWhereUniqueWithoutCreatorInput[]
    updateMany?: DirectoryUpdateManyWithWhereWithoutCreatorInput | DirectoryUpdateManyWithWhereWithoutCreatorInput[]
    deleteMany?: DirectoryScalarWhereInput | DirectoryScalarWhereInput[]
  }

  export type PermissionUpdateManyWithoutGranterNestedInput = {
    create?: XOR<PermissionCreateWithoutGranterInput, PermissionUncheckedCreateWithoutGranterInput> | PermissionCreateWithoutGranterInput[] | PermissionUncheckedCreateWithoutGranterInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutGranterInput | PermissionCreateOrConnectWithoutGranterInput[]
    upsert?: PermissionUpsertWithWhereUniqueWithoutGranterInput | PermissionUpsertWithWhereUniqueWithoutGranterInput[]
    createMany?: PermissionCreateManyGranterInputEnvelope
    set?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    disconnect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    delete?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    update?: PermissionUpdateWithWhereUniqueWithoutGranterInput | PermissionUpdateWithWhereUniqueWithoutGranterInput[]
    updateMany?: PermissionUpdateManyWithWhereWithoutGranterInput | PermissionUpdateManyWithWhereWithoutGranterInput[]
    deleteMany?: PermissionScalarWhereInput | PermissionScalarWhereInput[]
  }

  export type PermissionUpdateManyWithoutUserNestedInput = {
    create?: XOR<PermissionCreateWithoutUserInput, PermissionUncheckedCreateWithoutUserInput> | PermissionCreateWithoutUserInput[] | PermissionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutUserInput | PermissionCreateOrConnectWithoutUserInput[]
    upsert?: PermissionUpsertWithWhereUniqueWithoutUserInput | PermissionUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: PermissionCreateManyUserInputEnvelope
    set?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    disconnect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    delete?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    update?: PermissionUpdateWithWhereUniqueWithoutUserInput | PermissionUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: PermissionUpdateManyWithWhereWithoutUserInput | PermissionUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: PermissionScalarWhereInput | PermissionScalarWhereInput[]
  }

  export type FileUncheckedUpdateManyWithoutCreatorNestedInput = {
    create?: XOR<FileCreateWithoutCreatorInput, FileUncheckedCreateWithoutCreatorInput> | FileCreateWithoutCreatorInput[] | FileUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: FileCreateOrConnectWithoutCreatorInput | FileCreateOrConnectWithoutCreatorInput[]
    upsert?: FileUpsertWithWhereUniqueWithoutCreatorInput | FileUpsertWithWhereUniqueWithoutCreatorInput[]
    createMany?: FileCreateManyCreatorInputEnvelope
    set?: FileWhereUniqueInput | FileWhereUniqueInput[]
    disconnect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    delete?: FileWhereUniqueInput | FileWhereUniqueInput[]
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    update?: FileUpdateWithWhereUniqueWithoutCreatorInput | FileUpdateWithWhereUniqueWithoutCreatorInput[]
    updateMany?: FileUpdateManyWithWhereWithoutCreatorInput | FileUpdateManyWithWhereWithoutCreatorInput[]
    deleteMany?: FileScalarWhereInput | FileScalarWhereInput[]
  }

  export type ApprovalUncheckedUpdateManyWithoutApproverNestedInput = {
    create?: XOR<ApprovalCreateWithoutApproverInput, ApprovalUncheckedCreateWithoutApproverInput> | ApprovalCreateWithoutApproverInput[] | ApprovalUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: ApprovalCreateOrConnectWithoutApproverInput | ApprovalCreateOrConnectWithoutApproverInput[]
    upsert?: ApprovalUpsertWithWhereUniqueWithoutApproverInput | ApprovalUpsertWithWhereUniqueWithoutApproverInput[]
    createMany?: ApprovalCreateManyApproverInputEnvelope
    set?: ApprovalWhereUniqueInput | ApprovalWhereUniqueInput[]
    disconnect?: ApprovalWhereUniqueInput | ApprovalWhereUniqueInput[]
    delete?: ApprovalWhereUniqueInput | ApprovalWhereUniqueInput[]
    connect?: ApprovalWhereUniqueInput | ApprovalWhereUniqueInput[]
    update?: ApprovalUpdateWithWhereUniqueWithoutApproverInput | ApprovalUpdateWithWhereUniqueWithoutApproverInput[]
    updateMany?: ApprovalUpdateManyWithWhereWithoutApproverInput | ApprovalUpdateManyWithWhereWithoutApproverInput[]
    deleteMany?: ApprovalScalarWhereInput | ApprovalScalarWhereInput[]
  }

  export type VersionUncheckedUpdateManyWithoutApproverNestedInput = {
    create?: XOR<VersionCreateWithoutApproverInput, VersionUncheckedCreateWithoutApproverInput> | VersionCreateWithoutApproverInput[] | VersionUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutApproverInput | VersionCreateOrConnectWithoutApproverInput[]
    upsert?: VersionUpsertWithWhereUniqueWithoutApproverInput | VersionUpsertWithWhereUniqueWithoutApproverInput[]
    createMany?: VersionCreateManyApproverInputEnvelope
    set?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    disconnect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    delete?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    update?: VersionUpdateWithWhereUniqueWithoutApproverInput | VersionUpdateWithWhereUniqueWithoutApproverInput[]
    updateMany?: VersionUpdateManyWithWhereWithoutApproverInput | VersionUpdateManyWithWhereWithoutApproverInput[]
    deleteMany?: VersionScalarWhereInput | VersionScalarWhereInput[]
  }

  export type FileUncheckedUpdateManyWithoutApproverNestedInput = {
    create?: XOR<FileCreateWithoutApproverInput, FileUncheckedCreateWithoutApproverInput> | FileCreateWithoutApproverInput[] | FileUncheckedCreateWithoutApproverInput[]
    connectOrCreate?: FileCreateOrConnectWithoutApproverInput | FileCreateOrConnectWithoutApproverInput[]
    upsert?: FileUpsertWithWhereUniqueWithoutApproverInput | FileUpsertWithWhereUniqueWithoutApproverInput[]
    createMany?: FileCreateManyApproverInputEnvelope
    set?: FileWhereUniqueInput | FileWhereUniqueInput[]
    disconnect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    delete?: FileWhereUniqueInput | FileWhereUniqueInput[]
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    update?: FileUpdateWithWhereUniqueWithoutApproverInput | FileUpdateWithWhereUniqueWithoutApproverInput[]
    updateMany?: FileUpdateManyWithWhereWithoutApproverInput | FileUpdateManyWithWhereWithoutApproverInput[]
    deleteMany?: FileScalarWhereInput | FileScalarWhereInput[]
  }

  export type VersionUncheckedUpdateManyWithoutCreatorNestedInput = {
    create?: XOR<VersionCreateWithoutCreatorInput, VersionUncheckedCreateWithoutCreatorInput> | VersionCreateWithoutCreatorInput[] | VersionUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutCreatorInput | VersionCreateOrConnectWithoutCreatorInput[]
    upsert?: VersionUpsertWithWhereUniqueWithoutCreatorInput | VersionUpsertWithWhereUniqueWithoutCreatorInput[]
    createMany?: VersionCreateManyCreatorInputEnvelope
    set?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    disconnect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    delete?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    update?: VersionUpdateWithWhereUniqueWithoutCreatorInput | VersionUpdateWithWhereUniqueWithoutCreatorInput[]
    updateMany?: VersionUpdateManyWithWhereWithoutCreatorInput | VersionUpdateManyWithWhereWithoutCreatorInput[]
    deleteMany?: VersionScalarWhereInput | VersionScalarWhereInput[]
  }

  export type DirectoryUncheckedUpdateManyWithoutCreatorNestedInput = {
    create?: XOR<DirectoryCreateWithoutCreatorInput, DirectoryUncheckedCreateWithoutCreatorInput> | DirectoryCreateWithoutCreatorInput[] | DirectoryUncheckedCreateWithoutCreatorInput[]
    connectOrCreate?: DirectoryCreateOrConnectWithoutCreatorInput | DirectoryCreateOrConnectWithoutCreatorInput[]
    upsert?: DirectoryUpsertWithWhereUniqueWithoutCreatorInput | DirectoryUpsertWithWhereUniqueWithoutCreatorInput[]
    createMany?: DirectoryCreateManyCreatorInputEnvelope
    set?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    disconnect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    delete?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    connect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    update?: DirectoryUpdateWithWhereUniqueWithoutCreatorInput | DirectoryUpdateWithWhereUniqueWithoutCreatorInput[]
    updateMany?: DirectoryUpdateManyWithWhereWithoutCreatorInput | DirectoryUpdateManyWithWhereWithoutCreatorInput[]
    deleteMany?: DirectoryScalarWhereInput | DirectoryScalarWhereInput[]
  }

  export type PermissionUncheckedUpdateManyWithoutGranterNestedInput = {
    create?: XOR<PermissionCreateWithoutGranterInput, PermissionUncheckedCreateWithoutGranterInput> | PermissionCreateWithoutGranterInput[] | PermissionUncheckedCreateWithoutGranterInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutGranterInput | PermissionCreateOrConnectWithoutGranterInput[]
    upsert?: PermissionUpsertWithWhereUniqueWithoutGranterInput | PermissionUpsertWithWhereUniqueWithoutGranterInput[]
    createMany?: PermissionCreateManyGranterInputEnvelope
    set?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    disconnect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    delete?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    update?: PermissionUpdateWithWhereUniqueWithoutGranterInput | PermissionUpdateWithWhereUniqueWithoutGranterInput[]
    updateMany?: PermissionUpdateManyWithWhereWithoutGranterInput | PermissionUpdateManyWithWhereWithoutGranterInput[]
    deleteMany?: PermissionScalarWhereInput | PermissionScalarWhereInput[]
  }

  export type PermissionUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<PermissionCreateWithoutUserInput, PermissionUncheckedCreateWithoutUserInput> | PermissionCreateWithoutUserInput[] | PermissionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutUserInput | PermissionCreateOrConnectWithoutUserInput[]
    upsert?: PermissionUpsertWithWhereUniqueWithoutUserInput | PermissionUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: PermissionCreateManyUserInputEnvelope
    set?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    disconnect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    delete?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    update?: PermissionUpdateWithWhereUniqueWithoutUserInput | PermissionUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: PermissionUpdateManyWithWhereWithoutUserInput | PermissionUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: PermissionScalarWhereInput | PermissionScalarWhereInput[]
  }

  export type DirectoryCreateNestedOneWithoutChildrenInput = {
    create?: XOR<DirectoryCreateWithoutChildrenInput, DirectoryUncheckedCreateWithoutChildrenInput>
    connectOrCreate?: DirectoryCreateOrConnectWithoutChildrenInput
    connect?: DirectoryWhereUniqueInput
  }

  export type DirectoryCreateNestedManyWithoutParentInput = {
    create?: XOR<DirectoryCreateWithoutParentInput, DirectoryUncheckedCreateWithoutParentInput> | DirectoryCreateWithoutParentInput[] | DirectoryUncheckedCreateWithoutParentInput[]
    connectOrCreate?: DirectoryCreateOrConnectWithoutParentInput | DirectoryCreateOrConnectWithoutParentInput[]
    createMany?: DirectoryCreateManyParentInputEnvelope
    connect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
  }

  export type UserCreateNestedOneWithoutCreatedDirectoriesInput = {
    create?: XOR<UserCreateWithoutCreatedDirectoriesInput, UserUncheckedCreateWithoutCreatedDirectoriesInput>
    connectOrCreate?: UserCreateOrConnectWithoutCreatedDirectoriesInput
    connect?: UserWhereUniqueInput
  }

  export type PermissionCreateNestedManyWithoutDirectoryInput = {
    create?: XOR<PermissionCreateWithoutDirectoryInput, PermissionUncheckedCreateWithoutDirectoryInput> | PermissionCreateWithoutDirectoryInput[] | PermissionUncheckedCreateWithoutDirectoryInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutDirectoryInput | PermissionCreateOrConnectWithoutDirectoryInput[]
    createMany?: PermissionCreateManyDirectoryInputEnvelope
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
  }

  export type FileCreateNestedManyWithoutDirectoryInput = {
    create?: XOR<FileCreateWithoutDirectoryInput, FileUncheckedCreateWithoutDirectoryInput> | FileCreateWithoutDirectoryInput[] | FileUncheckedCreateWithoutDirectoryInput[]
    connectOrCreate?: FileCreateOrConnectWithoutDirectoryInput | FileCreateOrConnectWithoutDirectoryInput[]
    createMany?: FileCreateManyDirectoryInputEnvelope
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
  }

  export type DirectoryUncheckedCreateNestedManyWithoutParentInput = {
    create?: XOR<DirectoryCreateWithoutParentInput, DirectoryUncheckedCreateWithoutParentInput> | DirectoryCreateWithoutParentInput[] | DirectoryUncheckedCreateWithoutParentInput[]
    connectOrCreate?: DirectoryCreateOrConnectWithoutParentInput | DirectoryCreateOrConnectWithoutParentInput[]
    createMany?: DirectoryCreateManyParentInputEnvelope
    connect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
  }

  export type PermissionUncheckedCreateNestedManyWithoutDirectoryInput = {
    create?: XOR<PermissionCreateWithoutDirectoryInput, PermissionUncheckedCreateWithoutDirectoryInput> | PermissionCreateWithoutDirectoryInput[] | PermissionUncheckedCreateWithoutDirectoryInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutDirectoryInput | PermissionCreateOrConnectWithoutDirectoryInput[]
    createMany?: PermissionCreateManyDirectoryInputEnvelope
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
  }

  export type FileUncheckedCreateNestedManyWithoutDirectoryInput = {
    create?: XOR<FileCreateWithoutDirectoryInput, FileUncheckedCreateWithoutDirectoryInput> | FileCreateWithoutDirectoryInput[] | FileUncheckedCreateWithoutDirectoryInput[]
    connectOrCreate?: FileCreateOrConnectWithoutDirectoryInput | FileCreateOrConnectWithoutDirectoryInput[]
    createMany?: FileCreateManyDirectoryInputEnvelope
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type DirectoryUpdateOneWithoutChildrenNestedInput = {
    create?: XOR<DirectoryCreateWithoutChildrenInput, DirectoryUncheckedCreateWithoutChildrenInput>
    connectOrCreate?: DirectoryCreateOrConnectWithoutChildrenInput
    upsert?: DirectoryUpsertWithoutChildrenInput
    disconnect?: DirectoryWhereInput | boolean
    delete?: DirectoryWhereInput | boolean
    connect?: DirectoryWhereUniqueInput
    update?: XOR<XOR<DirectoryUpdateToOneWithWhereWithoutChildrenInput, DirectoryUpdateWithoutChildrenInput>, DirectoryUncheckedUpdateWithoutChildrenInput>
  }

  export type DirectoryUpdateManyWithoutParentNestedInput = {
    create?: XOR<DirectoryCreateWithoutParentInput, DirectoryUncheckedCreateWithoutParentInput> | DirectoryCreateWithoutParentInput[] | DirectoryUncheckedCreateWithoutParentInput[]
    connectOrCreate?: DirectoryCreateOrConnectWithoutParentInput | DirectoryCreateOrConnectWithoutParentInput[]
    upsert?: DirectoryUpsertWithWhereUniqueWithoutParentInput | DirectoryUpsertWithWhereUniqueWithoutParentInput[]
    createMany?: DirectoryCreateManyParentInputEnvelope
    set?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    disconnect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    delete?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    connect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    update?: DirectoryUpdateWithWhereUniqueWithoutParentInput | DirectoryUpdateWithWhereUniqueWithoutParentInput[]
    updateMany?: DirectoryUpdateManyWithWhereWithoutParentInput | DirectoryUpdateManyWithWhereWithoutParentInput[]
    deleteMany?: DirectoryScalarWhereInput | DirectoryScalarWhereInput[]
  }

  export type UserUpdateOneWithoutCreatedDirectoriesNestedInput = {
    create?: XOR<UserCreateWithoutCreatedDirectoriesInput, UserUncheckedCreateWithoutCreatedDirectoriesInput>
    connectOrCreate?: UserCreateOrConnectWithoutCreatedDirectoriesInput
    upsert?: UserUpsertWithoutCreatedDirectoriesInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutCreatedDirectoriesInput, UserUpdateWithoutCreatedDirectoriesInput>, UserUncheckedUpdateWithoutCreatedDirectoriesInput>
  }

  export type PermissionUpdateManyWithoutDirectoryNestedInput = {
    create?: XOR<PermissionCreateWithoutDirectoryInput, PermissionUncheckedCreateWithoutDirectoryInput> | PermissionCreateWithoutDirectoryInput[] | PermissionUncheckedCreateWithoutDirectoryInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutDirectoryInput | PermissionCreateOrConnectWithoutDirectoryInput[]
    upsert?: PermissionUpsertWithWhereUniqueWithoutDirectoryInput | PermissionUpsertWithWhereUniqueWithoutDirectoryInput[]
    createMany?: PermissionCreateManyDirectoryInputEnvelope
    set?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    disconnect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    delete?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    update?: PermissionUpdateWithWhereUniqueWithoutDirectoryInput | PermissionUpdateWithWhereUniqueWithoutDirectoryInput[]
    updateMany?: PermissionUpdateManyWithWhereWithoutDirectoryInput | PermissionUpdateManyWithWhereWithoutDirectoryInput[]
    deleteMany?: PermissionScalarWhereInput | PermissionScalarWhereInput[]
  }

  export type FileUpdateManyWithoutDirectoryNestedInput = {
    create?: XOR<FileCreateWithoutDirectoryInput, FileUncheckedCreateWithoutDirectoryInput> | FileCreateWithoutDirectoryInput[] | FileUncheckedCreateWithoutDirectoryInput[]
    connectOrCreate?: FileCreateOrConnectWithoutDirectoryInput | FileCreateOrConnectWithoutDirectoryInput[]
    upsert?: FileUpsertWithWhereUniqueWithoutDirectoryInput | FileUpsertWithWhereUniqueWithoutDirectoryInput[]
    createMany?: FileCreateManyDirectoryInputEnvelope
    set?: FileWhereUniqueInput | FileWhereUniqueInput[]
    disconnect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    delete?: FileWhereUniqueInput | FileWhereUniqueInput[]
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    update?: FileUpdateWithWhereUniqueWithoutDirectoryInput | FileUpdateWithWhereUniqueWithoutDirectoryInput[]
    updateMany?: FileUpdateManyWithWhereWithoutDirectoryInput | FileUpdateManyWithWhereWithoutDirectoryInput[]
    deleteMany?: FileScalarWhereInput | FileScalarWhereInput[]
  }

  export type DirectoryUncheckedUpdateManyWithoutParentNestedInput = {
    create?: XOR<DirectoryCreateWithoutParentInput, DirectoryUncheckedCreateWithoutParentInput> | DirectoryCreateWithoutParentInput[] | DirectoryUncheckedCreateWithoutParentInput[]
    connectOrCreate?: DirectoryCreateOrConnectWithoutParentInput | DirectoryCreateOrConnectWithoutParentInput[]
    upsert?: DirectoryUpsertWithWhereUniqueWithoutParentInput | DirectoryUpsertWithWhereUniqueWithoutParentInput[]
    createMany?: DirectoryCreateManyParentInputEnvelope
    set?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    disconnect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    delete?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    connect?: DirectoryWhereUniqueInput | DirectoryWhereUniqueInput[]
    update?: DirectoryUpdateWithWhereUniqueWithoutParentInput | DirectoryUpdateWithWhereUniqueWithoutParentInput[]
    updateMany?: DirectoryUpdateManyWithWhereWithoutParentInput | DirectoryUpdateManyWithWhereWithoutParentInput[]
    deleteMany?: DirectoryScalarWhereInput | DirectoryScalarWhereInput[]
  }

  export type PermissionUncheckedUpdateManyWithoutDirectoryNestedInput = {
    create?: XOR<PermissionCreateWithoutDirectoryInput, PermissionUncheckedCreateWithoutDirectoryInput> | PermissionCreateWithoutDirectoryInput[] | PermissionUncheckedCreateWithoutDirectoryInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutDirectoryInput | PermissionCreateOrConnectWithoutDirectoryInput[]
    upsert?: PermissionUpsertWithWhereUniqueWithoutDirectoryInput | PermissionUpsertWithWhereUniqueWithoutDirectoryInput[]
    createMany?: PermissionCreateManyDirectoryInputEnvelope
    set?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    disconnect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    delete?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    update?: PermissionUpdateWithWhereUniqueWithoutDirectoryInput | PermissionUpdateWithWhereUniqueWithoutDirectoryInput[]
    updateMany?: PermissionUpdateManyWithWhereWithoutDirectoryInput | PermissionUpdateManyWithWhereWithoutDirectoryInput[]
    deleteMany?: PermissionScalarWhereInput | PermissionScalarWhereInput[]
  }

  export type FileUncheckedUpdateManyWithoutDirectoryNestedInput = {
    create?: XOR<FileCreateWithoutDirectoryInput, FileUncheckedCreateWithoutDirectoryInput> | FileCreateWithoutDirectoryInput[] | FileUncheckedCreateWithoutDirectoryInput[]
    connectOrCreate?: FileCreateOrConnectWithoutDirectoryInput | FileCreateOrConnectWithoutDirectoryInput[]
    upsert?: FileUpsertWithWhereUniqueWithoutDirectoryInput | FileUpsertWithWhereUniqueWithoutDirectoryInput[]
    createMany?: FileCreateManyDirectoryInputEnvelope
    set?: FileWhereUniqueInput | FileWhereUniqueInput[]
    disconnect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    delete?: FileWhereUniqueInput | FileWhereUniqueInput[]
    connect?: FileWhereUniqueInput | FileWhereUniqueInput[]
    update?: FileUpdateWithWhereUniqueWithoutDirectoryInput | FileUpdateWithWhereUniqueWithoutDirectoryInput[]
    updateMany?: FileUpdateManyWithWhereWithoutDirectoryInput | FileUpdateManyWithWhereWithoutDirectoryInput[]
    deleteMany?: FileScalarWhereInput | FileScalarWhereInput[]
  }

  export type DirectoryCreateNestedOneWithoutFilesInput = {
    create?: XOR<DirectoryCreateWithoutFilesInput, DirectoryUncheckedCreateWithoutFilesInput>
    connectOrCreate?: DirectoryCreateOrConnectWithoutFilesInput
    connect?: DirectoryWhereUniqueInput
  }

  export type UserCreateNestedOneWithoutFilesInput = {
    create?: XOR<UserCreateWithoutFilesInput, UserUncheckedCreateWithoutFilesInput>
    connectOrCreate?: UserCreateOrConnectWithoutFilesInput
    connect?: UserWhereUniqueInput
  }

  export type VersionCreateNestedManyWithoutFileInput = {
    create?: XOR<VersionCreateWithoutFileInput, VersionUncheckedCreateWithoutFileInput> | VersionCreateWithoutFileInput[] | VersionUncheckedCreateWithoutFileInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutFileInput | VersionCreateOrConnectWithoutFileInput[]
    createMany?: VersionCreateManyFileInputEnvelope
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
  }

  export type UserCreateNestedOneWithoutApprovedFilesInput = {
    create?: XOR<UserCreateWithoutApprovedFilesInput, UserUncheckedCreateWithoutApprovedFilesInput>
    connectOrCreate?: UserCreateOrConnectWithoutApprovedFilesInput
    connect?: UserWhereUniqueInput
  }

  export type ApprovalCreateNestedOneWithoutFileInput = {
    create?: XOR<ApprovalCreateWithoutFileInput, ApprovalUncheckedCreateWithoutFileInput>
    connectOrCreate?: ApprovalCreateOrConnectWithoutFileInput
    connect?: ApprovalWhereUniqueInput
  }

  export type PermissionCreateNestedManyWithoutFileInput = {
    create?: XOR<PermissionCreateWithoutFileInput, PermissionUncheckedCreateWithoutFileInput> | PermissionCreateWithoutFileInput[] | PermissionUncheckedCreateWithoutFileInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutFileInput | PermissionCreateOrConnectWithoutFileInput[]
    createMany?: PermissionCreateManyFileInputEnvelope
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
  }

  export type VersionUncheckedCreateNestedManyWithoutFileInput = {
    create?: XOR<VersionCreateWithoutFileInput, VersionUncheckedCreateWithoutFileInput> | VersionCreateWithoutFileInput[] | VersionUncheckedCreateWithoutFileInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutFileInput | VersionCreateOrConnectWithoutFileInput[]
    createMany?: VersionCreateManyFileInputEnvelope
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
  }

  export type ApprovalUncheckedCreateNestedOneWithoutFileInput = {
    create?: XOR<ApprovalCreateWithoutFileInput, ApprovalUncheckedCreateWithoutFileInput>
    connectOrCreate?: ApprovalCreateOrConnectWithoutFileInput
    connect?: ApprovalWhereUniqueInput
  }

  export type PermissionUncheckedCreateNestedManyWithoutFileInput = {
    create?: XOR<PermissionCreateWithoutFileInput, PermissionUncheckedCreateWithoutFileInput> | PermissionCreateWithoutFileInput[] | PermissionUncheckedCreateWithoutFileInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutFileInput | PermissionCreateOrConnectWithoutFileInput[]
    createMany?: PermissionCreateManyFileInputEnvelope
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
  }

  export type EnumApprovalStatusFieldUpdateOperationsInput = {
    set?: $Enums.ApprovalStatus
  }

  export type DirectoryUpdateOneWithoutFilesNestedInput = {
    create?: XOR<DirectoryCreateWithoutFilesInput, DirectoryUncheckedCreateWithoutFilesInput>
    connectOrCreate?: DirectoryCreateOrConnectWithoutFilesInput
    upsert?: DirectoryUpsertWithoutFilesInput
    disconnect?: DirectoryWhereInput | boolean
    delete?: DirectoryWhereInput | boolean
    connect?: DirectoryWhereUniqueInput
    update?: XOR<XOR<DirectoryUpdateToOneWithWhereWithoutFilesInput, DirectoryUpdateWithoutFilesInput>, DirectoryUncheckedUpdateWithoutFilesInput>
  }

  export type UserUpdateOneRequiredWithoutFilesNestedInput = {
    create?: XOR<UserCreateWithoutFilesInput, UserUncheckedCreateWithoutFilesInput>
    connectOrCreate?: UserCreateOrConnectWithoutFilesInput
    upsert?: UserUpsertWithoutFilesInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutFilesInput, UserUpdateWithoutFilesInput>, UserUncheckedUpdateWithoutFilesInput>
  }

  export type VersionUpdateManyWithoutFileNestedInput = {
    create?: XOR<VersionCreateWithoutFileInput, VersionUncheckedCreateWithoutFileInput> | VersionCreateWithoutFileInput[] | VersionUncheckedCreateWithoutFileInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutFileInput | VersionCreateOrConnectWithoutFileInput[]
    upsert?: VersionUpsertWithWhereUniqueWithoutFileInput | VersionUpsertWithWhereUniqueWithoutFileInput[]
    createMany?: VersionCreateManyFileInputEnvelope
    set?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    disconnect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    delete?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    update?: VersionUpdateWithWhereUniqueWithoutFileInput | VersionUpdateWithWhereUniqueWithoutFileInput[]
    updateMany?: VersionUpdateManyWithWhereWithoutFileInput | VersionUpdateManyWithWhereWithoutFileInput[]
    deleteMany?: VersionScalarWhereInput | VersionScalarWhereInput[]
  }

  export type UserUpdateOneWithoutApprovedFilesNestedInput = {
    create?: XOR<UserCreateWithoutApprovedFilesInput, UserUncheckedCreateWithoutApprovedFilesInput>
    connectOrCreate?: UserCreateOrConnectWithoutApprovedFilesInput
    upsert?: UserUpsertWithoutApprovedFilesInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutApprovedFilesInput, UserUpdateWithoutApprovedFilesInput>, UserUncheckedUpdateWithoutApprovedFilesInput>
  }

  export type ApprovalUpdateOneWithoutFileNestedInput = {
    create?: XOR<ApprovalCreateWithoutFileInput, ApprovalUncheckedCreateWithoutFileInput>
    connectOrCreate?: ApprovalCreateOrConnectWithoutFileInput
    upsert?: ApprovalUpsertWithoutFileInput
    disconnect?: ApprovalWhereInput | boolean
    delete?: ApprovalWhereInput | boolean
    connect?: ApprovalWhereUniqueInput
    update?: XOR<XOR<ApprovalUpdateToOneWithWhereWithoutFileInput, ApprovalUpdateWithoutFileInput>, ApprovalUncheckedUpdateWithoutFileInput>
  }

  export type PermissionUpdateManyWithoutFileNestedInput = {
    create?: XOR<PermissionCreateWithoutFileInput, PermissionUncheckedCreateWithoutFileInput> | PermissionCreateWithoutFileInput[] | PermissionUncheckedCreateWithoutFileInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutFileInput | PermissionCreateOrConnectWithoutFileInput[]
    upsert?: PermissionUpsertWithWhereUniqueWithoutFileInput | PermissionUpsertWithWhereUniqueWithoutFileInput[]
    createMany?: PermissionCreateManyFileInputEnvelope
    set?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    disconnect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    delete?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    update?: PermissionUpdateWithWhereUniqueWithoutFileInput | PermissionUpdateWithWhereUniqueWithoutFileInput[]
    updateMany?: PermissionUpdateManyWithWhereWithoutFileInput | PermissionUpdateManyWithWhereWithoutFileInput[]
    deleteMany?: PermissionScalarWhereInput | PermissionScalarWhereInput[]
  }

  export type VersionUncheckedUpdateManyWithoutFileNestedInput = {
    create?: XOR<VersionCreateWithoutFileInput, VersionUncheckedCreateWithoutFileInput> | VersionCreateWithoutFileInput[] | VersionUncheckedCreateWithoutFileInput[]
    connectOrCreate?: VersionCreateOrConnectWithoutFileInput | VersionCreateOrConnectWithoutFileInput[]
    upsert?: VersionUpsertWithWhereUniqueWithoutFileInput | VersionUpsertWithWhereUniqueWithoutFileInput[]
    createMany?: VersionCreateManyFileInputEnvelope
    set?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    disconnect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    delete?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    connect?: VersionWhereUniqueInput | VersionWhereUniqueInput[]
    update?: VersionUpdateWithWhereUniqueWithoutFileInput | VersionUpdateWithWhereUniqueWithoutFileInput[]
    updateMany?: VersionUpdateManyWithWhereWithoutFileInput | VersionUpdateManyWithWhereWithoutFileInput[]
    deleteMany?: VersionScalarWhereInput | VersionScalarWhereInput[]
  }

  export type ApprovalUncheckedUpdateOneWithoutFileNestedInput = {
    create?: XOR<ApprovalCreateWithoutFileInput, ApprovalUncheckedCreateWithoutFileInput>
    connectOrCreate?: ApprovalCreateOrConnectWithoutFileInput
    upsert?: ApprovalUpsertWithoutFileInput
    disconnect?: ApprovalWhereInput | boolean
    delete?: ApprovalWhereInput | boolean
    connect?: ApprovalWhereUniqueInput
    update?: XOR<XOR<ApprovalUpdateToOneWithWhereWithoutFileInput, ApprovalUpdateWithoutFileInput>, ApprovalUncheckedUpdateWithoutFileInput>
  }

  export type PermissionUncheckedUpdateManyWithoutFileNestedInput = {
    create?: XOR<PermissionCreateWithoutFileInput, PermissionUncheckedCreateWithoutFileInput> | PermissionCreateWithoutFileInput[] | PermissionUncheckedCreateWithoutFileInput[]
    connectOrCreate?: PermissionCreateOrConnectWithoutFileInput | PermissionCreateOrConnectWithoutFileInput[]
    upsert?: PermissionUpsertWithWhereUniqueWithoutFileInput | PermissionUpsertWithWhereUniqueWithoutFileInput[]
    createMany?: PermissionCreateManyFileInputEnvelope
    set?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    disconnect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    delete?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    connect?: PermissionWhereUniqueInput | PermissionWhereUniqueInput[]
    update?: PermissionUpdateWithWhereUniqueWithoutFileInput | PermissionUpdateWithWhereUniqueWithoutFileInput[]
    updateMany?: PermissionUpdateManyWithWhereWithoutFileInput | PermissionUpdateManyWithWhereWithoutFileInput[]
    deleteMany?: PermissionScalarWhereInput | PermissionScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutCreatedVersionsInput = {
    create?: XOR<UserCreateWithoutCreatedVersionsInput, UserUncheckedCreateWithoutCreatedVersionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutCreatedVersionsInput
    connect?: UserWhereUniqueInput
  }

  export type FileCreateNestedOneWithoutVersionsInput = {
    create?: XOR<FileCreateWithoutVersionsInput, FileUncheckedCreateWithoutVersionsInput>
    connectOrCreate?: FileCreateOrConnectWithoutVersionsInput
    connect?: FileWhereUniqueInput
  }

  export type UserCreateNestedOneWithoutApprovedVersionsInput = {
    create?: XOR<UserCreateWithoutApprovedVersionsInput, UserUncheckedCreateWithoutApprovedVersionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutApprovedVersionsInput
    connect?: UserWhereUniqueInput
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type UserUpdateOneRequiredWithoutCreatedVersionsNestedInput = {
    create?: XOR<UserCreateWithoutCreatedVersionsInput, UserUncheckedCreateWithoutCreatedVersionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutCreatedVersionsInput
    upsert?: UserUpsertWithoutCreatedVersionsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutCreatedVersionsInput, UserUpdateWithoutCreatedVersionsInput>, UserUncheckedUpdateWithoutCreatedVersionsInput>
  }

  export type FileUpdateOneRequiredWithoutVersionsNestedInput = {
    create?: XOR<FileCreateWithoutVersionsInput, FileUncheckedCreateWithoutVersionsInput>
    connectOrCreate?: FileCreateOrConnectWithoutVersionsInput
    upsert?: FileUpsertWithoutVersionsInput
    connect?: FileWhereUniqueInput
    update?: XOR<XOR<FileUpdateToOneWithWhereWithoutVersionsInput, FileUpdateWithoutVersionsInput>, FileUncheckedUpdateWithoutVersionsInput>
  }

  export type UserUpdateOneWithoutApprovedVersionsNestedInput = {
    create?: XOR<UserCreateWithoutApprovedVersionsInput, UserUncheckedCreateWithoutApprovedVersionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutApprovedVersionsInput
    upsert?: UserUpsertWithoutApprovedVersionsInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutApprovedVersionsInput, UserUpdateWithoutApprovedVersionsInput>, UserUncheckedUpdateWithoutApprovedVersionsInput>
  }

  export type FileCreateNestedOneWithoutApprovalInput = {
    create?: XOR<FileCreateWithoutApprovalInput, FileUncheckedCreateWithoutApprovalInput>
    connectOrCreate?: FileCreateOrConnectWithoutApprovalInput
    connect?: FileWhereUniqueInput
  }

  export type UserCreateNestedOneWithoutApprovalsInput = {
    create?: XOR<UserCreateWithoutApprovalsInput, UserUncheckedCreateWithoutApprovalsInput>
    connectOrCreate?: UserCreateOrConnectWithoutApprovalsInput
    connect?: UserWhereUniqueInput
  }

  export type FileUpdateOneRequiredWithoutApprovalNestedInput = {
    create?: XOR<FileCreateWithoutApprovalInput, FileUncheckedCreateWithoutApprovalInput>
    connectOrCreate?: FileCreateOrConnectWithoutApprovalInput
    upsert?: FileUpsertWithoutApprovalInput
    connect?: FileWhereUniqueInput
    update?: XOR<XOR<FileUpdateToOneWithWhereWithoutApprovalInput, FileUpdateWithoutApprovalInput>, FileUncheckedUpdateWithoutApprovalInput>
  }

  export type UserUpdateOneWithoutApprovalsNestedInput = {
    create?: XOR<UserCreateWithoutApprovalsInput, UserUncheckedCreateWithoutApprovalsInput>
    connectOrCreate?: UserCreateOrConnectWithoutApprovalsInput
    upsert?: UserUpsertWithoutApprovalsInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutApprovalsInput, UserUpdateWithoutApprovalsInput>, UserUncheckedUpdateWithoutApprovalsInput>
  }

  export type UserCreateNestedOneWithoutPermissionsInput = {
    create?: XOR<UserCreateWithoutPermissionsInput, UserUncheckedCreateWithoutPermissionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutPermissionsInput
    connect?: UserWhereUniqueInput
  }

  export type UserCreateNestedOneWithoutGivenPermissionsInput = {
    create?: XOR<UserCreateWithoutGivenPermissionsInput, UserUncheckedCreateWithoutGivenPermissionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutGivenPermissionsInput
    connect?: UserWhereUniqueInput
  }

  export type FileCreateNestedOneWithoutPermissionsInput = {
    create?: XOR<FileCreateWithoutPermissionsInput, FileUncheckedCreateWithoutPermissionsInput>
    connectOrCreate?: FileCreateOrConnectWithoutPermissionsInput
    connect?: FileWhereUniqueInput
  }

  export type DirectoryCreateNestedOneWithoutPermissionsInput = {
    create?: XOR<DirectoryCreateWithoutPermissionsInput, DirectoryUncheckedCreateWithoutPermissionsInput>
    connectOrCreate?: DirectoryCreateOrConnectWithoutPermissionsInput
    connect?: DirectoryWhereUniqueInput
  }

  export type EnumPermissionTypeFieldUpdateOperationsInput = {
    set?: $Enums.PermissionType
  }

  export type EnumResourceTypeFieldUpdateOperationsInput = {
    set?: $Enums.ResourceType
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type UserUpdateOneRequiredWithoutPermissionsNestedInput = {
    create?: XOR<UserCreateWithoutPermissionsInput, UserUncheckedCreateWithoutPermissionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutPermissionsInput
    upsert?: UserUpsertWithoutPermissionsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutPermissionsInput, UserUpdateWithoutPermissionsInput>, UserUncheckedUpdateWithoutPermissionsInput>
  }

  export type UserUpdateOneWithoutGivenPermissionsNestedInput = {
    create?: XOR<UserCreateWithoutGivenPermissionsInput, UserUncheckedCreateWithoutGivenPermissionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutGivenPermissionsInput
    upsert?: UserUpsertWithoutGivenPermissionsInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutGivenPermissionsInput, UserUpdateWithoutGivenPermissionsInput>, UserUncheckedUpdateWithoutGivenPermissionsInput>
  }

  export type FileUpdateOneWithoutPermissionsNestedInput = {
    create?: XOR<FileCreateWithoutPermissionsInput, FileUncheckedCreateWithoutPermissionsInput>
    connectOrCreate?: FileCreateOrConnectWithoutPermissionsInput
    upsert?: FileUpsertWithoutPermissionsInput
    disconnect?: FileWhereInput | boolean
    delete?: FileWhereInput | boolean
    connect?: FileWhereUniqueInput
    update?: XOR<XOR<FileUpdateToOneWithWhereWithoutPermissionsInput, FileUpdateWithoutPermissionsInput>, FileUncheckedUpdateWithoutPermissionsInput>
  }

  export type DirectoryUpdateOneWithoutPermissionsNestedInput = {
    create?: XOR<DirectoryCreateWithoutPermissionsInput, DirectoryUncheckedCreateWithoutPermissionsInput>
    connectOrCreate?: DirectoryCreateOrConnectWithoutPermissionsInput
    upsert?: DirectoryUpsertWithoutPermissionsInput
    disconnect?: DirectoryWhereInput | boolean
    delete?: DirectoryWhereInput | boolean
    connect?: DirectoryWhereUniqueInput
    update?: XOR<XOR<DirectoryUpdateToOneWithWhereWithoutPermissionsInput, DirectoryUpdateWithoutPermissionsInput>, DirectoryUncheckedUpdateWithoutPermissionsInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedEnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedEnumApprovalStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.ApprovalStatus | EnumApprovalStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ApprovalStatus[]
    notIn?: $Enums.ApprovalStatus[]
    not?: NestedEnumApprovalStatusFilter<$PrismaModel> | $Enums.ApprovalStatus
  }

  export type NestedEnumApprovalStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.ApprovalStatus | EnumApprovalStatusFieldRefInput<$PrismaModel>
    in?: $Enums.ApprovalStatus[]
    notIn?: $Enums.ApprovalStatus[]
    not?: NestedEnumApprovalStatusWithAggregatesFilter<$PrismaModel> | $Enums.ApprovalStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumApprovalStatusFilter<$PrismaModel>
    _max?: NestedEnumApprovalStatusFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedEnumPermissionTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.PermissionType | EnumPermissionTypeFieldRefInput<$PrismaModel>
    in?: $Enums.PermissionType[]
    notIn?: $Enums.PermissionType[]
    not?: NestedEnumPermissionTypeFilter<$PrismaModel> | $Enums.PermissionType
  }

  export type NestedEnumResourceTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.ResourceType | EnumResourceTypeFieldRefInput<$PrismaModel>
    in?: $Enums.ResourceType[]
    notIn?: $Enums.ResourceType[]
    not?: NestedEnumResourceTypeFilter<$PrismaModel> | $Enums.ResourceType
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedEnumPermissionTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PermissionType | EnumPermissionTypeFieldRefInput<$PrismaModel>
    in?: $Enums.PermissionType[]
    notIn?: $Enums.PermissionType[]
    not?: NestedEnumPermissionTypeWithAggregatesFilter<$PrismaModel> | $Enums.PermissionType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPermissionTypeFilter<$PrismaModel>
    _max?: NestedEnumPermissionTypeFilter<$PrismaModel>
  }

  export type NestedEnumResourceTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.ResourceType | EnumResourceTypeFieldRefInput<$PrismaModel>
    in?: $Enums.ResourceType[]
    notIn?: $Enums.ResourceType[]
    not?: NestedEnumResourceTypeWithAggregatesFilter<$PrismaModel> | $Enums.ResourceType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumResourceTypeFilter<$PrismaModel>
    _max?: NestedEnumResourceTypeFilter<$PrismaModel>
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type FileCreateWithoutCreatorInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryPath?: string | null
    createdAt?: Date | string
    approvalStatus?: $Enums.ApprovalStatus
    directory?: DirectoryCreateNestedOneWithoutFilesInput
    versions?: VersionCreateNestedManyWithoutFileInput
    approver?: UserCreateNestedOneWithoutApprovedFilesInput
    approval?: ApprovalCreateNestedOneWithoutFileInput
    permissions?: PermissionCreateNestedManyWithoutFileInput
  }

  export type FileUncheckedCreateWithoutCreatorInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryId?: string | null
    directoryPath?: string | null
    createdAt?: Date | string
    approvalStatus?: $Enums.ApprovalStatus
    approvedBy?: string | null
    versions?: VersionUncheckedCreateNestedManyWithoutFileInput
    approval?: ApprovalUncheckedCreateNestedOneWithoutFileInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutFileInput
  }

  export type FileCreateOrConnectWithoutCreatorInput = {
    where: FileWhereUniqueInput
    create: XOR<FileCreateWithoutCreatorInput, FileUncheckedCreateWithoutCreatorInput>
  }

  export type FileCreateManyCreatorInputEnvelope = {
    data: FileCreateManyCreatorInput | FileCreateManyCreatorInput[]
  }

  export type ApprovalCreateWithoutApproverInput = {
    id?: string
    approvedAt?: Date | string | null
    file: FileCreateNestedOneWithoutApprovalInput
  }

  export type ApprovalUncheckedCreateWithoutApproverInput = {
    id?: string
    fileId: string
    approvedAt?: Date | string | null
  }

  export type ApprovalCreateOrConnectWithoutApproverInput = {
    where: ApprovalWhereUniqueInput
    create: XOR<ApprovalCreateWithoutApproverInput, ApprovalUncheckedCreateWithoutApproverInput>
  }

  export type ApprovalCreateManyApproverInputEnvelope = {
    data: ApprovalCreateManyApproverInput | ApprovalCreateManyApproverInput[]
  }

  export type VersionCreateWithoutApproverInput = {
    id?: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    approvedAt?: Date | string | null
    creator: UserCreateNestedOneWithoutCreatedVersionsInput
    file: FileCreateNestedOneWithoutVersionsInput
  }

  export type VersionUncheckedCreateWithoutApproverInput = {
    id?: string
    fileId: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    createdBy: string
    approvedAt?: Date | string | null
  }

  export type VersionCreateOrConnectWithoutApproverInput = {
    where: VersionWhereUniqueInput
    create: XOR<VersionCreateWithoutApproverInput, VersionUncheckedCreateWithoutApproverInput>
  }

  export type VersionCreateManyApproverInputEnvelope = {
    data: VersionCreateManyApproverInput | VersionCreateManyApproverInput[]
  }

  export type FileCreateWithoutApproverInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryPath?: string | null
    createdAt?: Date | string
    approvalStatus?: $Enums.ApprovalStatus
    directory?: DirectoryCreateNestedOneWithoutFilesInput
    creator: UserCreateNestedOneWithoutFilesInput
    versions?: VersionCreateNestedManyWithoutFileInput
    approval?: ApprovalCreateNestedOneWithoutFileInput
    permissions?: PermissionCreateNestedManyWithoutFileInput
  }

  export type FileUncheckedCreateWithoutApproverInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryId?: string | null
    directoryPath?: string | null
    createdAt?: Date | string
    createdBy: string
    approvalStatus?: $Enums.ApprovalStatus
    versions?: VersionUncheckedCreateNestedManyWithoutFileInput
    approval?: ApprovalUncheckedCreateNestedOneWithoutFileInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutFileInput
  }

  export type FileCreateOrConnectWithoutApproverInput = {
    where: FileWhereUniqueInput
    create: XOR<FileCreateWithoutApproverInput, FileUncheckedCreateWithoutApproverInput>
  }

  export type FileCreateManyApproverInputEnvelope = {
    data: FileCreateManyApproverInput | FileCreateManyApproverInput[]
  }

  export type VersionCreateWithoutCreatorInput = {
    id?: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    approvedAt?: Date | string | null
    file: FileCreateNestedOneWithoutVersionsInput
    approver?: UserCreateNestedOneWithoutApprovedVersionsInput
  }

  export type VersionUncheckedCreateWithoutCreatorInput = {
    id?: string
    fileId: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    approvedBy?: string | null
    approvedAt?: Date | string | null
  }

  export type VersionCreateOrConnectWithoutCreatorInput = {
    where: VersionWhereUniqueInput
    create: XOR<VersionCreateWithoutCreatorInput, VersionUncheckedCreateWithoutCreatorInput>
  }

  export type VersionCreateManyCreatorInputEnvelope = {
    data: VersionCreateManyCreatorInput | VersionCreateManyCreatorInput[]
  }

  export type DirectoryCreateWithoutCreatorInput = {
    id?: string
    name: string
    path: string
    createdAt?: Date | string
    parent?: DirectoryCreateNestedOneWithoutChildrenInput
    children?: DirectoryCreateNestedManyWithoutParentInput
    permissions?: PermissionCreateNestedManyWithoutDirectoryInput
    files?: FileCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryUncheckedCreateWithoutCreatorInput = {
    id?: string
    name: string
    path: string
    parentId?: string | null
    createdAt?: Date | string
    children?: DirectoryUncheckedCreateNestedManyWithoutParentInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutDirectoryInput
    files?: FileUncheckedCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryCreateOrConnectWithoutCreatorInput = {
    where: DirectoryWhereUniqueInput
    create: XOR<DirectoryCreateWithoutCreatorInput, DirectoryUncheckedCreateWithoutCreatorInput>
  }

  export type DirectoryCreateManyCreatorInputEnvelope = {
    data: DirectoryCreateManyCreatorInput | DirectoryCreateManyCreatorInput[]
  }

  export type PermissionCreateWithoutGranterInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    cascadeToChildren?: boolean
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutPermissionsInput
    file?: FileCreateNestedOneWithoutPermissionsInput
    directory?: DirectoryCreateNestedOneWithoutPermissionsInput
  }

  export type PermissionUncheckedCreateWithoutGranterInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    userId: string
    fileId?: string | null
    directoryId?: string | null
    cascadeToChildren?: boolean
    createdAt?: Date | string
  }

  export type PermissionCreateOrConnectWithoutGranterInput = {
    where: PermissionWhereUniqueInput
    create: XOR<PermissionCreateWithoutGranterInput, PermissionUncheckedCreateWithoutGranterInput>
  }

  export type PermissionCreateManyGranterInputEnvelope = {
    data: PermissionCreateManyGranterInput | PermissionCreateManyGranterInput[]
  }

  export type PermissionCreateWithoutUserInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    cascadeToChildren?: boolean
    createdAt?: Date | string
    granter?: UserCreateNestedOneWithoutGivenPermissionsInput
    file?: FileCreateNestedOneWithoutPermissionsInput
    directory?: DirectoryCreateNestedOneWithoutPermissionsInput
  }

  export type PermissionUncheckedCreateWithoutUserInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    grantedBy?: string | null
    fileId?: string | null
    directoryId?: string | null
    cascadeToChildren?: boolean
    createdAt?: Date | string
  }

  export type PermissionCreateOrConnectWithoutUserInput = {
    where: PermissionWhereUniqueInput
    create: XOR<PermissionCreateWithoutUserInput, PermissionUncheckedCreateWithoutUserInput>
  }

  export type PermissionCreateManyUserInputEnvelope = {
    data: PermissionCreateManyUserInput | PermissionCreateManyUserInput[]
  }

  export type FileUpsertWithWhereUniqueWithoutCreatorInput = {
    where: FileWhereUniqueInput
    update: XOR<FileUpdateWithoutCreatorInput, FileUncheckedUpdateWithoutCreatorInput>
    create: XOR<FileCreateWithoutCreatorInput, FileUncheckedCreateWithoutCreatorInput>
  }

  export type FileUpdateWithWhereUniqueWithoutCreatorInput = {
    where: FileWhereUniqueInput
    data: XOR<FileUpdateWithoutCreatorInput, FileUncheckedUpdateWithoutCreatorInput>
  }

  export type FileUpdateManyWithWhereWithoutCreatorInput = {
    where: FileScalarWhereInput
    data: XOR<FileUpdateManyMutationInput, FileUncheckedUpdateManyWithoutCreatorInput>
  }

  export type FileScalarWhereInput = {
    AND?: FileScalarWhereInput | FileScalarWhereInput[]
    OR?: FileScalarWhereInput[]
    NOT?: FileScalarWhereInput | FileScalarWhereInput[]
    id?: StringFilter<"File"> | string
    name?: StringFilter<"File"> | string
    description?: StringNullableFilter<"File"> | string | null
    path?: StringFilter<"File"> | string
    directoryId?: StringNullableFilter<"File"> | string | null
    directoryPath?: StringNullableFilter<"File"> | string | null
    createdAt?: DateTimeFilter<"File"> | Date | string
    createdBy?: StringFilter<"File"> | string
    approvalStatus?: EnumApprovalStatusFilter<"File"> | $Enums.ApprovalStatus
    approvedBy?: StringNullableFilter<"File"> | string | null
  }

  export type ApprovalUpsertWithWhereUniqueWithoutApproverInput = {
    where: ApprovalWhereUniqueInput
    update: XOR<ApprovalUpdateWithoutApproverInput, ApprovalUncheckedUpdateWithoutApproverInput>
    create: XOR<ApprovalCreateWithoutApproverInput, ApprovalUncheckedCreateWithoutApproverInput>
  }

  export type ApprovalUpdateWithWhereUniqueWithoutApproverInput = {
    where: ApprovalWhereUniqueInput
    data: XOR<ApprovalUpdateWithoutApproverInput, ApprovalUncheckedUpdateWithoutApproverInput>
  }

  export type ApprovalUpdateManyWithWhereWithoutApproverInput = {
    where: ApprovalScalarWhereInput
    data: XOR<ApprovalUpdateManyMutationInput, ApprovalUncheckedUpdateManyWithoutApproverInput>
  }

  export type ApprovalScalarWhereInput = {
    AND?: ApprovalScalarWhereInput | ApprovalScalarWhereInput[]
    OR?: ApprovalScalarWhereInput[]
    NOT?: ApprovalScalarWhereInput | ApprovalScalarWhereInput[]
    id?: StringFilter<"Approval"> | string
    fileId?: StringFilter<"Approval"> | string
    approvedBy?: StringNullableFilter<"Approval"> | string | null
    approvedAt?: DateTimeNullableFilter<"Approval"> | Date | string | null
  }

  export type VersionUpsertWithWhereUniqueWithoutApproverInput = {
    where: VersionWhereUniqueInput
    update: XOR<VersionUpdateWithoutApproverInput, VersionUncheckedUpdateWithoutApproverInput>
    create: XOR<VersionCreateWithoutApproverInput, VersionUncheckedCreateWithoutApproverInput>
  }

  export type VersionUpdateWithWhereUniqueWithoutApproverInput = {
    where: VersionWhereUniqueInput
    data: XOR<VersionUpdateWithoutApproverInput, VersionUncheckedUpdateWithoutApproverInput>
  }

  export type VersionUpdateManyWithWhereWithoutApproverInput = {
    where: VersionScalarWhereInput
    data: XOR<VersionUpdateManyMutationInput, VersionUncheckedUpdateManyWithoutApproverInput>
  }

  export type VersionScalarWhereInput = {
    AND?: VersionScalarWhereInput | VersionScalarWhereInput[]
    OR?: VersionScalarWhereInput[]
    NOT?: VersionScalarWhereInput | VersionScalarWhereInput[]
    id?: StringFilter<"Version"> | string
    fileId?: StringFilter<"Version"> | string
    filePath?: StringFilter<"Version"> | string
    versionNumber?: IntFilter<"Version"> | number
    createdAt?: DateTimeFilter<"Version"> | Date | string
    description?: StringNullableFilter<"Version"> | string | null
    createdBy?: StringFilter<"Version"> | string
    approvedBy?: StringNullableFilter<"Version"> | string | null
    approvedAt?: DateTimeNullableFilter<"Version"> | Date | string | null
  }

  export type FileUpsertWithWhereUniqueWithoutApproverInput = {
    where: FileWhereUniqueInput
    update: XOR<FileUpdateWithoutApproverInput, FileUncheckedUpdateWithoutApproverInput>
    create: XOR<FileCreateWithoutApproverInput, FileUncheckedCreateWithoutApproverInput>
  }

  export type FileUpdateWithWhereUniqueWithoutApproverInput = {
    where: FileWhereUniqueInput
    data: XOR<FileUpdateWithoutApproverInput, FileUncheckedUpdateWithoutApproverInput>
  }

  export type FileUpdateManyWithWhereWithoutApproverInput = {
    where: FileScalarWhereInput
    data: XOR<FileUpdateManyMutationInput, FileUncheckedUpdateManyWithoutApproverInput>
  }

  export type VersionUpsertWithWhereUniqueWithoutCreatorInput = {
    where: VersionWhereUniqueInput
    update: XOR<VersionUpdateWithoutCreatorInput, VersionUncheckedUpdateWithoutCreatorInput>
    create: XOR<VersionCreateWithoutCreatorInput, VersionUncheckedCreateWithoutCreatorInput>
  }

  export type VersionUpdateWithWhereUniqueWithoutCreatorInput = {
    where: VersionWhereUniqueInput
    data: XOR<VersionUpdateWithoutCreatorInput, VersionUncheckedUpdateWithoutCreatorInput>
  }

  export type VersionUpdateManyWithWhereWithoutCreatorInput = {
    where: VersionScalarWhereInput
    data: XOR<VersionUpdateManyMutationInput, VersionUncheckedUpdateManyWithoutCreatorInput>
  }

  export type DirectoryUpsertWithWhereUniqueWithoutCreatorInput = {
    where: DirectoryWhereUniqueInput
    update: XOR<DirectoryUpdateWithoutCreatorInput, DirectoryUncheckedUpdateWithoutCreatorInput>
    create: XOR<DirectoryCreateWithoutCreatorInput, DirectoryUncheckedCreateWithoutCreatorInput>
  }

  export type DirectoryUpdateWithWhereUniqueWithoutCreatorInput = {
    where: DirectoryWhereUniqueInput
    data: XOR<DirectoryUpdateWithoutCreatorInput, DirectoryUncheckedUpdateWithoutCreatorInput>
  }

  export type DirectoryUpdateManyWithWhereWithoutCreatorInput = {
    where: DirectoryScalarWhereInput
    data: XOR<DirectoryUpdateManyMutationInput, DirectoryUncheckedUpdateManyWithoutCreatorInput>
  }

  export type DirectoryScalarWhereInput = {
    AND?: DirectoryScalarWhereInput | DirectoryScalarWhereInput[]
    OR?: DirectoryScalarWhereInput[]
    NOT?: DirectoryScalarWhereInput | DirectoryScalarWhereInput[]
    id?: StringFilter<"Directory"> | string
    name?: StringFilter<"Directory"> | string
    path?: StringFilter<"Directory"> | string
    parentId?: StringNullableFilter<"Directory"> | string | null
    createdAt?: DateTimeFilter<"Directory"> | Date | string
    createdBy?: StringNullableFilter<"Directory"> | string | null
  }

  export type PermissionUpsertWithWhereUniqueWithoutGranterInput = {
    where: PermissionWhereUniqueInput
    update: XOR<PermissionUpdateWithoutGranterInput, PermissionUncheckedUpdateWithoutGranterInput>
    create: XOR<PermissionCreateWithoutGranterInput, PermissionUncheckedCreateWithoutGranterInput>
  }

  export type PermissionUpdateWithWhereUniqueWithoutGranterInput = {
    where: PermissionWhereUniqueInput
    data: XOR<PermissionUpdateWithoutGranterInput, PermissionUncheckedUpdateWithoutGranterInput>
  }

  export type PermissionUpdateManyWithWhereWithoutGranterInput = {
    where: PermissionScalarWhereInput
    data: XOR<PermissionUpdateManyMutationInput, PermissionUncheckedUpdateManyWithoutGranterInput>
  }

  export type PermissionScalarWhereInput = {
    AND?: PermissionScalarWhereInput | PermissionScalarWhereInput[]
    OR?: PermissionScalarWhereInput[]
    NOT?: PermissionScalarWhereInput | PermissionScalarWhereInput[]
    id?: StringFilter<"Permission"> | string
    permissionType?: EnumPermissionTypeFilter<"Permission"> | $Enums.PermissionType
    resourceType?: EnumResourceTypeFilter<"Permission"> | $Enums.ResourceType
    userId?: StringFilter<"Permission"> | string
    grantedBy?: StringNullableFilter<"Permission"> | string | null
    fileId?: StringNullableFilter<"Permission"> | string | null
    directoryId?: StringNullableFilter<"Permission"> | string | null
    cascadeToChildren?: BoolFilter<"Permission"> | boolean
    createdAt?: DateTimeFilter<"Permission"> | Date | string
  }

  export type PermissionUpsertWithWhereUniqueWithoutUserInput = {
    where: PermissionWhereUniqueInput
    update: XOR<PermissionUpdateWithoutUserInput, PermissionUncheckedUpdateWithoutUserInput>
    create: XOR<PermissionCreateWithoutUserInput, PermissionUncheckedCreateWithoutUserInput>
  }

  export type PermissionUpdateWithWhereUniqueWithoutUserInput = {
    where: PermissionWhereUniqueInput
    data: XOR<PermissionUpdateWithoutUserInput, PermissionUncheckedUpdateWithoutUserInput>
  }

  export type PermissionUpdateManyWithWhereWithoutUserInput = {
    where: PermissionScalarWhereInput
    data: XOR<PermissionUpdateManyMutationInput, PermissionUncheckedUpdateManyWithoutUserInput>
  }

  export type DirectoryCreateWithoutChildrenInput = {
    id?: string
    name: string
    path: string
    createdAt?: Date | string
    parent?: DirectoryCreateNestedOneWithoutChildrenInput
    creator?: UserCreateNestedOneWithoutCreatedDirectoriesInput
    permissions?: PermissionCreateNestedManyWithoutDirectoryInput
    files?: FileCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryUncheckedCreateWithoutChildrenInput = {
    id?: string
    name: string
    path: string
    parentId?: string | null
    createdAt?: Date | string
    createdBy?: string | null
    permissions?: PermissionUncheckedCreateNestedManyWithoutDirectoryInput
    files?: FileUncheckedCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryCreateOrConnectWithoutChildrenInput = {
    where: DirectoryWhereUniqueInput
    create: XOR<DirectoryCreateWithoutChildrenInput, DirectoryUncheckedCreateWithoutChildrenInput>
  }

  export type DirectoryCreateWithoutParentInput = {
    id?: string
    name: string
    path: string
    createdAt?: Date | string
    children?: DirectoryCreateNestedManyWithoutParentInput
    creator?: UserCreateNestedOneWithoutCreatedDirectoriesInput
    permissions?: PermissionCreateNestedManyWithoutDirectoryInput
    files?: FileCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryUncheckedCreateWithoutParentInput = {
    id?: string
    name: string
    path: string
    createdAt?: Date | string
    createdBy?: string | null
    children?: DirectoryUncheckedCreateNestedManyWithoutParentInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutDirectoryInput
    files?: FileUncheckedCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryCreateOrConnectWithoutParentInput = {
    where: DirectoryWhereUniqueInput
    create: XOR<DirectoryCreateWithoutParentInput, DirectoryUncheckedCreateWithoutParentInput>
  }

  export type DirectoryCreateManyParentInputEnvelope = {
    data: DirectoryCreateManyParentInput | DirectoryCreateManyParentInput[]
  }

  export type UserCreateWithoutCreatedDirectoriesInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionCreateNestedManyWithoutApproverInput
    approvedFiles?: FileCreateNestedManyWithoutApproverInput
    createdVersions?: VersionCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionCreateNestedManyWithoutGranterInput
    permissions?: PermissionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutCreatedDirectoriesInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileUncheckedCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalUncheckedCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionUncheckedCreateNestedManyWithoutApproverInput
    approvedFiles?: FileUncheckedCreateNestedManyWithoutApproverInput
    createdVersions?: VersionUncheckedCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionUncheckedCreateNestedManyWithoutGranterInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutCreatedDirectoriesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutCreatedDirectoriesInput, UserUncheckedCreateWithoutCreatedDirectoriesInput>
  }

  export type PermissionCreateWithoutDirectoryInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    cascadeToChildren?: boolean
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutPermissionsInput
    granter?: UserCreateNestedOneWithoutGivenPermissionsInput
    file?: FileCreateNestedOneWithoutPermissionsInput
  }

  export type PermissionUncheckedCreateWithoutDirectoryInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    userId: string
    grantedBy?: string | null
    fileId?: string | null
    cascadeToChildren?: boolean
    createdAt?: Date | string
  }

  export type PermissionCreateOrConnectWithoutDirectoryInput = {
    where: PermissionWhereUniqueInput
    create: XOR<PermissionCreateWithoutDirectoryInput, PermissionUncheckedCreateWithoutDirectoryInput>
  }

  export type PermissionCreateManyDirectoryInputEnvelope = {
    data: PermissionCreateManyDirectoryInput | PermissionCreateManyDirectoryInput[]
  }

  export type FileCreateWithoutDirectoryInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryPath?: string | null
    createdAt?: Date | string
    approvalStatus?: $Enums.ApprovalStatus
    creator: UserCreateNestedOneWithoutFilesInput
    versions?: VersionCreateNestedManyWithoutFileInput
    approver?: UserCreateNestedOneWithoutApprovedFilesInput
    approval?: ApprovalCreateNestedOneWithoutFileInput
    permissions?: PermissionCreateNestedManyWithoutFileInput
  }

  export type FileUncheckedCreateWithoutDirectoryInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryPath?: string | null
    createdAt?: Date | string
    createdBy: string
    approvalStatus?: $Enums.ApprovalStatus
    approvedBy?: string | null
    versions?: VersionUncheckedCreateNestedManyWithoutFileInput
    approval?: ApprovalUncheckedCreateNestedOneWithoutFileInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutFileInput
  }

  export type FileCreateOrConnectWithoutDirectoryInput = {
    where: FileWhereUniqueInput
    create: XOR<FileCreateWithoutDirectoryInput, FileUncheckedCreateWithoutDirectoryInput>
  }

  export type FileCreateManyDirectoryInputEnvelope = {
    data: FileCreateManyDirectoryInput | FileCreateManyDirectoryInput[]
  }

  export type DirectoryUpsertWithoutChildrenInput = {
    update: XOR<DirectoryUpdateWithoutChildrenInput, DirectoryUncheckedUpdateWithoutChildrenInput>
    create: XOR<DirectoryCreateWithoutChildrenInput, DirectoryUncheckedCreateWithoutChildrenInput>
    where?: DirectoryWhereInput
  }

  export type DirectoryUpdateToOneWithWhereWithoutChildrenInput = {
    where?: DirectoryWhereInput
    data: XOR<DirectoryUpdateWithoutChildrenInput, DirectoryUncheckedUpdateWithoutChildrenInput>
  }

  export type DirectoryUpdateWithoutChildrenInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    parent?: DirectoryUpdateOneWithoutChildrenNestedInput
    creator?: UserUpdateOneWithoutCreatedDirectoriesNestedInput
    permissions?: PermissionUpdateManyWithoutDirectoryNestedInput
    files?: FileUpdateManyWithoutDirectoryNestedInput
  }

  export type DirectoryUncheckedUpdateWithoutChildrenInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    parentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: NullableStringFieldUpdateOperationsInput | string | null
    permissions?: PermissionUncheckedUpdateManyWithoutDirectoryNestedInput
    files?: FileUncheckedUpdateManyWithoutDirectoryNestedInput
  }

  export type DirectoryUpsertWithWhereUniqueWithoutParentInput = {
    where: DirectoryWhereUniqueInput
    update: XOR<DirectoryUpdateWithoutParentInput, DirectoryUncheckedUpdateWithoutParentInput>
    create: XOR<DirectoryCreateWithoutParentInput, DirectoryUncheckedCreateWithoutParentInput>
  }

  export type DirectoryUpdateWithWhereUniqueWithoutParentInput = {
    where: DirectoryWhereUniqueInput
    data: XOR<DirectoryUpdateWithoutParentInput, DirectoryUncheckedUpdateWithoutParentInput>
  }

  export type DirectoryUpdateManyWithWhereWithoutParentInput = {
    where: DirectoryScalarWhereInput
    data: XOR<DirectoryUpdateManyMutationInput, DirectoryUncheckedUpdateManyWithoutParentInput>
  }

  export type UserUpsertWithoutCreatedDirectoriesInput = {
    update: XOR<UserUpdateWithoutCreatedDirectoriesInput, UserUncheckedUpdateWithoutCreatedDirectoriesInput>
    create: XOR<UserCreateWithoutCreatedDirectoriesInput, UserUncheckedCreateWithoutCreatedDirectoriesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutCreatedDirectoriesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutCreatedDirectoriesInput, UserUncheckedUpdateWithoutCreatedDirectoriesInput>
  }

  export type UserUpdateWithoutCreatedDirectoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutCreatedDirectoriesInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUncheckedUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUncheckedUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUncheckedUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUncheckedUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUncheckedUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUncheckedUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type PermissionUpsertWithWhereUniqueWithoutDirectoryInput = {
    where: PermissionWhereUniqueInput
    update: XOR<PermissionUpdateWithoutDirectoryInput, PermissionUncheckedUpdateWithoutDirectoryInput>
    create: XOR<PermissionCreateWithoutDirectoryInput, PermissionUncheckedCreateWithoutDirectoryInput>
  }

  export type PermissionUpdateWithWhereUniqueWithoutDirectoryInput = {
    where: PermissionWhereUniqueInput
    data: XOR<PermissionUpdateWithoutDirectoryInput, PermissionUncheckedUpdateWithoutDirectoryInput>
  }

  export type PermissionUpdateManyWithWhereWithoutDirectoryInput = {
    where: PermissionScalarWhereInput
    data: XOR<PermissionUpdateManyMutationInput, PermissionUncheckedUpdateManyWithoutDirectoryInput>
  }

  export type FileUpsertWithWhereUniqueWithoutDirectoryInput = {
    where: FileWhereUniqueInput
    update: XOR<FileUpdateWithoutDirectoryInput, FileUncheckedUpdateWithoutDirectoryInput>
    create: XOR<FileCreateWithoutDirectoryInput, FileUncheckedCreateWithoutDirectoryInput>
  }

  export type FileUpdateWithWhereUniqueWithoutDirectoryInput = {
    where: FileWhereUniqueInput
    data: XOR<FileUpdateWithoutDirectoryInput, FileUncheckedUpdateWithoutDirectoryInput>
  }

  export type FileUpdateManyWithWhereWithoutDirectoryInput = {
    where: FileScalarWhereInput
    data: XOR<FileUpdateManyMutationInput, FileUncheckedUpdateManyWithoutDirectoryInput>
  }

  export type DirectoryCreateWithoutFilesInput = {
    id?: string
    name: string
    path: string
    createdAt?: Date | string
    parent?: DirectoryCreateNestedOneWithoutChildrenInput
    children?: DirectoryCreateNestedManyWithoutParentInput
    creator?: UserCreateNestedOneWithoutCreatedDirectoriesInput
    permissions?: PermissionCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryUncheckedCreateWithoutFilesInput = {
    id?: string
    name: string
    path: string
    parentId?: string | null
    createdAt?: Date | string
    createdBy?: string | null
    children?: DirectoryUncheckedCreateNestedManyWithoutParentInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryCreateOrConnectWithoutFilesInput = {
    where: DirectoryWhereUniqueInput
    create: XOR<DirectoryCreateWithoutFilesInput, DirectoryUncheckedCreateWithoutFilesInput>
  }

  export type UserCreateWithoutFilesInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    approvals?: ApprovalCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionCreateNestedManyWithoutApproverInput
    approvedFiles?: FileCreateNestedManyWithoutApproverInput
    createdVersions?: VersionCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionCreateNestedManyWithoutGranterInput
    permissions?: PermissionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutFilesInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    approvals?: ApprovalUncheckedCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionUncheckedCreateNestedManyWithoutApproverInput
    approvedFiles?: FileUncheckedCreateNestedManyWithoutApproverInput
    createdVersions?: VersionUncheckedCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryUncheckedCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionUncheckedCreateNestedManyWithoutGranterInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutFilesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutFilesInput, UserUncheckedCreateWithoutFilesInput>
  }

  export type VersionCreateWithoutFileInput = {
    id?: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    approvedAt?: Date | string | null
    creator: UserCreateNestedOneWithoutCreatedVersionsInput
    approver?: UserCreateNestedOneWithoutApprovedVersionsInput
  }

  export type VersionUncheckedCreateWithoutFileInput = {
    id?: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    createdBy: string
    approvedBy?: string | null
    approvedAt?: Date | string | null
  }

  export type VersionCreateOrConnectWithoutFileInput = {
    where: VersionWhereUniqueInput
    create: XOR<VersionCreateWithoutFileInput, VersionUncheckedCreateWithoutFileInput>
  }

  export type VersionCreateManyFileInputEnvelope = {
    data: VersionCreateManyFileInput | VersionCreateManyFileInput[]
  }

  export type UserCreateWithoutApprovedFilesInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionCreateNestedManyWithoutApproverInput
    createdVersions?: VersionCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionCreateNestedManyWithoutGranterInput
    permissions?: PermissionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutApprovedFilesInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileUncheckedCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalUncheckedCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionUncheckedCreateNestedManyWithoutApproverInput
    createdVersions?: VersionUncheckedCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryUncheckedCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionUncheckedCreateNestedManyWithoutGranterInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutApprovedFilesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutApprovedFilesInput, UserUncheckedCreateWithoutApprovedFilesInput>
  }

  export type ApprovalCreateWithoutFileInput = {
    id?: string
    approvedAt?: Date | string | null
    approver?: UserCreateNestedOneWithoutApprovalsInput
  }

  export type ApprovalUncheckedCreateWithoutFileInput = {
    id?: string
    approvedBy?: string | null
    approvedAt?: Date | string | null
  }

  export type ApprovalCreateOrConnectWithoutFileInput = {
    where: ApprovalWhereUniqueInput
    create: XOR<ApprovalCreateWithoutFileInput, ApprovalUncheckedCreateWithoutFileInput>
  }

  export type PermissionCreateWithoutFileInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    cascadeToChildren?: boolean
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutPermissionsInput
    granter?: UserCreateNestedOneWithoutGivenPermissionsInput
    directory?: DirectoryCreateNestedOneWithoutPermissionsInput
  }

  export type PermissionUncheckedCreateWithoutFileInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    userId: string
    grantedBy?: string | null
    directoryId?: string | null
    cascadeToChildren?: boolean
    createdAt?: Date | string
  }

  export type PermissionCreateOrConnectWithoutFileInput = {
    where: PermissionWhereUniqueInput
    create: XOR<PermissionCreateWithoutFileInput, PermissionUncheckedCreateWithoutFileInput>
  }

  export type PermissionCreateManyFileInputEnvelope = {
    data: PermissionCreateManyFileInput | PermissionCreateManyFileInput[]
  }

  export type DirectoryUpsertWithoutFilesInput = {
    update: XOR<DirectoryUpdateWithoutFilesInput, DirectoryUncheckedUpdateWithoutFilesInput>
    create: XOR<DirectoryCreateWithoutFilesInput, DirectoryUncheckedCreateWithoutFilesInput>
    where?: DirectoryWhereInput
  }

  export type DirectoryUpdateToOneWithWhereWithoutFilesInput = {
    where?: DirectoryWhereInput
    data: XOR<DirectoryUpdateWithoutFilesInput, DirectoryUncheckedUpdateWithoutFilesInput>
  }

  export type DirectoryUpdateWithoutFilesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    parent?: DirectoryUpdateOneWithoutChildrenNestedInput
    children?: DirectoryUpdateManyWithoutParentNestedInput
    creator?: UserUpdateOneWithoutCreatedDirectoriesNestedInput
    permissions?: PermissionUpdateManyWithoutDirectoryNestedInput
  }

  export type DirectoryUncheckedUpdateWithoutFilesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    parentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: NullableStringFieldUpdateOperationsInput | string | null
    children?: DirectoryUncheckedUpdateManyWithoutParentNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutDirectoryNestedInput
  }

  export type UserUpsertWithoutFilesInput = {
    update: XOR<UserUpdateWithoutFilesInput, UserUncheckedUpdateWithoutFilesInput>
    create: XOR<UserCreateWithoutFilesInput, UserUncheckedCreateWithoutFilesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutFilesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutFilesInput, UserUncheckedUpdateWithoutFilesInput>
  }

  export type UserUpdateWithoutFilesInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    approvals?: ApprovalUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutFilesInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    approvals?: ApprovalUncheckedUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUncheckedUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUncheckedUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUncheckedUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUncheckedUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUncheckedUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type VersionUpsertWithWhereUniqueWithoutFileInput = {
    where: VersionWhereUniqueInput
    update: XOR<VersionUpdateWithoutFileInput, VersionUncheckedUpdateWithoutFileInput>
    create: XOR<VersionCreateWithoutFileInput, VersionUncheckedCreateWithoutFileInput>
  }

  export type VersionUpdateWithWhereUniqueWithoutFileInput = {
    where: VersionWhereUniqueInput
    data: XOR<VersionUpdateWithoutFileInput, VersionUncheckedUpdateWithoutFileInput>
  }

  export type VersionUpdateManyWithWhereWithoutFileInput = {
    where: VersionScalarWhereInput
    data: XOR<VersionUpdateManyMutationInput, VersionUncheckedUpdateManyWithoutFileInput>
  }

  export type UserUpsertWithoutApprovedFilesInput = {
    update: XOR<UserUpdateWithoutApprovedFilesInput, UserUncheckedUpdateWithoutApprovedFilesInput>
    create: XOR<UserCreateWithoutApprovedFilesInput, UserUncheckedCreateWithoutApprovedFilesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutApprovedFilesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutApprovedFilesInput, UserUncheckedUpdateWithoutApprovedFilesInput>
  }

  export type UserUpdateWithoutApprovedFilesInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutApprovedFilesInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUncheckedUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUncheckedUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUncheckedUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUncheckedUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUncheckedUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUncheckedUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type ApprovalUpsertWithoutFileInput = {
    update: XOR<ApprovalUpdateWithoutFileInput, ApprovalUncheckedUpdateWithoutFileInput>
    create: XOR<ApprovalCreateWithoutFileInput, ApprovalUncheckedCreateWithoutFileInput>
    where?: ApprovalWhereInput
  }

  export type ApprovalUpdateToOneWithWhereWithoutFileInput = {
    where?: ApprovalWhereInput
    data: XOR<ApprovalUpdateWithoutFileInput, ApprovalUncheckedUpdateWithoutFileInput>
  }

  export type ApprovalUpdateWithoutFileInput = {
    id?: StringFieldUpdateOperationsInput | string
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    approver?: UserUpdateOneWithoutApprovalsNestedInput
  }

  export type ApprovalUncheckedUpdateWithoutFileInput = {
    id?: StringFieldUpdateOperationsInput | string
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type PermissionUpsertWithWhereUniqueWithoutFileInput = {
    where: PermissionWhereUniqueInput
    update: XOR<PermissionUpdateWithoutFileInput, PermissionUncheckedUpdateWithoutFileInput>
    create: XOR<PermissionCreateWithoutFileInput, PermissionUncheckedCreateWithoutFileInput>
  }

  export type PermissionUpdateWithWhereUniqueWithoutFileInput = {
    where: PermissionWhereUniqueInput
    data: XOR<PermissionUpdateWithoutFileInput, PermissionUncheckedUpdateWithoutFileInput>
  }

  export type PermissionUpdateManyWithWhereWithoutFileInput = {
    where: PermissionScalarWhereInput
    data: XOR<PermissionUpdateManyMutationInput, PermissionUncheckedUpdateManyWithoutFileInput>
  }

  export type UserCreateWithoutCreatedVersionsInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionCreateNestedManyWithoutApproverInput
    approvedFiles?: FileCreateNestedManyWithoutApproverInput
    createdDirectories?: DirectoryCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionCreateNestedManyWithoutGranterInput
    permissions?: PermissionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutCreatedVersionsInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileUncheckedCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalUncheckedCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionUncheckedCreateNestedManyWithoutApproverInput
    approvedFiles?: FileUncheckedCreateNestedManyWithoutApproverInput
    createdDirectories?: DirectoryUncheckedCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionUncheckedCreateNestedManyWithoutGranterInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutCreatedVersionsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutCreatedVersionsInput, UserUncheckedCreateWithoutCreatedVersionsInput>
  }

  export type FileCreateWithoutVersionsInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryPath?: string | null
    createdAt?: Date | string
    approvalStatus?: $Enums.ApprovalStatus
    directory?: DirectoryCreateNestedOneWithoutFilesInput
    creator: UserCreateNestedOneWithoutFilesInput
    approver?: UserCreateNestedOneWithoutApprovedFilesInput
    approval?: ApprovalCreateNestedOneWithoutFileInput
    permissions?: PermissionCreateNestedManyWithoutFileInput
  }

  export type FileUncheckedCreateWithoutVersionsInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryId?: string | null
    directoryPath?: string | null
    createdAt?: Date | string
    createdBy: string
    approvalStatus?: $Enums.ApprovalStatus
    approvedBy?: string | null
    approval?: ApprovalUncheckedCreateNestedOneWithoutFileInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutFileInput
  }

  export type FileCreateOrConnectWithoutVersionsInput = {
    where: FileWhereUniqueInput
    create: XOR<FileCreateWithoutVersionsInput, FileUncheckedCreateWithoutVersionsInput>
  }

  export type UserCreateWithoutApprovedVersionsInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalCreateNestedManyWithoutApproverInput
    approvedFiles?: FileCreateNestedManyWithoutApproverInput
    createdVersions?: VersionCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionCreateNestedManyWithoutGranterInput
    permissions?: PermissionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutApprovedVersionsInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileUncheckedCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalUncheckedCreateNestedManyWithoutApproverInput
    approvedFiles?: FileUncheckedCreateNestedManyWithoutApproverInput
    createdVersions?: VersionUncheckedCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryUncheckedCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionUncheckedCreateNestedManyWithoutGranterInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutApprovedVersionsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutApprovedVersionsInput, UserUncheckedCreateWithoutApprovedVersionsInput>
  }

  export type UserUpsertWithoutCreatedVersionsInput = {
    update: XOR<UserUpdateWithoutCreatedVersionsInput, UserUncheckedUpdateWithoutCreatedVersionsInput>
    create: XOR<UserCreateWithoutCreatedVersionsInput, UserUncheckedCreateWithoutCreatedVersionsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutCreatedVersionsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutCreatedVersionsInput, UserUncheckedUpdateWithoutCreatedVersionsInput>
  }

  export type UserUpdateWithoutCreatedVersionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUpdateManyWithoutApproverNestedInput
    createdDirectories?: DirectoryUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutCreatedVersionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUncheckedUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUncheckedUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUncheckedUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUncheckedUpdateManyWithoutApproverNestedInput
    createdDirectories?: DirectoryUncheckedUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUncheckedUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type FileUpsertWithoutVersionsInput = {
    update: XOR<FileUpdateWithoutVersionsInput, FileUncheckedUpdateWithoutVersionsInput>
    create: XOR<FileCreateWithoutVersionsInput, FileUncheckedCreateWithoutVersionsInput>
    where?: FileWhereInput
  }

  export type FileUpdateToOneWithWhereWithoutVersionsInput = {
    where?: FileWhereInput
    data: XOR<FileUpdateWithoutVersionsInput, FileUncheckedUpdateWithoutVersionsInput>
  }

  export type FileUpdateWithoutVersionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    directory?: DirectoryUpdateOneWithoutFilesNestedInput
    creator?: UserUpdateOneRequiredWithoutFilesNestedInput
    approver?: UserUpdateOneWithoutApprovedFilesNestedInput
    approval?: ApprovalUpdateOneWithoutFileNestedInput
    permissions?: PermissionUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateWithoutVersionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    approval?: ApprovalUncheckedUpdateOneWithoutFileNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutFileNestedInput
  }

  export type UserUpsertWithoutApprovedVersionsInput = {
    update: XOR<UserUpdateWithoutApprovedVersionsInput, UserUncheckedUpdateWithoutApprovedVersionsInput>
    create: XOR<UserCreateWithoutApprovedVersionsInput, UserUncheckedCreateWithoutApprovedVersionsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutApprovedVersionsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutApprovedVersionsInput, UserUncheckedUpdateWithoutApprovedVersionsInput>
  }

  export type UserUpdateWithoutApprovedVersionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutApprovedVersionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUncheckedUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUncheckedUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUncheckedUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUncheckedUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUncheckedUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUncheckedUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type FileCreateWithoutApprovalInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryPath?: string | null
    createdAt?: Date | string
    approvalStatus?: $Enums.ApprovalStatus
    directory?: DirectoryCreateNestedOneWithoutFilesInput
    creator: UserCreateNestedOneWithoutFilesInput
    versions?: VersionCreateNestedManyWithoutFileInput
    approver?: UserCreateNestedOneWithoutApprovedFilesInput
    permissions?: PermissionCreateNestedManyWithoutFileInput
  }

  export type FileUncheckedCreateWithoutApprovalInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryId?: string | null
    directoryPath?: string | null
    createdAt?: Date | string
    createdBy: string
    approvalStatus?: $Enums.ApprovalStatus
    approvedBy?: string | null
    versions?: VersionUncheckedCreateNestedManyWithoutFileInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutFileInput
  }

  export type FileCreateOrConnectWithoutApprovalInput = {
    where: FileWhereUniqueInput
    create: XOR<FileCreateWithoutApprovalInput, FileUncheckedCreateWithoutApprovalInput>
  }

  export type UserCreateWithoutApprovalsInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileCreateNestedManyWithoutCreatorInput
    approvedVersions?: VersionCreateNestedManyWithoutApproverInput
    approvedFiles?: FileCreateNestedManyWithoutApproverInput
    createdVersions?: VersionCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionCreateNestedManyWithoutGranterInput
    permissions?: PermissionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutApprovalsInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileUncheckedCreateNestedManyWithoutCreatorInput
    approvedVersions?: VersionUncheckedCreateNestedManyWithoutApproverInput
    approvedFiles?: FileUncheckedCreateNestedManyWithoutApproverInput
    createdVersions?: VersionUncheckedCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryUncheckedCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionUncheckedCreateNestedManyWithoutGranterInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutApprovalsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutApprovalsInput, UserUncheckedCreateWithoutApprovalsInput>
  }

  export type FileUpsertWithoutApprovalInput = {
    update: XOR<FileUpdateWithoutApprovalInput, FileUncheckedUpdateWithoutApprovalInput>
    create: XOR<FileCreateWithoutApprovalInput, FileUncheckedCreateWithoutApprovalInput>
    where?: FileWhereInput
  }

  export type FileUpdateToOneWithWhereWithoutApprovalInput = {
    where?: FileWhereInput
    data: XOR<FileUpdateWithoutApprovalInput, FileUncheckedUpdateWithoutApprovalInput>
  }

  export type FileUpdateWithoutApprovalInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    directory?: DirectoryUpdateOneWithoutFilesNestedInput
    creator?: UserUpdateOneRequiredWithoutFilesNestedInput
    versions?: VersionUpdateManyWithoutFileNestedInput
    approver?: UserUpdateOneWithoutApprovedFilesNestedInput
    permissions?: PermissionUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateWithoutApprovalInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    versions?: VersionUncheckedUpdateManyWithoutFileNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutFileNestedInput
  }

  export type UserUpsertWithoutApprovalsInput = {
    update: XOR<UserUpdateWithoutApprovalsInput, UserUncheckedUpdateWithoutApprovalsInput>
    create: XOR<UserCreateWithoutApprovalsInput, UserUncheckedCreateWithoutApprovalsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutApprovalsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutApprovalsInput, UserUncheckedUpdateWithoutApprovalsInput>
  }

  export type UserUpdateWithoutApprovalsInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUpdateManyWithoutCreatorNestedInput
    approvedVersions?: VersionUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutApprovalsInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUncheckedUpdateManyWithoutCreatorNestedInput
    approvedVersions?: VersionUncheckedUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUncheckedUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUncheckedUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUncheckedUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUncheckedUpdateManyWithoutGranterNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutPermissionsInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionCreateNestedManyWithoutApproverInput
    approvedFiles?: FileCreateNestedManyWithoutApproverInput
    createdVersions?: VersionCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionCreateNestedManyWithoutGranterInput
  }

  export type UserUncheckedCreateWithoutPermissionsInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileUncheckedCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalUncheckedCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionUncheckedCreateNestedManyWithoutApproverInput
    approvedFiles?: FileUncheckedCreateNestedManyWithoutApproverInput
    createdVersions?: VersionUncheckedCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryUncheckedCreateNestedManyWithoutCreatorInput
    givenPermissions?: PermissionUncheckedCreateNestedManyWithoutGranterInput
  }

  export type UserCreateOrConnectWithoutPermissionsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutPermissionsInput, UserUncheckedCreateWithoutPermissionsInput>
  }

  export type UserCreateWithoutGivenPermissionsInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionCreateNestedManyWithoutApproverInput
    approvedFiles?: FileCreateNestedManyWithoutApproverInput
    createdVersions?: VersionCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryCreateNestedManyWithoutCreatorInput
    permissions?: PermissionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutGivenPermissionsInput = {
    id?: string
    username: string
    email?: string | null
    password: string
    role: $Enums.Role
    files?: FileUncheckedCreateNestedManyWithoutCreatorInput
    approvals?: ApprovalUncheckedCreateNestedManyWithoutApproverInput
    approvedVersions?: VersionUncheckedCreateNestedManyWithoutApproverInput
    approvedFiles?: FileUncheckedCreateNestedManyWithoutApproverInput
    createdVersions?: VersionUncheckedCreateNestedManyWithoutCreatorInput
    createdDirectories?: DirectoryUncheckedCreateNestedManyWithoutCreatorInput
    permissions?: PermissionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutGivenPermissionsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutGivenPermissionsInput, UserUncheckedCreateWithoutGivenPermissionsInput>
  }

  export type FileCreateWithoutPermissionsInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryPath?: string | null
    createdAt?: Date | string
    approvalStatus?: $Enums.ApprovalStatus
    directory?: DirectoryCreateNestedOneWithoutFilesInput
    creator: UserCreateNestedOneWithoutFilesInput
    versions?: VersionCreateNestedManyWithoutFileInput
    approver?: UserCreateNestedOneWithoutApprovedFilesInput
    approval?: ApprovalCreateNestedOneWithoutFileInput
  }

  export type FileUncheckedCreateWithoutPermissionsInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryId?: string | null
    directoryPath?: string | null
    createdAt?: Date | string
    createdBy: string
    approvalStatus?: $Enums.ApprovalStatus
    approvedBy?: string | null
    versions?: VersionUncheckedCreateNestedManyWithoutFileInput
    approval?: ApprovalUncheckedCreateNestedOneWithoutFileInput
  }

  export type FileCreateOrConnectWithoutPermissionsInput = {
    where: FileWhereUniqueInput
    create: XOR<FileCreateWithoutPermissionsInput, FileUncheckedCreateWithoutPermissionsInput>
  }

  export type DirectoryCreateWithoutPermissionsInput = {
    id?: string
    name: string
    path: string
    createdAt?: Date | string
    parent?: DirectoryCreateNestedOneWithoutChildrenInput
    children?: DirectoryCreateNestedManyWithoutParentInput
    creator?: UserCreateNestedOneWithoutCreatedDirectoriesInput
    files?: FileCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryUncheckedCreateWithoutPermissionsInput = {
    id?: string
    name: string
    path: string
    parentId?: string | null
    createdAt?: Date | string
    createdBy?: string | null
    children?: DirectoryUncheckedCreateNestedManyWithoutParentInput
    files?: FileUncheckedCreateNestedManyWithoutDirectoryInput
  }

  export type DirectoryCreateOrConnectWithoutPermissionsInput = {
    where: DirectoryWhereUniqueInput
    create: XOR<DirectoryCreateWithoutPermissionsInput, DirectoryUncheckedCreateWithoutPermissionsInput>
  }

  export type UserUpsertWithoutPermissionsInput = {
    update: XOR<UserUpdateWithoutPermissionsInput, UserUncheckedUpdateWithoutPermissionsInput>
    create: XOR<UserCreateWithoutPermissionsInput, UserUncheckedCreateWithoutPermissionsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutPermissionsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutPermissionsInput, UserUncheckedUpdateWithoutPermissionsInput>
  }

  export type UserUpdateWithoutPermissionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUpdateManyWithoutGranterNestedInput
  }

  export type UserUncheckedUpdateWithoutPermissionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUncheckedUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUncheckedUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUncheckedUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUncheckedUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUncheckedUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUncheckedUpdateManyWithoutCreatorNestedInput
    givenPermissions?: PermissionUncheckedUpdateManyWithoutGranterNestedInput
  }

  export type UserUpsertWithoutGivenPermissionsInput = {
    update: XOR<UserUpdateWithoutGivenPermissionsInput, UserUncheckedUpdateWithoutGivenPermissionsInput>
    create: XOR<UserCreateWithoutGivenPermissionsInput, UserUncheckedCreateWithoutGivenPermissionsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutGivenPermissionsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutGivenPermissionsInput, UserUncheckedUpdateWithoutGivenPermissionsInput>
  }

  export type UserUpdateWithoutGivenPermissionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUpdateManyWithoutCreatorNestedInput
    permissions?: PermissionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutGivenPermissionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    username?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    password?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    files?: FileUncheckedUpdateManyWithoutCreatorNestedInput
    approvals?: ApprovalUncheckedUpdateManyWithoutApproverNestedInput
    approvedVersions?: VersionUncheckedUpdateManyWithoutApproverNestedInput
    approvedFiles?: FileUncheckedUpdateManyWithoutApproverNestedInput
    createdVersions?: VersionUncheckedUpdateManyWithoutCreatorNestedInput
    createdDirectories?: DirectoryUncheckedUpdateManyWithoutCreatorNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type FileUpsertWithoutPermissionsInput = {
    update: XOR<FileUpdateWithoutPermissionsInput, FileUncheckedUpdateWithoutPermissionsInput>
    create: XOR<FileCreateWithoutPermissionsInput, FileUncheckedCreateWithoutPermissionsInput>
    where?: FileWhereInput
  }

  export type FileUpdateToOneWithWhereWithoutPermissionsInput = {
    where?: FileWhereInput
    data: XOR<FileUpdateWithoutPermissionsInput, FileUncheckedUpdateWithoutPermissionsInput>
  }

  export type FileUpdateWithoutPermissionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    directory?: DirectoryUpdateOneWithoutFilesNestedInput
    creator?: UserUpdateOneRequiredWithoutFilesNestedInput
    versions?: VersionUpdateManyWithoutFileNestedInput
    approver?: UserUpdateOneWithoutApprovedFilesNestedInput
    approval?: ApprovalUpdateOneWithoutFileNestedInput
  }

  export type FileUncheckedUpdateWithoutPermissionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    versions?: VersionUncheckedUpdateManyWithoutFileNestedInput
    approval?: ApprovalUncheckedUpdateOneWithoutFileNestedInput
  }

  export type DirectoryUpsertWithoutPermissionsInput = {
    update: XOR<DirectoryUpdateWithoutPermissionsInput, DirectoryUncheckedUpdateWithoutPermissionsInput>
    create: XOR<DirectoryCreateWithoutPermissionsInput, DirectoryUncheckedCreateWithoutPermissionsInput>
    where?: DirectoryWhereInput
  }

  export type DirectoryUpdateToOneWithWhereWithoutPermissionsInput = {
    where?: DirectoryWhereInput
    data: XOR<DirectoryUpdateWithoutPermissionsInput, DirectoryUncheckedUpdateWithoutPermissionsInput>
  }

  export type DirectoryUpdateWithoutPermissionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    parent?: DirectoryUpdateOneWithoutChildrenNestedInput
    children?: DirectoryUpdateManyWithoutParentNestedInput
    creator?: UserUpdateOneWithoutCreatedDirectoriesNestedInput
    files?: FileUpdateManyWithoutDirectoryNestedInput
  }

  export type DirectoryUncheckedUpdateWithoutPermissionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    parentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: NullableStringFieldUpdateOperationsInput | string | null
    children?: DirectoryUncheckedUpdateManyWithoutParentNestedInput
    files?: FileUncheckedUpdateManyWithoutDirectoryNestedInput
  }

  export type FileCreateManyCreatorInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryId?: string | null
    directoryPath?: string | null
    createdAt?: Date | string
    approvalStatus?: $Enums.ApprovalStatus
    approvedBy?: string | null
  }

  export type ApprovalCreateManyApproverInput = {
    id?: string
    fileId: string
    approvedAt?: Date | string | null
  }

  export type VersionCreateManyApproverInput = {
    id?: string
    fileId: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    createdBy: string
    approvedAt?: Date | string | null
  }

  export type FileCreateManyApproverInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryId?: string | null
    directoryPath?: string | null
    createdAt?: Date | string
    createdBy: string
    approvalStatus?: $Enums.ApprovalStatus
  }

  export type VersionCreateManyCreatorInput = {
    id?: string
    fileId: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    approvedBy?: string | null
    approvedAt?: Date | string | null
  }

  export type DirectoryCreateManyCreatorInput = {
    id?: string
    name: string
    path: string
    parentId?: string | null
    createdAt?: Date | string
  }

  export type PermissionCreateManyGranterInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    userId: string
    fileId?: string | null
    directoryId?: string | null
    cascadeToChildren?: boolean
    createdAt?: Date | string
  }

  export type PermissionCreateManyUserInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    grantedBy?: string | null
    fileId?: string | null
    directoryId?: string | null
    cascadeToChildren?: boolean
    createdAt?: Date | string
  }

  export type FileUpdateWithoutCreatorInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    directory?: DirectoryUpdateOneWithoutFilesNestedInput
    versions?: VersionUpdateManyWithoutFileNestedInput
    approver?: UserUpdateOneWithoutApprovedFilesNestedInput
    approval?: ApprovalUpdateOneWithoutFileNestedInput
    permissions?: PermissionUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateWithoutCreatorInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    versions?: VersionUncheckedUpdateManyWithoutFileNestedInput
    approval?: ApprovalUncheckedUpdateOneWithoutFileNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateManyWithoutCreatorInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type ApprovalUpdateWithoutApproverInput = {
    id?: StringFieldUpdateOperationsInput | string
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    file?: FileUpdateOneRequiredWithoutApprovalNestedInput
  }

  export type ApprovalUncheckedUpdateWithoutApproverInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type ApprovalUncheckedUpdateManyWithoutApproverInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type VersionUpdateWithoutApproverInput = {
    id?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    creator?: UserUpdateOneRequiredWithoutCreatedVersionsNestedInput
    file?: FileUpdateOneRequiredWithoutVersionsNestedInput
  }

  export type VersionUncheckedUpdateWithoutApproverInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdBy?: StringFieldUpdateOperationsInput | string
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type VersionUncheckedUpdateManyWithoutApproverInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdBy?: StringFieldUpdateOperationsInput | string
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type FileUpdateWithoutApproverInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    directory?: DirectoryUpdateOneWithoutFilesNestedInput
    creator?: UserUpdateOneRequiredWithoutFilesNestedInput
    versions?: VersionUpdateManyWithoutFileNestedInput
    approval?: ApprovalUpdateOneWithoutFileNestedInput
    permissions?: PermissionUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateWithoutApproverInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    versions?: VersionUncheckedUpdateManyWithoutFileNestedInput
    approval?: ApprovalUncheckedUpdateOneWithoutFileNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateManyWithoutApproverInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
  }

  export type VersionUpdateWithoutCreatorInput = {
    id?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    file?: FileUpdateOneRequiredWithoutVersionsNestedInput
    approver?: UserUpdateOneWithoutApprovedVersionsNestedInput
  }

  export type VersionUncheckedUpdateWithoutCreatorInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type VersionUncheckedUpdateManyWithoutCreatorInput = {
    id?: StringFieldUpdateOperationsInput | string
    fileId?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type DirectoryUpdateWithoutCreatorInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    parent?: DirectoryUpdateOneWithoutChildrenNestedInput
    children?: DirectoryUpdateManyWithoutParentNestedInput
    permissions?: PermissionUpdateManyWithoutDirectoryNestedInput
    files?: FileUpdateManyWithoutDirectoryNestedInput
  }

  export type DirectoryUncheckedUpdateWithoutCreatorInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    parentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    children?: DirectoryUncheckedUpdateManyWithoutParentNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutDirectoryNestedInput
    files?: FileUncheckedUpdateManyWithoutDirectoryNestedInput
  }

  export type DirectoryUncheckedUpdateManyWithoutCreatorInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    parentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PermissionUpdateWithoutGranterInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutPermissionsNestedInput
    file?: FileUpdateOneWithoutPermissionsNestedInput
    directory?: DirectoryUpdateOneWithoutPermissionsNestedInput
  }

  export type PermissionUncheckedUpdateWithoutGranterInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    userId?: StringFieldUpdateOperationsInput | string
    fileId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PermissionUncheckedUpdateManyWithoutGranterInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    userId?: StringFieldUpdateOperationsInput | string
    fileId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PermissionUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    granter?: UserUpdateOneWithoutGivenPermissionsNestedInput
    file?: FileUpdateOneWithoutPermissionsNestedInput
    directory?: DirectoryUpdateOneWithoutPermissionsNestedInput
  }

  export type PermissionUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    grantedBy?: NullableStringFieldUpdateOperationsInput | string | null
    fileId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PermissionUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    grantedBy?: NullableStringFieldUpdateOperationsInput | string | null
    fileId?: NullableStringFieldUpdateOperationsInput | string | null
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type DirectoryCreateManyParentInput = {
    id?: string
    name: string
    path: string
    createdAt?: Date | string
    createdBy?: string | null
  }

  export type PermissionCreateManyDirectoryInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    userId: string
    grantedBy?: string | null
    fileId?: string | null
    cascadeToChildren?: boolean
    createdAt?: Date | string
  }

  export type FileCreateManyDirectoryInput = {
    id?: string
    name: string
    description?: string | null
    path: string
    directoryPath?: string | null
    createdAt?: Date | string
    createdBy: string
    approvalStatus?: $Enums.ApprovalStatus
    approvedBy?: string | null
  }

  export type DirectoryUpdateWithoutParentInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    children?: DirectoryUpdateManyWithoutParentNestedInput
    creator?: UserUpdateOneWithoutCreatedDirectoriesNestedInput
    permissions?: PermissionUpdateManyWithoutDirectoryNestedInput
    files?: FileUpdateManyWithoutDirectoryNestedInput
  }

  export type DirectoryUncheckedUpdateWithoutParentInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: NullableStringFieldUpdateOperationsInput | string | null
    children?: DirectoryUncheckedUpdateManyWithoutParentNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutDirectoryNestedInput
    files?: FileUncheckedUpdateManyWithoutDirectoryNestedInput
  }

  export type DirectoryUncheckedUpdateManyWithoutParentInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    path?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type PermissionUpdateWithoutDirectoryInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutPermissionsNestedInput
    granter?: UserUpdateOneWithoutGivenPermissionsNestedInput
    file?: FileUpdateOneWithoutPermissionsNestedInput
  }

  export type PermissionUncheckedUpdateWithoutDirectoryInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    userId?: StringFieldUpdateOperationsInput | string
    grantedBy?: NullableStringFieldUpdateOperationsInput | string | null
    fileId?: NullableStringFieldUpdateOperationsInput | string | null
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PermissionUncheckedUpdateManyWithoutDirectoryInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    userId?: StringFieldUpdateOperationsInput | string
    grantedBy?: NullableStringFieldUpdateOperationsInput | string | null
    fileId?: NullableStringFieldUpdateOperationsInput | string | null
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type FileUpdateWithoutDirectoryInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    creator?: UserUpdateOneRequiredWithoutFilesNestedInput
    versions?: VersionUpdateManyWithoutFileNestedInput
    approver?: UserUpdateOneWithoutApprovedFilesNestedInput
    approval?: ApprovalUpdateOneWithoutFileNestedInput
    permissions?: PermissionUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateWithoutDirectoryInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    versions?: VersionUncheckedUpdateManyWithoutFileNestedInput
    approval?: ApprovalUncheckedUpdateOneWithoutFileNestedInput
    permissions?: PermissionUncheckedUpdateManyWithoutFileNestedInput
  }

  export type FileUncheckedUpdateManyWithoutDirectoryInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    path?: StringFieldUpdateOperationsInput | string
    directoryPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    createdBy?: StringFieldUpdateOperationsInput | string
    approvalStatus?: EnumApprovalStatusFieldUpdateOperationsInput | $Enums.ApprovalStatus
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type VersionCreateManyFileInput = {
    id?: string
    filePath: string
    versionNumber: number
    createdAt?: Date | string
    description?: string | null
    createdBy: string
    approvedBy?: string | null
    approvedAt?: Date | string | null
  }

  export type PermissionCreateManyFileInput = {
    id?: string
    permissionType: $Enums.PermissionType
    resourceType: $Enums.ResourceType
    userId: string
    grantedBy?: string | null
    directoryId?: string | null
    cascadeToChildren?: boolean
    createdAt?: Date | string
  }

  export type VersionUpdateWithoutFileInput = {
    id?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    creator?: UserUpdateOneRequiredWithoutCreatedVersionsNestedInput
    approver?: UserUpdateOneWithoutApprovedVersionsNestedInput
  }

  export type VersionUncheckedUpdateWithoutFileInput = {
    id?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdBy?: StringFieldUpdateOperationsInput | string
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type VersionUncheckedUpdateManyWithoutFileInput = {
    id?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    versionNumber?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdBy?: StringFieldUpdateOperationsInput | string
    approvedBy?: NullableStringFieldUpdateOperationsInput | string | null
    approvedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type PermissionUpdateWithoutFileInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutPermissionsNestedInput
    granter?: UserUpdateOneWithoutGivenPermissionsNestedInput
    directory?: DirectoryUpdateOneWithoutPermissionsNestedInput
  }

  export type PermissionUncheckedUpdateWithoutFileInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    userId?: StringFieldUpdateOperationsInput | string
    grantedBy?: NullableStringFieldUpdateOperationsInput | string | null
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PermissionUncheckedUpdateManyWithoutFileInput = {
    id?: StringFieldUpdateOperationsInput | string
    permissionType?: EnumPermissionTypeFieldUpdateOperationsInput | $Enums.PermissionType
    resourceType?: EnumResourceTypeFieldUpdateOperationsInput | $Enums.ResourceType
    userId?: StringFieldUpdateOperationsInput | string
    grantedBy?: NullableStringFieldUpdateOperationsInput | string | null
    directoryId?: NullableStringFieldUpdateOperationsInput | string | null
    cascadeToChildren?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}