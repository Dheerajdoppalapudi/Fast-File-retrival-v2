module.exports = {
  // https://github.com/prisma/prisma/pull/12907
  ...require('.prisma/client/default'),
}
