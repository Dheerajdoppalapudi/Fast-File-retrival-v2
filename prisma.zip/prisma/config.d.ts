export { defineConfig, type PrismaConfig, type PrismaConfigInternal } from '@prisma/config';
